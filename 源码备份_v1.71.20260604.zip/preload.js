const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  openPdfDialog: () => ipcRenderer.invoke('dialog:openPdf'),
  readFile: (filePath) => ipcRenderer.invoke('fs:readFile', filePath),
  getFileInfo: (filePath) => ipcRenderer.invoke('fs:getFileInfo', filePath),

  // Print pipeline (mode-aware)
  getPrinters: () => ipcRenderer.invoke('print:getPrinters'),
  selectInvoicesDialog: () => ipcRenderer.invoke('dialog:selectInvoices'),
  executePrint: (filePaths, printerName, options) => ipcRenderer.invoke('print:executePrint', filePaths, printerName, options || {}),
  generatePreview: (filePaths, options) => ipcRenderer.invoke('print:generatePreview', filePaths, options || {}),
  openPrinterProperties: (printerName) => ipcRenderer.invoke('print:printerProperties', printerName),
  onPrintProgress: (callback) => {
    const handler = (_, data) => callback(data);
    ipcRenderer.on('print:progress', handler);
    return () => ipcRenderer.removeListener('print:progress', handler);
  },

  // PDF split / merge
  splitPDF: (filePath, ranges, outputDir) => ipcRenderer.invoke('pdf:split', filePath, ranges, outputDir),
  mergePDFs: (filePaths, outputPath) => ipcRenderer.invoke('pdf:merge', filePaths, outputPath),
  getPDFInfo: (filePath) => ipcRenderer.invoke('pdf:getInfo', filePath),

  // File dialogs (extended)
  selectDirectory: () => ipcRenderer.invoke('dialog:selectDirectory'),
  saveFileDialog: (defaultName) => ipcRenderer.invoke('dialog:saveFile', defaultName),

  // Menu event listeners
  onOpenFile: (callback) => ipcRenderer.on('open-file', (_, fp) => callback(fp)),
  onMenuOpenPdf: (callback) => ipcRenderer.on('menu:openPdf', callback),
  onMenuPrintPanel: (callback) => ipcRenderer.on('menu:printPanel', callback),
  onMenuSplitPanel: (callback) => ipcRenderer.on('menu:splitPanel', callback),
  onMenuMergePanel: (callback) => ipcRenderer.on('menu:mergePanel', callback),
  onViewFitWidth: (callback) => ipcRenderer.on('view:fitWidth', callback),
  onViewFitPage: (callback) => ipcRenderer.on('view:fitPage', callback),
  onViewActualSize: (callback) => ipcRenderer.on('view:actualSize', callback),
  onViewZoomIn: (callback) => ipcRenderer.on('view:zoomIn', callback),
  onViewZoomOut: (callback) => ipcRenderer.on('view:zoomOut', callback),

  // Expose resources path for renderer to locate unpacked files
  getResourcesPath: () => process.resourcesPath
});
