class MergePanel {
  constructor() {
    this.files = []; // [{name, path, size, pages}]
    this._createDialog();
  }

  _createDialog() {
    this.overlay = document.createElement('div');
    this.overlay.className = 'dialog-overlay';
    this.overlay.style.display = 'none';
    this.overlay.innerHTML = `
      <div class="dialog" style="max-width:600px;">
        <div class="dialog-header">
          <h2>合并文档</h2>
          <button class="dialog-close" id="merge-panel-close"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg></button>
        </div>
        <div class="dialog-body">
          <!-- 拖拽区域 -->
          <div id="merge-drop-zone" class="print-drop-zone" style="margin-bottom:12px;">
            <div class="print-drop-content">
              <p class="print-drop-icon">+</p>
              <p>拖拽PDF文件到此处</p>
              <p>或</p>
              <button id="merge-select-files" class="btn-secondary">选择文件</button>
            </div>
          </div>

          <!-- 文件列表 -->
          <div style="margin-bottom:12px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">
              <span style="font-weight:500;font-size:13px;">文件列表</span>
              <span id="merge-file-summary" style="font-size:12px;color:var(--text-secondary,#616161);">0 个文件</span>
            </div>
            <div id="merge-file-list" class="print-file-list" style="max-height:180px;">
              <div class="print-file-empty">暂无文件，请选择或拖拽PDF文件</div>
            </div>
          </div>

          <!-- 排序按钮 -->
          <div style="display:flex;gap:6px;margin-bottom:12px;">
            <button id="merge-move-up" class="btn-secondary" disabled>↑ 上移</button>
            <button id="merge-move-down" class="btn-secondary" disabled>↓ 下移</button>
            <button id="merge-remove-selected" class="btn-secondary" disabled><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg> 移除</button>
          </div>

          <!-- 输出路径 -->
          <div style="margin-bottom:12px;">
            <label style="display:block;margin-bottom:6px;font-weight:500;font-size:13px;">输出文件</label>
            <div style="display:flex;gap:8px;">
              <input type="text" id="merge-output-path" readonly style="flex:1;height:30px;border:1px solid var(--border,#d9d9d9);border-radius:4px;padding:0 8px;font-size:12px;background:#fafafa;" placeholder="请选择输出路径...">
              <button id="merge-select-output" class="btn-secondary">选择路径</button>
            </div>
          </div>
        </div>
        <div class="dialog-footer">
          <div class="dialog-footer-left">
            <span id="merge-status-text" style="font-size:12px;color:var(--text-secondary,#616161);"></span>
          </div>
          <div class="dialog-footer-right">
            <button id="merge-btn-cancel">取消</button>
            <button id="merge-btn-execute" class="btn-primary" disabled>开始合并</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(this.overlay);

    this._selectedIndex = -1;
    this._bindEvents();
  }

  _bindEvents() {
    const sel = (id) => this.overlay.querySelector(id);

    sel('#merge-panel-close').addEventListener('click', () => this.hide());
    sel('#merge-btn-cancel').addEventListener('click', () => this.hide());
    this.overlay.addEventListener('click', (e) => { if (e.target === this.overlay) this.hide(); });

    sel('#merge-select-files').addEventListener('click', () => this._selectFiles());
    sel('#merge-select-output').addEventListener('click', () => this._selectOutput());
    sel('#merge-btn-execute').addEventListener('click', () => this._executeMerge());

    sel('#merge-move-up').addEventListener('click', () => this._moveUp());
    sel('#merge-move-down').addEventListener('click', () => this._moveDown());
    sel('#merge-remove-selected').addEventListener('click', () => this._removeSelected());

    // Drag and drop
    const dropZone = sel('#merge-drop-zone');
    dropZone.addEventListener('dragover', (e) => {
      e.preventDefault(); e.stopPropagation();
      dropZone.classList.add('drag-over');
    });
    dropZone.addEventListener('dragleave', () => { dropZone.classList.remove('drag-over'); });
    dropZone.addEventListener('drop', async (e) => {
      e.preventDefault();
      dropZone.classList.remove('drag-over');
      const pdfPaths = Array.from(e.dataTransfer.files)
        .filter(f => f.name.toLowerCase().endsWith('.pdf'))
        .map(f => f.path);
      if (pdfPaths.length > 0) await this._addFiles(pdfPaths);
    });
  }

  _sel(id) { return this.overlay.querySelector(id); }

  async open() {
    this.overlay.style.display = 'flex';
    this.files = [];
    this._selectedIndex = -1;
    this._sel('#merge-output-path').value = '';
    this._sel('#merge-status-text').textContent = '';
    this._renderFileList();
    this._updateButtons();
    document.getElementById('status-text').textContent = '就绪';
  }

  hide() {
    this.overlay.style.display = 'none';
    document.getElementById('status-text').textContent = '就绪';
  }

  async _selectFiles() {
    const filePaths = await window.electronAPI.selectInvoicesDialog();
    if (filePaths && filePaths.length > 0) {
      await this._addFiles(filePaths);
    }
  }

  async _addFiles(filePaths) {
    const newPaths = filePaths.filter(fp => !this.files.some(f => f.path === fp));
    if (newPaths.length === 0) return;
    const results = await Promise.allSettled(
      newPaths.map(fp => window.electronAPI.getPDFInfo(fp))
    );
    for (let j = 0; j < results.length; j++) {
      const res = results[j];
      this.files.push(res.status === 'fulfilled'
        ? res.value
        : { name: newPaths[j].slice(newPaths[j].lastIndexOf('\\') + 1), path: newPaths[j], size: 0, pages: 0 });
    }
    this._renderFileList();
    this._updateButtons();
  }

  _removeFile(index) {
    this.files.splice(index, 1);
    if (this._selectedIndex >= this.files.length) {
      this._selectedIndex = this.files.length - 1;
    }
    this._renderFileList();
    this._updateButtons();
  }

  _removeSelected() {
    if (this._selectedIndex >= 0 && this._selectedIndex < this.files.length) {
      this._removeFile(this._selectedIndex);
    }
  }

  _moveUp() {
    if (this._selectedIndex > 0) {
      [this.files[this._selectedIndex - 1], this.files[this._selectedIndex]] =
        [this.files[this._selectedIndex], this.files[this._selectedIndex - 1]];
      this._selectedIndex--;
      this._renderFileList();
    }
  }

  _moveDown() {
    if (this._selectedIndex >= 0 && this._selectedIndex < this.files.length - 1) {
      [this.files[this._selectedIndex], this.files[this._selectedIndex + 1]] =
        [this.files[this._selectedIndex + 1], this.files[this._selectedIndex]];
      this._selectedIndex++;
      this._renderFileList();
    }
  }

  _renderFileList() {
    const list = this._sel('#merge-file-list');
    if (this.files.length === 0) {
      list.innerHTML = '<div class="print-file-empty">暂无文件，请选择或拖拽PDF文件</div>';
    } else {
      list.innerHTML = this.files.map((f, i) => `
        <div class="print-file-item merge-file-item ${i === this._selectedIndex ? 'merge-selected' : ''}" data-index="${i}">
          <span class="print-file-icon">&#9679;</span>
          <span class="print-file-name" title="${f.path}">${f.name}</span>
          <span class="print-file-size">${f.pages || '?'} 页</span>
          <button class="print-file-remove" data-index="${i}" title="移除"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg></button>
        </div>
      `).join('');

      // Click to select
      list.querySelectorAll('.merge-file-item').forEach(item => {
        item.addEventListener('click', (e) => {
          if (e.target.classList.contains('print-file-remove')) return;
          this._selectedIndex = parseInt(item.dataset.index);
          this._renderFileList();
          this._updateButtons();
        });
      });

      // Remove button
      list.querySelectorAll('.print-file-remove').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          this._removeFile(parseInt(btn.dataset.index));
        });
      });
    }

    const totalPages = this.files.reduce((sum, f) => sum + (f.pages || 0), 0);
    this._sel('#merge-file-summary').textContent =
      this.files.length + ' 个文件，合并后 ' + totalPages + ' 页';
  }

  async _selectOutput() {
    const defaultName = this.files.length > 0
      ? this.files[0].name.replace(/\.pdf$/i, '') + '_合并.pdf'
      : 'merged.pdf';
    const path = await window.electronAPI.saveFileDialog(defaultName);
    if (path) {
      this._sel('#merge-output-path').value = path;
      this._updateButtons();
    }
  }

  _updateButtons() {
    const hasFiles = this.files.length >= 2;
    const hasOutput = !!this._sel('#merge-output-path').value;
    this._sel('#merge-btn-execute').disabled = !hasFiles || !hasOutput;

    const hasSelection = this._selectedIndex >= 0 && this._selectedIndex < this.files.length;
    this._sel('#merge-move-up').disabled = !hasSelection || this._selectedIndex <= 0;
    this._sel('#merge-move-down').disabled = !hasSelection || this._selectedIndex >= this.files.length - 1;
    this._sel('#merge-remove-selected').disabled = !hasSelection;
  }

  async _executeMerge() {
    this._sel('#merge-btn-execute').disabled = true;
    this._sel('#merge-status-text').textContent = '正在合并...';

    try {
      const filePaths = this.files.map(f => f.path);
      const outputPath = this._sel('#merge-output-path').value;
      const result = await window.electronAPI.mergePDFs(filePaths, outputPath);
      this._sel('#merge-status-text').textContent = '合并完成（' + result.totalPages + ' 页）';
      document.getElementById('status-text').textContent = '合并完成: ' + outputPath.split(/[\\/]/).pop();
    } catch (e) {
      this._sel('#merge-status-text').textContent = '合并失败: ' + e.message;
      this._sel('#merge-btn-execute').disabled = false;
    }
  }
}
