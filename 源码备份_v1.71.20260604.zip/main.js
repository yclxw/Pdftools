const { app, BrowserWindow, dialog, Menu, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const { execFile } = require('child_process');
const { PDFDocument, PageSizes, StandardFonts, rgb, degrees } = require('pdf-lib');

const pkg = require('./package.json');

let logPath = '';
function log(msg) {
  try {
    if (!logPath) {
      const userData = app.getPath('userData');
      logPath = path.join(userData, 'app.log');
    }
    const line = `[${new Date().toISOString()}] ${msg}\n`;
    fs.appendFileSync(logPath, line);
  } catch (_) {}
  console.log(msg);
}

let mainWindow;
let pendingFile = null;

// Helper: run PowerShell with UTF-16LE input; force PowerShell to output UTF-8
function runPowerShell(cmd, opts, callback) {
  const fullCmd = '$OutputEncoding = [Console]::OutputEncoding = [Text.Encoding]::UTF8; ' + cmd;
  const encoded = Buffer.from(fullCmd, 'utf16le').toString('base64');
  if (callback) {
    return execFile('powershell', ['-NoProfile', '-EncodedCommand', encoded], opts, callback);
  }
  return execFile('powershell', ['-NoProfile', '-EncodedCommand', encoded], opts);
}

function createWindow() {
  log('Creating main window...');
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 800,
    minHeight: 600,
    title: 'PDF发票打印工具 for Win7',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'))
    .then(() => log('Main window loaded successfully'))
    .catch(err => log('Failed to load main window: ' + err.message));

  mainWindow.webContents.on('did-fail-load', (_, code, desc) => {
    log(`Page load failed: ${code} - ${desc}`);
  });

  mainWindow.webContents.on('console-message', (_, level, message) => {
    log(`[Renderer] ${message}`);
  });

  const menuTemplate = [
    {
      label: '阅读',
      click: () => sendToRenderer('menu:openPdf')
    },
    {
      label: '打印',
      click: () => sendToRenderer('menu:printPanel')
    },
    {
      label: '拆分',
      click: () => sendToRenderer('menu:splitPanel')
    },
    {
      label: '合并',
      click: () => sendToRenderer('menu:mergePanel')
    },
    {
      label: '视图',
      submenu: [
        {
          label: '适应宽度',
          accelerator: 'CmdOrCtrl+1',
          click: () => sendToRenderer('view:fitWidth')
        },
        {
          label: '适应页面',
          accelerator: 'CmdOrCtrl+2',
          click: () => sendToRenderer('view:fitPage')
        },
        {
          label: '实际大小',
          accelerator: 'CmdOrCtrl+3',
          click: () => sendToRenderer('view:actualSize')
        },
        { type: 'separator' },
        { label: '放大', accelerator: 'CmdOrCtrl+=', click: () => sendToRenderer('view:zoomIn') },
        { label: '缩小', accelerator: 'CmdOrCtrl+-', click: () => sendToRenderer('view:zoomOut') },
        { type: 'separator' },
        { label: '切换开发者工具', role: 'toggleDevTools' }
      ]
    },
    {
      label: '帮助',
      submenu: [
        {
          label: '设为默认软件',
          click: () => setAsDefaultPdfViewer()
        },
        { type: 'separator' },
        {
          label: '关于',
          click: () => {
            const ver = pkg.version.split('.');
            const dateStr = ver.length === 3 ? `${ver[2].slice(0,4)}-${ver[2].slice(4,6)}-${ver[2].slice(6,8)}` : '';
            const shortVer = ver.length >= 2 ? `v${ver[0]}.${ver[1]}` : `v${pkg.version}`;
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: '关于 PDF发票打印工具 for Win7',
              message: 'PDF发票打印工具 for Win7',
              detail: `版本: ${shortVer}\n日期: ${dateStr}\n平台: Windows 7 SP1 x64+ / Windows 11\n作者: 帅气的锅巴`
            });
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(menuTemplate);
  Menu.setApplicationMenu(menu);
}

function sendToRenderer(channel, ...args) {
  if (mainWindow && mainWindow.webContents) {
    mainWindow.webContents.send(channel, ...args);
  }
}

function setAsDefaultPdfViewer() {
  if (!app.isPackaged) {
    dialog.showMessageBox(mainWindow, {
      type: 'warning', title: '开发模式',
      message: '设为默认软件仅在安装后的打包版本中生效。'
    });
    return;
  }

  const appExe = app.getPath('exe');
  const appName = 'PDF发票打印工具 for Win7.exe';
  const openCmd = '\\"' + appExe + '\\" \\"%1\\"';
  const appReg = 'HKCU\\Software\\Classes\\Applications\\' + appName;

  // Step 1: Register app in Windows "Open With" list via registry
  const tasks = [
    // Register app command and friendly name for "Open With" dialog
    ['add', appReg + '\\shell\\open\\command', '/ve', '/d', openCmd, '/f'],
    ['add', appReg, '/v', 'FriendlyAppName', '/d', 'PDF发票打印工具 for Win7', '/f'],
    // Also set ProgID for proper file type display
    ['add', 'HKCU\\Software\\Classes\\Pdftools.pdf', '/ve', '/d', 'PDF发票打印工具 for Win7 文档', '/f'],
    ['add', 'HKCU\\Software\\Classes\\Pdftools.pdf\\DefaultIcon', '/ve', '/d', appExe + ',0', '/f'],
    ['add', 'HKCU\\Software\\Classes\\Pdftools.pdf\\shell\\open\\command', '/ve', '/d', openCmd, '/f'],
    // Set .pdf → ProgID at HKCU level (backup to UserChoice)
    ['add', 'HKCU\\Software\\Classes\\.pdf', '/ve', '/d', 'Pdftools.pdf', '/f'],
    // Also try HKLM for system-wide (admin needed, ignore errors)
    ['add', 'HKLM\\SOFTWARE\\Classes\\Applications\\' + appName + '\\shell\\open\\command', '/ve', '/d', openCmd, '/f'],
  ];

  let done = 0;
  let errors = [];
  for (const args of tasks) {
    execFile('reg', args, { windowsHide: true }, (err) => {
      if (err) {
        if (!args[1].startsWith('HKLM')) {
          errors.push(args[1]);
        }
        log('Reg: ' + err.message);
      }
      done++;
      if (done === tasks.length) {
        if (errors.length > 0) {
          log(`设为默认软件: 部分注册失败 (${errors.length}/${tasks.length})`);
        }
        openWithDialog();
      }
    });
  }

  function openWithDialog() {
    const tempPdf = path.join(app.getPath('temp'), '_pdftools_default_temp.pdf');
    const minPdf = Buffer.from(
      '%PDF-1.0\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n' +
      '2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n' +
      '3 0 obj<</Type/Page/MediaBox[0 0 612 792]/Parent 2 0 R>>endobj\n' +
      'xref\n0 4\n0000000000 65535 f \n0000000009 00000 n \n0000000058 00000 n \n0000000115 00000 n \n' +
      'trailer<</Size 4/Root 1 0 R>>\nstartxref\n190\n%%EOF',
      'ascii'
    );
    try {
      fs.writeFileSync(tempPdf, minPdf);
      execFile('rundll32', ['shell32.dll,OpenAs_RunDLL', tempPdf],
        { windowsHide: false }, (err) => {
          if (err) log('OpenWith: ' + err.message);
          setTimeout(() => { try { fs.unlinkSync(tempPdf); } catch (_) {} }, 10000);
        });
    } catch (e) {
      dialog.showErrorBox('错误', '无法启动关联设置。');
    }
    log('设为默认软件: OpenWith 对话框已打开');
  }
}

ipcMain.handle('dialog:openPdf', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: '打开PDF文件',
    filters: [{ name: 'PDF文件', extensions: ['pdf'] }],
    properties: ['openFile', 'multiSelections']
  });
  if (result.canceled) return [];
  return result.filePaths;
});

ipcMain.handle('dialog:selectInvoices', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: '选择发票文件进行拼版',
    filters: [{ name: 'PDF文件', extensions: ['pdf'] }],
    properties: ['openFile', 'multiSelections']
  });
  if (result.canceled) return [];
  return result.filePaths;
});

ipcMain.handle('fs:readFile', async (_, filePath) => {
  try {
    const buffer = fs.readFileSync(filePath);
    return buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
  } catch (e) {
    throw new Error(`读取文件失败: ${e.message}`);
  }
});

ipcMain.handle('fs:getFileInfo', async (_, filePath) => {
  try {
    const stat = fs.statSync(filePath);
    return {
      name: path.basename(filePath),
      path: filePath,
      size: stat.size
    };
  } catch (e) {
    throw new Error(`获取文件信息失败: ${e.message}`);
  }
});

// Open Windows printer properties dialog
ipcMain.handle('print:printerProperties', async (_, printerName) => {
  return new Promise((resolve, reject) => {
    const args = ['printui.dll,PrintUIEntry', '/p', '/n', printerName];
    execFile('rundll32', args, { timeout: 15000, windowsHide: false }, (err) => {
      if (err) {
        log(`Printer properties error: ${err.message}`);
        reject(new Error(`无法打开打印机属性: ${err.message}`));
      } else {
        resolve();
      }
    });
  });
});

// Get Windows printer list
ipcMain.handle('print:getPrinters', async () => {
  // Windows 7 and 8/8.1 do not have Get-Printer (requires Win8+/Server2012+ with PrintManagement).
  // On those systems, skip the PowerShell attempt entirely to avoid a 10s timeout.
  const winVersion = process.platform === 'win32' ? require('os').release().split('.').map(Number) : [];
  const isLegacyWindows = winVersion.length > 0 && winVersion[0] < 10; // NT 6.x = Win7/8/8.1

  if (isLegacyWindows) {
    return getPrintersViaWmic();
  }

  return new Promise((resolve) => {
    runPowerShell(
      '(Get-Printer | Select-Object -ExpandProperty Name) -join "|"',
      { timeout: 10000, windowsHide: true }, (err, stdout) => {
        if (err) {
          getPrintersViaWmic().then(resolve);
          return;
        }
        const printers = stdout.trim().split('|').filter(Boolean);
        resolve(printers);
      });
  });
});

function getPrintersViaWmic() {
  return new Promise((resolve) => {
    execFile('wmic', ['printer', 'get', 'name'], { timeout: 10000, windowsHide: true, encoding: 'buffer' }, (err, stdout) => {
      if (err) { resolve([]); return; }
      let text;
      try {
        text = new TextDecoder('utf-8', { fatal: true }).decode(stdout);
      } catch {
        try {
          text = new TextDecoder('gbk').decode(stdout);
        } catch {
          text = stdout.toString('utf-8');
        }
      }
      const printers = [];
      const lines = text.split('\r\n');
      for (let i = 0; i < lines.length; i++) {
        const l = lines[i].trim();
        if (l && l !== 'Name' && !l.startsWith('===')) printers.push(l);
      }
      resolve(printers);
    });
  });
}

// Get SumatraPDF.exe path
// Priority: same directory as exe → extraResources → dev directory
function getSumatraPath() {
  const exeDir = app.isPackaged ? path.dirname(app.getPath('exe')) : __dirname;
  const candidates = [
    path.join(exeDir, 'SumatraPDF.exe'),
    path.join(exeDir, 'SumatraPDF', 'SumatraPDF.exe'),
    path.join(process.resourcesPath, 'SumatraPDF.exe'),
    path.join(process.resourcesPath, 'SumatraPDF', 'SumatraPDF.exe'),
  ];
  for (const p of candidates) {
    log(`Search SumatraPDF: ${p}`);
    if (fs.existsSync(p)) return p;
  }
  log('SumatraPDF.exe not found in any candidate path');
  return candidates[0];
}

// Imposition engine: 2-in-1 vector imposition using pdf-lib
// All files (single or multiple) use the same 2-in-1 A4 layout with configurable margins.
// Each invoice is scaled to fit the available width; height scales proportionally.
async function runImposition(filePaths, options = {}) {
  const outputDoc = await PDFDocument.create();

  const A4_WIDTH = PageSizes.A4[0];   // 595.28
  const A4_HEIGHT = PageSizes.A4[1];  // 841.89
  const marginCm = options.marginCm != null ? options.marginCm : 1.0;
  const MARGIN = marginCm * 28.35;    // cm to points
  const availWidth = A4_WIDTH - 2 * MARGIN;
  const availHeight = A4_HEIGHT - 2 * MARGIN;
  const halfHeight = availHeight / 2;

  const font = await outputDoc.embedFont(StandardFonts.Helvetica);

  for (let i = 0; i < filePaths.length; i += 2) {
    const page = outputDoc.addPage([A4_WIDTH, A4_HEIGHT]);

    // Top half - first invoice (fills top, bottom-aligns to center line)
    const topY = MARGIN + halfHeight;
    await _embedInvoice(outputDoc, page, filePaths[i], font, MARGIN, topY, availWidth, halfHeight, 'top');

    // Bottom half - second invoice if exists (fills bottom, top-aligns to center line)
    if (i + 1 < filePaths.length) {
      await _embedInvoice(outputDoc, page, filePaths[i + 1], font, MARGIN, MARGIN, availWidth, halfHeight, 'bottom');
    }
  }

  return await outputDoc.save();
}

async function _embedInvoice(outputDoc, targetPage, sourcePath, font, x, y, maxWidth, maxHeight, alignTo) {
  try {
    const srcBytes = fs.readFileSync(sourcePath);
    const srcDoc = await PDFDocument.load(srcBytes);
    const srcPages = srcDoc.getPages();
    if (srcPages.length === 0) return;

    const [embeddedPage] = await outputDoc.embedPdf(srcDoc, [0]);
    const dims = embeddedPage.size();
    const width = dims.width;
    const height = dims.height;
    if (!width || !height) return;

    // Scale to fit width; height scales proportionally (may overflow half-area)
    const fitScale = maxWidth / width;
    const drawW = width * fitScale;
    const drawH = height * fitScale;

    const drawX = x + (maxWidth - drawW) / 2;
    let drawY;
    if (alignTo === 'top') {
      drawY = y + maxHeight - drawH;
    } else if (alignTo === 'bottom') {
      drawY = y;
    } else {
      drawY = y + (maxHeight - drawH) / 2;
    }

    targetPage.drawPage(embeddedPage, {
      x: drawX,
      y: drawY,
      width: drawW,
      height: drawH
    });
  } catch (e) {
    log(`嵌入发票失败: ${e.message}`);
    targetPage.drawText('Error: ' + (e.message || '').replace(/[^\x00-\x7F]/g, ''), {
      x: x + 10,
      y: y + maxHeight / 2,
      size: 10,
      font: font,
      color: rgb(0.8, 0.2, 0.2)
    });
  }
}

// ============================================================
// Print mode: Invoice (发票模式)
// 2-in-1 imposition on A4, then silent print via SumatraPDF
// Supports multi-copy: imposition runs once, printed N times
// ============================================================
async function printInvoiceMode(filePaths, printerName, options = {}) {
  const copies = options.copies || 1;
  const totalPairs = Math.ceil(filePaths.length / 2);

  // Stage 1: Imposition (run once for all copies)
  // Use cached bytes from preview if available to avoid redundant work
  let pdfBytes;
  if (options._cachedPdfBytes) {
    log(`[Invoice] Using cached preview bytes, skipping re-imposition`);
    pdfBytes = Buffer.from(options._cachedPdfBytes);
    sendToRenderer('print:progress', {
      stage: 'imposition',
      current: totalPairs,
      total: totalPairs,
      message: copies > 1 ? `将打印 ${copies} 份...` : '正在准备打印...'
    });
  } else {
    sendToRenderer('print:progress', {
      stage: 'imposition',
      current: 0,
      total: totalPairs,
      message: `正在拼版 ${filePaths.length} 个文件...`
    });
    log(`[Invoice] Starting imposition for ${filePaths.length} files → ${totalPairs} A4 pages, ${copies} copies`);
    pdfBytes = await runImposition(filePaths, options);
    sendToRenderer('print:progress', {
      stage: 'imposition',
      current: totalPairs,
      total: totalPairs,
      message: copies > 1 ? `拼版完成，将打印 ${copies} 份...` : '拼版完成，正在准备打印...'
    });
  }

  // Stage 2: Write temp PDF
  const tempDir = app.getPath('temp');
  const tempPdfPath = path.join(tempDir, `invoice_print_${Date.now()}.pdf`);
  fs.writeFileSync(tempPdfPath, Buffer.from(pdfBytes));
  log(`[Invoice] Temp PDF written: ${tempPdfPath}`);

  // Stage 3: Print N copies via SumatraPDF
  for (let copy = 1; copy <= copies; copy++) {
    if (copies > 1) {
      sendToRenderer('print:progress', {
        stage: 'printing',
        current: copy,
        total: copies,
        message: `正在打印第 ${copy}/${copies} 份...`
      });
    } else {
      sendToRenderer('print:progress', {
        stage: 'printing',
        current: 0,
        total: 1,
        message: '正在发送到打印机...'
      });
    }

    log(`[Invoice] Printing copy ${copy}/${copies} → "${printerName}"`);
    await _sumatraPrint(tempPdfPath, printerName, copy === copies);
  }

  sendToRenderer('print:progress', {
    stage: 'done',
    current: copies,
    total: copies,
    message: `打印完成（共 ${copies} 份）`
  });
  log(`[Invoice] Complete: ${copies} copies printed`);
}

// ============================================================
// Print mode: Document (文件模式)
// Direct print without imposition, supports multi-copy, batch,
// auto-rotate and portrait/landscape orientation
// ============================================================
async function printDocumentMode(filePaths, printerName, options = {}) {
  const copies = options.copies || 1;
  const results = { success: [], failed: [], totalFiles: filePaths.length, totalCopies: 0 };

  for (let fi = 0; fi < filePaths.length; fi++) {
    const fp = filePaths[fi];
    const fileName = path.basename(fp);

    // Pre-process: apply page orientation if needed
    let printPath = fp;
    let tempPath = null;
    const needsTransform = options.pageOrientation && options.pageOrientation !== 'auto';

    if (needsTransform) {
      try {
        const pdfBytes = await applyPrintSettings(fp, options);
        tempPath = path.join(app.getPath('temp'), `doc_transformed_${Date.now()}_${fi}.pdf`);
        fs.writeFileSync(tempPath, Buffer.from(pdfBytes));
        printPath = tempPath;
        log(`[Document] Transformed "${fileName}": pageOrientation=${options.pageOrientation}, paperOrientation=${options.paperOrientation}`);
      } catch (e) {
        log(`[Document] Transform failed for "${fileName}": ${e.message}, using original`);
        // Fall back to original file if transform fails
      }
    }

    for (let ci = 0; ci < copies; ci++) {
      results.totalCopies++;
      const copyLabel = copies > 1 ? ` (第${ci + 1}/${copies}份)` : '';
      const progressTotal = filePaths.length * copies;
      const progressCurrent = fi * copies + ci + 1;

      sendToRenderer('print:progress', {
        stage: 'printing',
        current: progressCurrent,
        total: progressTotal,
        message: `正在打印 ${fileName}${copyLabel} (${progressCurrent}/${progressTotal})`
      });

      log(`[Document] Printing "${fileName}" copy ${ci + 1}/${copies} → "${printerName}"`);

      try {
        await _sumatraPrint(printPath, printerName, false);
      } catch (e) {
        log(`[Document] Print failed for "${fileName}": ${e.message}`);
        results.failed.push({ path: fp, name: fileName, error: e.message });
        // Clean up temp file on error
        if (tempPath) { try { fs.unlinkSync(tempPath); } catch (_) {} }
        if (!options.continueOnError) {
          sendToRenderer('print:progress', {
            stage: 'done',
            current: progressCurrent,
            total: progressTotal,
            message: `打印中断：成功 ${results.success.length}，失败 ${results.failed.length}`
          });
          throw new Error(`打印 "${fileName}" 失败: ${e.message}`);
        }
        continue;
      }
      results.success.push(fp);
    }

    // Clean up temp file after all copies of this file
    if (tempPath) {
      try { fs.unlinkSync(tempPath); } catch (_) {}
      tempPath = null;
    }
  }

  // Final progress report
  sendToRenderer('print:progress', {
    stage: 'done',
    current: results.totalCopies,
    total: results.totalCopies,
    message: `打印完成：成功 ${results.success.length}，失败 ${results.failed.length}`
  });

  log(`[Document] Batch complete: ${results.success.length} OK, ${results.failed.length} failed`);
  return results;
}

// Helper: parse page range string like "1-3,5,7-9" into array of page numbers
function parsePageRange(rangeStr, totalPages) {
  if (!rangeStr || rangeStr.trim() === '') {
    return Array.from({ length: totalPages }, (_, i) => i + 1);
  }

  const pages = new Set();
  const parts = rangeStr.split(',').map(p => p.trim()).filter(p => p);

  for (const part of parts) {
    if (part.includes('-')) {
      // Range like "1-3"
      const [start, end] = part.split('-').map(n => parseInt(n.trim()));
      if (!isNaN(start) && !isNaN(end)) {
        const from = Math.max(1, Math.min(start, end));
        const to = Math.min(totalPages, Math.max(start, end));
        for (let i = from; i <= to; i++) {
          pages.add(i);
        }
      }
    } else {
      // Single page like "5"
      const pageNum = parseInt(part);
      if (!isNaN(pageNum) && pageNum >= 1 && pageNum <= totalPages) {
        pages.add(pageNum);
      }
    }
  }

  return Array.from(pages).sort((a, b) => a - b);
}

// Helper: extract specific pages from PDF document
async function extractPages(srcDoc, pageNumbers) {
  const newDoc = await PDFDocument.create();
  const indices = pageNumbers.map(n => n - 1); // Convert to 0-based index
  const pages = await newDoc.copyPages(srcDoc, indices);
  pages.forEach(p => newDoc.addPage(p));
  return newDoc;
}

// ============================================================
// Apply print settings: page orientation + page range filtering
// Uses pdf-lib to rotate pages and extract page ranges before printing
// ============================================================
async function applyPrintSettings(filePath, options = {}) {
  log(`[applyPrintSettings] file=${path.basename(filePath)}, pageOrientation=${options.pageOrientation}, paperOrientation=${options.paperOrientation}, pageRangeMode=${options.pageRangeMode}, pageRangeValue=${options.pageRangeValue}`);

  const srcBytes = fs.readFileSync(filePath);
  let srcDoc = await PDFDocument.load(srcBytes);
  let pages = srcDoc.getPages();

  log(`[applyPrintSettings] Loaded ${pages.length} pages`);

  // Step 1: Apply page range filtering if needed
  if (options.pageRangeMode === 'custom' && options.pageRangeValue) {
    const totalPages = pages.length;
    const selectedPages = parsePageRange(options.pageRangeValue, totalPages);
    
    if (selectedPages.length === 0) {
      log(`[applyPrintSettings] No valid pages in range, using all pages`);
    } else if (selectedPages.length < totalPages) {
      log(`[applyPrintSettings] Extracting pages: ${selectedPages.join(', ')} (${selectedPages.length}/${totalPages})`);
      srcDoc = await extractPages(srcDoc, selectedPages);
      pages = srcDoc.getPages();
      log(`[applyPrintSettings] After extraction: ${pages.length} pages`);
    } else {
      log(`[applyPrintSettings] All pages selected, no extraction needed`);
    }
  }

  // Determine if page rotation is needed based on pageOrientation setting
  const pageOrientValue = options.pageOrientation || 'auto';
  
  if (pageOrientValue === 'auto') {
    log(`[applyPrintSettings] Page orientation is auto, no rotation needed`);
    return await srcDoc.save(); // No changes needed
  }

  const targetPageIsLandscape = pageOrientValue === 'landscape';
  log(`[applyPrintSettings] Target page orientation: ${targetPageIsLandscape ? 'landscape' : 'portrait'}`);

  for (let i = 0; i < pages.length; i++) {
    const page = pages[i];
    const { width, height } = page.getSize();
    if (!width || !height) {
      log(`[applyPrintSettings] Page ${i + 1}: invalid size, skipping`);
      continue;
    }

    const isLandscape = width > height;
    let currentRotation = 0;
    try {
      const rot = page.getRotation();
      currentRotation = rot ? rot.angle : 0;
    } catch (e) {
      currentRotation = 0;
    }

    log(`[applyPrintSettings] Page ${i + 1}: ${width}x${height}, landscape=${isLandscape}, currentRotation=${currentRotation}`);

    // Check if rotation is needed
    if (isLandscape !== targetPageIsLandscape) {
      // Calculate new rotation: add 90 degrees to current rotation
      const newRotation = (currentRotation + 90) % 360;
      
      // Ensure newRotation is a multiple of 90
      const normalizedRotation = Math.round(newRotation / 90) * 90;
      
      page.setRotation(degrees(normalizedRotation));
      log(`[applyPrintSettings] Page ${i + 1}: rotated from ${isLandscape ? 'landscape' : 'portrait'} to ${targetPageIsLandscape ? 'landscape' : 'portrait'}, rotation: ${currentRotation}° → ${normalizedRotation}°`);
    } else {
      log(`[applyPrintSettings] Page ${i + 1}: already in desired orientation (${targetPageIsLandscape ? 'landscape' : 'portrait'})`);
    }
  }

  const result = await srcDoc.save();
  log(`[applyPrintSettings] Saved: ${result.length} bytes`);
  return result;
}

// ============================================================
// SumatraPDF silent print executor
// Always uses silent mode: -print-to <printer> -exit-when-done -silent
// ============================================================
async function _sumatraPrint(pdfPath, printerName, cleanupTemp = false) {
  const sumatraPath = getSumatraPath();
  if (!fs.existsSync(sumatraPath)) {
    throw new Error(
      `未找到 SumatraPDF.exe\n请将 SumatraPDF.exe 放置在:\n${path.dirname(sumatraPath)}`
    );
  }

  return new Promise((resolve, reject) => {
    const args = ['-print-to', printerName, '-exit-when-done', '-silent', pdfPath];
    log(`[Sumatra] Silent print to "${printerName}": ${path.basename(pdfPath)}`);

    execFile(sumatraPath, args, {
      timeout: 120000,
      windowsHide: true
    }, (err) => {
      // Clean up temp file if requested (last copy)
      if (cleanupTemp) {
        try { fs.unlinkSync(pdfPath); } catch (_) {}
      }

      if (err) {
        log(`[Sumatra] Error: ${err.message}`);
        reject(new Error(`打印失败: ${err.message}`));
      } else {
        log('[Sumatra] OK');
        resolve();
      }
    });
  });
}

// Main print IPC handler: route by mode
ipcMain.handle('print:executePrint', async (_, filePaths, printerName, options = {}) => {
  try {
    log(`Print: mode=${options.mode || 'invoice'}, files=${filePaths.length}, printer="${printerName}", copies=${options.copies || 1}`);

    if (options.mode === 'document') {
      return await printDocumentMode(filePaths, printerName, options);
    } else {
      // Default: invoice mode (backward compatible)
      return await printInvoiceMode(filePaths, printerName, options);
    }
  } catch (e) {
    log(`Print pipeline error: ${e.message}`);
    sendToRenderer('print:progress', {
      stage: 'error',
      message: e.message
    });
    throw e;
  }
});

// ============================================================
// PDF split: extract pages into separate PDF files
// ============================================================
ipcMain.handle('pdf:split', async (_, filePath, ranges, outputDir) => {
  log(`[Split] Splitting "${path.basename(filePath)}" into ${ranges.length} parts`);
  const srcBytes = fs.readFileSync(filePath);
  const srcDoc = await PDFDocument.load(srcBytes);
  const results = [];

  for (let i = 0; i < ranges.length; i++) {
    const [start, end] = ranges[i];
    const newDoc = await PDFDocument.create();
    const indices = Array.from(
      { length: end - start + 1 },
      (_, idx) => start - 1 + idx
    );
    const pages = await newDoc.copyPages(srcDoc, indices);
    pages.forEach(p => newDoc.addPage(p));

    const outBytes = await newDoc.save();
    const baseName = path.basename(filePath, '.pdf');
    const outPath = path.join(outputDir, `${baseName}_part${i + 1}.pdf`);
    fs.writeFileSync(outPath, Buffer.from(outBytes));
    results.push({ path: outPath, pages: indices.length });
    log(`[Split] Part ${i + 1}: ${outPath} (pages ${start}-${end})`);
  }

  return results;
});

// ============================================================
// PDF merge: combine multiple PDFs into one
// ============================================================
ipcMain.handle('pdf:merge', async (_, filePaths, outputPath) => {
  log(`[Merge] Merging ${filePaths.length} files → "${path.basename(outputPath)}"`);
  const mergedDoc = await PDFDocument.create();

  for (const fp of filePaths) {
    const srcBytes = fs.readFileSync(fp);
    const srcDoc = await PDFDocument.load(srcBytes);
    const pages = await mergedDoc.copyPages(srcDoc, srcDoc.getPageIndices());
    pages.forEach(p => mergedDoc.addPage(p));
  }

  const outBytes = await mergedDoc.save();
  fs.writeFileSync(outputPath, Buffer.from(outBytes));
  const totalPages = mergedDoc.getPageCount();
  log(`[Merge] Complete: ${outputPath} (${totalPages} pages)`);

  return { outputPath, totalPages };
});

// ============================================================
// PDF info: get page count and file size
// ============================================================
ipcMain.handle('pdf:getInfo', async (_, filePath) => {
  try {
    const stat = fs.statSync(filePath);
    const srcBytes = fs.readFileSync(filePath);
    const srcDoc = await PDFDocument.load(srcBytes);
    return {
      name: path.basename(filePath),
      path: filePath,
      size: stat.size,
      pages: srcDoc.getPageCount()
    };
  } catch (e) {
    throw new Error(`获取PDF信息失败: ${e.message}`);
  }
});

// ============================================================
// Directory selection dialog
// ============================================================
ipcMain.handle('dialog:selectDirectory', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: '选择输出目录',
    properties: ['openDirectory', 'createDirectory']
  });
  if (result.canceled || result.filePaths.length === 0) return null;
  return result.filePaths[0];
});

// ============================================================
// Save file dialog
// ============================================================
ipcMain.handle('dialog:saveFile', async (_, defaultName) => {
  const result = await dialog.showSaveDialog(mainWindow, {
    title: '保存合并后的PDF',
    defaultPath: defaultName || 'merged.pdf',
    filters: [{ name: 'PDF文件', extensions: ['pdf'] }]
  });
  if (result.canceled) return null;
  return result.filePath;
});

// ============================================================
// Preview: generate PDF bytes for preview in renderer
// ============================================================
// Helper: convert Uint8Array/Buffer to a clean ArrayBuffer for IPC transfer
function toArrayBuffer(data) {
  // Ensure we have a Buffer/Uint8Array with byteOffset 0 for clean transfer
  const buf = Buffer.from(data);
  return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
}

ipcMain.handle('print:generatePreview', async (_, filePaths, options = {}) => {
  log(`[Preview] mode=${options.mode || 'invoice'}, files=${filePaths.length}, pageOrientation=${options.pageOrientation}, paperOrientation=${options.paperOrientation}`);

  if (!filePaths || filePaths.length === 0) {
    throw new Error('没有选择文件');
  }

  let pdfBytes;
  if (options.mode === 'document') {
    // Document mode: preprocess all files and merge for preview
    const needsTransform = options.pageOrientation && options.pageOrientation !== 'auto';
    log(`[Preview] needsTransform=${needsTransform}`);

    if (filePaths.length === 1 && !needsTransform) {
      // Single file, no transform needed: read directly
      pdfBytes = fs.readFileSync(filePaths[0]);
      log(`[Preview] Direct read: ${pdfBytes.length} bytes`);
    } else {
      // Multiple files or transform needed: build merged preview doc
      const previewDoc = await PDFDocument.create();
      let addedPages = 0;
      for (const fp of filePaths) {
        let fileBytes;
        try {
          if (needsTransform) {
            log(`[Preview] Applying transform to: ${path.basename(fp)}`);
            fileBytes = Buffer.from(await applyPrintSettings(fp, options));
            log(`[Preview] Transform result: ${fileBytes.length} bytes`);
          } else {
            fileBytes = fs.readFileSync(fp);
          }
          const srcDoc = await PDFDocument.load(fileBytes);
          const pageIndices = srcDoc.getPageIndices();
          log(`[Preview] Source has ${pageIndices.length} pages`);
          const pages = await previewDoc.copyPages(srcDoc, pageIndices);
          pages.forEach(p => previewDoc.addPage(p));
          addedPages += pages.length;
        } catch (e) {
          log(`[Preview] Error processing "${path.basename(fp)}": ${e.message}`);
          // Continue with other files instead of failing completely
          continue;
        }
      }
      if (addedPages === 0) {
        throw new Error('没有可预览的页面');
      }
      pdfBytes = Buffer.from(await previewDoc.save());
      log(`[Preview] Merged PDF: ${pdfBytes.length} bytes, ${addedPages} pages`);
    }
    const infoDoc = await PDFDocument.load(pdfBytes);
    return {
      pdfBytes: toArrayBuffer(pdfBytes),
      totalPages: infoDoc.getPageCount()
    };
  } else {
    // Invoice mode: run imposition, return bytes
    pdfBytes = await runImposition(filePaths, options);
    const doc = await PDFDocument.load(pdfBytes);
    return {
      pdfBytes: toArrayBuffer(pdfBytes),
      totalPages: doc.getPageCount()
    };
  }
});

// 禁用GPU硬件加速，避免GPU进程崩溃导致启动无响应
app.disableHardwareAcceleration();

// Handle file association — open PDF from command line or double-click
function openPendingFile() {
  if (pendingFile && mainWindow) {
    const fp = pendingFile;
    pendingFile = null;
    if (fs.existsSync(fp)) {
      mainWindow.webContents.send('open-file', fp);
    }
  }
}

// Windows: file path passed via process.argv or second-instance
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
  app.quit();
} else {
  app.on('second-instance', (_, argv) => {
    const pdfArg = argv.find(a => a.toLowerCase().endsWith('.pdf'));
    if (pdfArg && fs.existsSync(pdfArg)) {
      if (mainWindow) {
        mainWindow.focus();
        mainWindow.webContents.send('open-file', pdfArg);
      } else {
        pendingFile = pdfArg;
      }
    }
  });
}

// Unified initialization: check argv for PDF, create window, then open file
app.whenReady().then(() => {
  const pdfArg = process.argv.find(a => a.toLowerCase().endsWith('.pdf'));
  if (pdfArg && fs.existsSync(pdfArg)) {
    pendingFile = pdfArg;
  }
  createWindow();
  // After window loads, send pending file
  mainWindow.webContents.on('did-finish-load', () => {
    openPendingFile();
  });
});

app.on('window-all-closed', () => {
  app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});
