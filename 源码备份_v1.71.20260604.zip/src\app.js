// ===== 应用入口 =====
(function () {
  // Initialize PDF.js worker and CMap for Chinese font support
  // Use absolute file:// path so CMap files resolve correctly inside asar
  // Prefer unpacked resources directory when packaged. Use resourcesPath exposed by preload.
  let resourcesPath = '';
  try {
    resourcesPath = window.electronAPI && window.electronAPI.getResourcesPath ? window.electronAPI.getResourcesPath() : '';
  } catch (e) { resourcesPath = ''; }

  if (resourcesPath) {
    const fileBase = 'file://' + resourcesPath + '/app.asar.unpacked/node_modules/pdfjs-dist';
    pdfjsLib.GlobalWorkerOptions.workerSrc = fileBase + '/build/pdf.worker.min.js';
    pdfjsLib.GlobalWorkerOptions.cMapUrl = fileBase + '/cmaps/';
    pdfjsLib.GlobalWorkerOptions.cMapPacked = true;
  } else {
    var baseUrl = window.location.href.replace(/\/src\/index\.html.*$/, '');
    pdfjsLib.GlobalWorkerOptions.workerSrc = baseUrl + '/node_modules/pdfjs-dist/build/pdf.worker.min.js';
    pdfjsLib.GlobalWorkerOptions.cMapUrl = baseUrl + '/node_modules/pdfjs-dist/cmaps/';
    pdfjsLib.GlobalWorkerOptions.cMapPacked = true;
  }

  // Initialize managers
  const tabManager = new TabManager();
  const printPanel = new PrintPanel();
  const splitPanel = new SplitPanel();
  const mergePanel = new MergePanel();

  // Wire print panel close → restore previous view
  printPanel.onClose = () => {
    if (tabManager.tabs.length === 0) {
      document.getElementById('welcome-screen').style.display = 'flex';
    } else {
      document.getElementById('viewer-container').style.display = 'block';
    }
  };

  // ===== Menu event listeners =====
  window.electronAPI.onOpenFile((filePath) => tabManager.openPdf(filePath));
  window.electronAPI.onMenuOpenPdf(() => tabManager.openPdfDialog());
  window.electronAPI.onMenuPrintPanel(() => {
    const filePaths = tabManager.tabs.map(t => t.filePath).filter(Boolean);
    printPanel.open(filePaths);
  });
  window.electronAPI.onMenuSplitPanel(() => {
    const activeTab = tabManager.getActiveTab();
    splitPanel.open(activeTab ? activeTab.filePath : null);
  });
  window.electronAPI.onMenuMergePanel(() => {
    mergePanel.open();
  });

  window.electronAPI.onViewFitWidth(() => {
    const tab = tabManager.getActiveTab();
    if (tab && tab.viewer) { tab.viewer.fitWidth(); updateZoomSelect(tab.scale); }
  });
  window.electronAPI.onViewFitPage(() => {
    const tab = tabManager.getActiveTab();
    if (tab && tab.viewer) { tab.viewer.fitPage(); updateZoomSelect(tab.scale); }
  });
  window.electronAPI.onViewActualSize(() => {
    const tab = tabManager.getActiveTab();
    if (tab && tab.viewer) { tab.viewer.actualSize(); updateZoomSelect(tab.scale); }
  });
  window.electronAPI.onViewZoomIn(() => {
    const tab = tabManager.getActiveTab();
    if (tab && tab.viewer) tab.viewer.zoomIn();
  });
  window.electronAPI.onViewZoomOut(() => {
    const tab = tabManager.getActiveTab();
    if (tab && tab.viewer) tab.viewer.zoomOut();
  });

  // ===== Toolbar buttons =====
  document.getElementById('btn-open').addEventListener('click', () => tabManager.openPdfDialog());
  document.getElementById('btn-print-panel').addEventListener('click', () => printPanel.open());

  // Split / Merge buttons
  document.getElementById('btn-split-panel').addEventListener('click', () => {
    const activeTab = tabManager.getActiveTab();
    splitPanel.open(activeTab ? activeTab.filePath : null);
  });
  document.getElementById('btn-merge-panel').addEventListener('click', () => {
    mergePanel.open();
  });

  document.getElementById('btn-zoom-in').addEventListener('click', () => {
    const tab = tabManager.getActiveTab();
    if (tab && tab.viewer) tab.viewer.zoomIn();
  });
  document.getElementById('btn-zoom-out').addEventListener('click', () => {
    const tab = tabManager.getActiveTab();
    if (tab && tab.viewer) tab.viewer.zoomOut();
  });

  document.getElementById('zoom-select').addEventListener('change', (e) => {
    const tab = tabManager.getActiveTab();
    if (!tab || !tab.viewer) return;

    const value = e.target.value;
    if (value === 'fit-width') {
      tab.viewer.fitWidth();
    } else if (value === 'fit-page') {
      tab.viewer.fitPage();
    } else {
      tab.viewer.setScale(parseFloat(value));
    }
    // Reset select to current scale
    updateZoomSelect(tab.scale);
  });

  document.getElementById('btn-prev').addEventListener('click', () => {
    const tab = tabManager.getActiveTab();
    if (tab && tab.viewer) tab.viewer.prevPage();
  });
  document.getElementById('btn-next').addEventListener('click', () => {
    const tab = tabManager.getActiveTab();
    if (tab && tab.viewer) tab.viewer.nextPage();
  });
  document.getElementById('page-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const tab = tabManager.getActiveTab();
      if (tab && tab.viewer) {
        const num = parseInt(e.target.value);
        if (!isNaN(num)) tab.viewer.goToPage(num);
      }
    }
  });

  // ===== Welcome screen buttons =====
  document.getElementById('welcome-open').addEventListener('click', () => tabManager.openPdfDialog());
  document.getElementById('welcome-print').addEventListener('click', () => printPanel.open());
  document.getElementById('welcome-split').addEventListener('click', () => {
    const activeTab = tabManager.getActiveTab();
    splitPanel.open(activeTab ? activeTab.filePath : null);
  });
  document.getElementById('welcome-merge').addEventListener('click', () => {
    mergePanel.open();
  });

  // ===== Drag and drop =====
  const contentArea = document.getElementById('content-area');

  function handleDragOver(e) {
    e.preventDefault();
    e.stopPropagation();
    e.dataTransfer.dropEffect = 'copy';
  }

  contentArea.addEventListener('dragover', handleDragOver);
  contentArea.addEventListener('drop', async (e) => {
    e.preventDefault();
    await handleDropFiles(e);
  });

  async function handleDropFiles(e) {
    const files = Array.from(e.dataTransfer.files);
    for (const file of files) {
      if (file.name.toLowerCase().endsWith('.pdf')) {
        await tabManager.openPdf(file.path);
      }
    }
  }

  // ===== Tab change handler =====
  tabManager.onTabChange = (tab) => {
    updateZoomSelect(tab.scale);
  };

  function updateZoomSelect(scale) {
    const select = document.getElementById('zoom-select');
    const pct = Math.round(scale * 100);
    // Only set to predefined values if they match
    const predefined = [50, 75, 100, 125, 150, 200];
    if (predefined.includes(pct)) {
      select.value = String(pct / 100);
    } else {
      select.value = ''; // custom value
    }
  }

  // ===== Keyboard shortcuts (global) =====
  document.addEventListener('keydown', (e) => {
    const tab = tabManager.getActiveTab();
    if (!tab || !tab.viewer) return;

    // Don't handle if focus is in an input
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;

    switch (e.key) {
      case 'PageDown':
        e.preventDefault();
        tab.viewer.nextPage();
        break;
      case 'PageUp':
        e.preventDefault();
        tab.viewer.prevPage();
        break;
      case 'Home':
        e.preventDefault();
        tab.viewer.goToPage(1);
        break;
      case 'End':
        e.preventDefault();
        tab.viewer.goToPage(tab.totalPages);
        break;
    }
  });

  // ===== Ctrl+MouseWheel zoom (throttled with accumulation) =====
  let wheelZoomTimeout;
  let wheelAccumDelta = 0;
  contentArea.addEventListener('wheel', (e) => {
    if (e.ctrlKey) {
      e.preventDefault();
      wheelAccumDelta += e.deltaY > 0 ? -0.05 : 0.05;
      if (wheelZoomTimeout) return; // Throttle: process after interval
      wheelZoomTimeout = setTimeout(() => {
        wheelZoomTimeout = null;
        const delta = wheelAccumDelta;
        wheelAccumDelta = 0;
        const tab = tabManager.getActiveTab();
        if (tab && tab.viewer) {
          tab.viewer.setScale(tab.scale + delta);
          updateZoomSelect(tab.scale);
        }
      }, 80);
    }
  }, { passive: false });

  // ===== Window resize → re-render for fit modes =====
  let resizeTimeout;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(() => {
      const tab = tabManager.getActiveTab();
      if (tab && tab.viewer && tab.viewer.scrollMode === 'continuous') {
        tab.viewer.renderCurrentPage();
      }
    }, 200);
  });

  document.getElementById('status-text').textContent = '就绪';
})();
