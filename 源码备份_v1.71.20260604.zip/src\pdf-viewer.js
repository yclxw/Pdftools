class PdfViewer {
  constructor(container, tab, onUpdate) {
    this.container = container;
    this.parentContainer = container.parentElement; // Explicit parent reference for size calculations
    this.tab = tab;
    this.onUpdate = onUpdate;
    this.canvases = [];
    this.scrollMode = 'continuous'; // 'continuous' or 'single'
    this._renderId = 0; // Incrementing ID to prevent race conditions
    this._scrollRenderId = 0; // Track scroll-triggered render vs programmatic scroll

    this._bindEvents();
  }

  renderCurrentPage() {
    if (!this.tab.pdfDoc) return;

    if (this.scrollMode === 'continuous') {
      this._renderAllPages();
    } else {
      this._renderSinglePage(this.tab.currentPage);
    }
  }

  async _renderAllPages() {
    this.container.innerHTML = '';
    this.canvases = [];

    const renderId = ++this._renderId;
    // Render first page immediately, then render rest lazily with requestAnimationFrame
    for (let i = 1; i <= this.tab.totalPages; i++) {
      if (renderId !== this._renderId) return; // Superseded by new render
      const canvas = document.createElement('canvas');
      canvas.dataset.pageNum = i;
      this.container.appendChild(canvas);
      this.canvases.push(canvas);
      if (i === 1) {
        // Render first page synchronously for immediate feedback
        await this._renderPageToCanvas(i, canvas);
      } else {
        // Defer remaining pages in batches to keep UI responsive
        await this._renderPageToCanvas(i, canvas);
        if (i % 5 === 0) {
          await new Promise(r => setTimeout(r, 0));
          if (renderId !== this._renderId) return;
        }
      }
    }

    // Scroll to current page after render
    if (this.tab.currentPage > 1 && this.canvases[this.tab.currentPage - 1]) {
      this._scrollRenderId++;
      const scrollId = this._scrollRenderId;
      setTimeout(() => {
        if (scrollId === this._scrollRenderId) {
          this.canvases[this.tab.currentPage - 1].scrollIntoView({ block: 'start' });
        }
      }, 50);
    }
  }

  async _renderSinglePage(pageNum) {
    this.container.innerHTML = '';
    this.canvases = [];

    const canvas = document.createElement('canvas');
    this.container.appendChild(canvas);
    this.canvases.push(canvas);
    await this._renderPageToCanvas(pageNum, canvas);
  }

  async _renderPageToCanvas(pageNum, canvas) {
    if (!this.tab.pdfDoc) return;

    try {
      const page = await this.tab.pdfDoc.getPage(pageNum);
      const viewport = page.getViewport({ scale: this.tab.scale });

      canvas.width = viewport.width;
      canvas.height = viewport.height;

      const ctx = canvas.getContext('2d');
      await page.render({
        canvasContext: ctx,
        viewport: viewport
      }).promise;
    } catch (e) {
      console.error(`渲染第${pageNum}页失败:`, e);
    }
  }

  setScale(scale) {
    this.tab.scale = Math.max(0.1, Math.min(5, scale));
    this.renderCurrentPage();
    if (this.onUpdate) this.onUpdate();
  }

  zoomIn() {
    this.setScale(this.tab.scale + 0.1);
  }

  zoomOut() {
    this.setScale(this.tab.scale - 0.1);
  }

  fitWidth() {
    if (!this.tab.pdfDoc) return;

    const parentWidth = (this.parentContainer || this.container.parentElement).clientWidth - 40;
    if (parentWidth <= 0) return;

    const renderId = ++this._renderId;
    // Get first page width at scale 1
    this.tab.pdfDoc.getPage(1).then(page => {
      if (renderId !== this._renderId) return; // Stale request, ignore
      const vp = page.getViewport({ scale: 1 });
      this.setScale(parentWidth / vp.width);
    });
  }

  fitPage() {
    if (!this.tab.pdfDoc) return;

    const parentHeight = (this.parentContainer || this.container.parentElement).clientHeight - 40;
    if (parentHeight <= 0) return;

    const renderId = ++this._renderId;
    this.tab.pdfDoc.getPage(1).then(page => {
      if (renderId !== this._renderId) return; // Stale request, ignore
      const vp = page.getViewport({ scale: 1 });
      this.setScale(parentHeight / vp.height);
    });
  }

  actualSize() {
    this.setScale(1);
  }

  nextPage() {
    if (this.tab.currentPage < this.tab.totalPages) {
      this.goToPage(this.tab.currentPage + 1);
    }
  }

  prevPage() {
    if (this.tab.currentPage > 1) {
      this.goToPage(this.tab.currentPage - 1);
    }
  }

  goToPage(pageNum) {
    const num = Math.max(1, Math.min(this.tab.totalPages, pageNum));
    if (num === this.tab.currentPage && this.scrollMode === 'single') return;

    this.tab.currentPage = num;

    if (this.scrollMode === 'single') {
      this.renderCurrentPage();
    } else if (this.canvases[num - 1]) {
      this.canvases[num - 1].scrollIntoView({ block: 'start' });
    }

    if (this.onUpdate) this.onUpdate();
  }

  setScrollMode(mode) {
    this.scrollMode = mode;
    this.renderCurrentPage();
  }

  _bindEvents() {
    // Track which page is currently visible during scroll
    let scrollTimeout;
    this.container.addEventListener('scroll', () => {
      if (this.scrollMode !== 'continuous' || this.canvases.length === 0) return;

      clearTimeout(scrollTimeout);
      scrollTimeout = setTimeout(() => {
        this._updateCurrentPageFromScroll();
      }, 100);
    });
  }

  _updateCurrentPageFromScroll() {
    const containerRect = this.container.getBoundingClientRect();
    const containerCenter = containerRect.top + containerRect.height * 0.3;

    let closestPage = 1;
    let closestDist = Infinity;

    for (const canvas of this.canvases) {
      const rect = canvas.getBoundingClientRect();
      const dist = Math.abs(rect.top - containerCenter);
      if (dist < closestDist && rect.top < containerRect.bottom && rect.bottom > containerRect.top) {
        closestDist = dist;
        closestPage = parseInt(canvas.dataset.pageNum);
      }
    }

    if (closestPage !== this.tab.currentPage) {
      this.tab.currentPage = closestPage;
      if (this.onUpdate) this.onUpdate();
    }
  }

  destroy() {
    this.container.innerHTML = '';
    this.canvases = [];
  }
}
