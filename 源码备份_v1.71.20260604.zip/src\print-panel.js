class PrintPanel {
  constructor() {
    this.files = [];
    this.mode = 'invoice';
    this.batchResults = null;
    this.previewCache = null;
    this._previewPage = 0;
    this._previewTotalPages = 0;
    this.onClose = null;  // callback when workspace is closed
    this._previewDebounceTimer = null;  // debounce timer for auto preview

    this.workspace = document.getElementById('print-workspace');
    this.dropZone = document.getElementById('print-drop-zone');
    this.fileList = document.getElementById('print-file-list');
    this.fileCount = document.getElementById('print-file-count');
    this.printerSelect = document.getElementById('printer-select');
    this.btnPrintProps = document.getElementById('btn-print-properties');
    this.btnPrint = document.getElementById('btn-print-start');
    this.btnPreview = document.getElementById('btn-print-preview');
    this.statusText = document.getElementById('print-status-text');
    this.progressBar = document.getElementById('print-progress-bar');
    this.progressFill = document.getElementById('print-progress-fill');
    this.queueSection = document.getElementById('print-queue-section');

    // Preview area
    this.previewArea = document.getElementById('print-preview-area');
    this.previewPlaceholder = document.querySelector('.preview-placeholder');
    this.previewCanvas = document.getElementById('print-preview-canvas');
    this.previewPrevBtn = document.getElementById('preview-page-prev');
    this.previewNextBtn = document.getElementById('preview-page-next');
    this.previewPageNum = document.getElementById('preview-page-num');
    this.previewTotal = document.getElementById('preview-total-pages');

    // Mode switch
    this.modeInvoiceBtn = document.getElementById('print-mode-invoice');
    this.modeDocumentBtn = document.getElementById('print-mode-document');

    // Invoice settings
    this.settingsInvoice = document.getElementById('print-settings-invoice');
    this.marginSlider = document.getElementById('print-margin-slider');
    this.marginValue = document.getElementById('print-margin-value');
    this.copiesInvoice = document.getElementById('print-copies-invoice');

    // Document settings
    this.settingsDocument = document.getElementById('print-settings-document');
    this.copiesDocument = document.getElementById('print-copies-document');
    this.continueCheck = document.getElementById('print-continue-check');
    
    // Page range settings
    this.pageRangeRadios = document.querySelectorAll('input[name="pageRange"]');
    this.pageRangeInput = document.getElementById('print-page-range-input');
    this._pageRangeMode = 'all'; // 'all' or 'custom'
    this._pageRangeValue = '';

    // Batch result
    this.batchResult = document.getElementById('print-batch-result');

    this._bindEvents();
  }

  _bindEvents() {
    document.getElementById('print-workspace-close').addEventListener('click', () => this.hide());
    document.getElementById('btn-print-cancel').addEventListener('click', () => this.hide());
    document.getElementById('btn-select-files').addEventListener('click', () => this._selectFiles());
    document.getElementById('btn-refresh-printers').addEventListener('click', () => this._refreshPrinters());
    this.btnPrintProps.addEventListener('click', () => this._openPrinterProperties());
    this.printerSelect.addEventListener('change', () => this._updateButtons());

    this.btnPrint.addEventListener('click', () => this._startPrint());
    this.btnPreview.addEventListener('click', () => {
      // Manual refresh: clear cache and regenerate preview
      this.previewCache = null;
      this._showPreview();
    });

    this.modeInvoiceBtn.addEventListener('click', () => this._setMode('invoice'));
    this.modeDocumentBtn.addEventListener('click', () => this._setMode('document'));

    this.marginSlider.addEventListener('input', () => {
      this.marginValue.textContent = parseFloat(this.marginSlider.value).toFixed(1) + ' cm';
      this.previewCache = null;
      // Auto preview when margin changes
      this._triggerAutoPreview();
    });
    
    // Orientation buttons - Page orientation
    this.pageOrientationButtons = document.querySelectorAll('.orientation-btn[data-type="page"]');
    this._pageOrientation = 'auto';
    this.pageOrientationButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        this.pageOrientationButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this._pageOrientation = btn.dataset.value;
        this.previewCache = null;
        // Auto preview when page orientation changes
        this._triggerAutoPreview();
      });
    });
    
    // Orientation buttons - Paper orientation
    this.paperOrientationButtons = document.querySelectorAll('.orientation-btn[data-type="paper"]');
    this._paperOrientation = 'auto';
    this.paperOrientationButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        this.paperOrientationButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this._paperOrientation = btn.dataset.value;
        this.previewCache = null;
        // Auto preview when paper orientation changes
        this._triggerAutoPreview();
      });
    });
    
    // Page range radio buttons
    this.pageRangeRadios.forEach(radio => {
      radio.addEventListener('change', () => {
        this._pageRangeMode = radio.value;
        if (radio.value === 'custom') {
          this.pageRangeInput.disabled = false;
          this.pageRangeInput.focus();
        } else {
          this.pageRangeInput.disabled = true;
          this._pageRangeValue = '';
        }
        this.previewCache = null;
        // Auto preview when page range mode changes
        this._triggerAutoPreview();
      });
    });
    
    // Page range input
    this.pageRangeInput.addEventListener('input', () => {
      this._pageRangeValue = this.pageRangeInput.value.trim();
      this.previewCache = null;
      // Auto preview when page range value changes (with debounce)
      this._triggerAutoPreview();
    });

    // Copies validation: clamp to 1-99 range on blur
    const validateCopies = (input) => {
      let val = parseInt(input.value);
      if (isNaN(val) || val < 1) val = 1;
      if (val > 99) val = 99;
      input.value = val;
    };
    this.copiesInvoice.addEventListener('blur', () => validateCopies(this.copiesInvoice));
    this.copiesDocument.addEventListener('blur', () => validateCopies(this.copiesDocument));

    this.previewPrevBtn.addEventListener('click', () => this._previewGoTo(this._previewPage - 1));
    this.previewNextBtn.addEventListener('click', () => this._previewGoTo(this._previewPage + 1));

    this.dropZone.addEventListener('dragover', (e) => {
      e.preventDefault(); e.stopPropagation();
      this.dropZone.classList.add('drag-over');
    });
    this.dropZone.addEventListener('dragleave', () => { this.dropZone.classList.remove('drag-over'); });
    this.dropZone.addEventListener('drop', async (e) => {
      e.preventDefault();
      this.dropZone.classList.remove('drag-over');
      const pdfPaths = Array.from(e.dataTransfer.files)
        .filter(f => f.name.toLowerCase().endsWith('.pdf'))
        .map(f => f.path);
      if (pdfPaths.length > 0) await this._addFiles(pdfPaths);
    });

    this._cleanupProgress = window.electronAPI.onPrintProgress((data) => this._onProgress(data));
  }

  _setMode(mode) {
    this.mode = mode;
    this.previewCache = null;
    this.modeInvoiceBtn.classList.toggle('active', mode === 'invoice');
    this.modeDocumentBtn.classList.toggle('active', mode === 'document');
    this.settingsInvoice.style.display = mode === 'invoice' ? 'block' : 'none';
    this.settingsDocument.style.display = mode === 'document' ? 'block' : 'none';
    this._hidePreview();
    this._renderFileList();
    // Auto preview when mode changes
    this._triggerAutoPreview();
  }

  _getOptions() {
    const opts = { mode: this.mode, continueOnError: this.continueCheck.checked };
    if (this.mode === 'invoice') {
      opts.marginCm = parseFloat(this.marginSlider.value) || 1.0;
      opts.copies = parseInt(this.copiesInvoice.value) || 1;
    } else {
      opts.copies = parseInt(this.copiesDocument.value) || 1;
      opts.pageOrientation = this._pageOrientation;
      opts.paperOrientation = this._paperOrientation;
      opts.pageRangeMode = this._pageRangeMode;
      opts.pageRangeValue = this._pageRangeValue;
    }
    return opts;
  }

  // ===== Open / Close =====
  async open(files) {
    this.files = [];
    this._pathSet = new Set();
    this.batchResults = null;
    this.batchResult.style.display = 'none';
    this._hidePreview();
    this._renderFileList();
    if (files && files.length > 0) { await this._addFiles(files); }

    // Show workspace, hide welcome + viewer
    document.getElementById('welcome-screen').style.display = 'none';
    document.getElementById('viewer-container').style.display = 'none';
    this.workspace.style.display = 'flex';

    await this._refreshPrinters();
    this._resetUI();
  }

  hide() {
    this.workspace.style.display = 'none';
    this._resetUI();
    this._hidePreview();
    // Notify app to restore previous view
    if (this.onClose) this.onClose();
  }

  // ===== Preview =====
  /**
   * Auto preview with debounce - triggers preview generation after changes
   * Waits 500ms after last change to avoid excessive API calls
   */
  _triggerAutoPreview() {
    // Clear existing timer
    if (this._previewDebounceTimer) {
      clearTimeout(this._previewDebounceTimer);
    }
    
    // Only auto-preview if there are files
    if (this.files.length === 0) {
      this._hidePreview();
      return;
    }
    
    // Set new timer
    this._previewDebounceTimer = setTimeout(() => {
      this._showPreview();
    }, 500);
  }

  async _showPreview() {
    if (this.files.length === 0) return;
    const options = this._getOptions();
    const filePaths = this.files.map(f => f.path);

    this.statusText.textContent = '正在生成预览...';
    this.previewPlaceholder.style.display = 'none';
    this.previewArea.style.display = 'flex';

    try {
      const result = await window.electronAPI.generatePreview(filePaths, options);
      this.previewCache = { pdfBytes: result.pdfBytes, totalPages: result.totalPages };
      this._previewTotalPages = result.totalPages;
      this._previewPage = 1;
      this.previewTotal.textContent = '/' + result.totalPages;
      await this._renderPreviewPage(1);
      this.statusText.textContent = result.totalPages > 1
        ? `预览就绪（共 ${result.totalPages} 页）` : '预览就绪';
    } catch (e) {
      this.statusText.textContent = '预览失败: ' + e.message;
      this.previewCache = null;
      this.previewArea.style.display = 'none';
      this.previewPlaceholder.style.display = 'flex';
    }
  }

  async _renderPreviewPage(pageNum) {
    if (!this.previewCache) return;
    let pdfDoc = null;
    try {
      pdfDoc = await pdfjsLib.getDocument({
        data: this.previewCache.pdfBytes.slice(0),
        cMapUrl: this._getCmapUrl(),
        cMapPacked: true
      }).promise;

      const page = await pdfDoc.getPage(pageNum);
      const wrap = document.getElementById('preview-canvas-wrap');
      const maxW = wrap.clientWidth - 32;
      const vp1 = page.getViewport({ scale: 1 });
      const scale = Math.min(1, maxW / vp1.width);
      const viewport = page.getViewport({ scale });

      const canvas = this.previewCanvas;
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      canvas.style.width = viewport.width + 'px';
      canvas.style.height = viewport.height + 'px';

      const ctx = canvas.getContext('2d');
      await page.render({ canvasContext: ctx, viewport: viewport }).promise;

      this._previewPage = pageNum;
      this.previewPageNum.textContent = pageNum;
      this.previewPrevBtn.disabled = pageNum <= 1;
      this.previewNextBtn.disabled = pageNum >= this._previewTotalPages;

      const zoomInfo = document.getElementById('preview-zoom-info');
      if (zoomInfo) { zoomInfo.textContent = Math.round(scale * 100) + '%'; }
    } catch (e) {
      console.error('Preview render error:', e);
      // Clear canvas on error to avoid showing stale content
      const canvas = this.previewCanvas;
      const ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      canvas.width = 0;
      canvas.height = 0;
      canvas.style.width = '0px';
      canvas.style.height = '0px';
      this.statusText.textContent = '预览渲染失败: ' + (e.message || '未知错误');
    } finally {
      if (pdfDoc) {
        try { pdfDoc.destroy(); } catch (_) {}
      }
    }
  }

  _previewGoTo(pageNum) {
    if (pageNum < 1 || pageNum > this._previewTotalPages) return;
    this._renderPreviewPage(pageNum);
  }

  _hidePreview() {
    if (this.previewPlaceholder) this.previewPlaceholder.style.display = 'flex';
    if (this.previewArea) this.previewArea.style.display = 'none';
    this.previewCache = null;
    this._previewPage = 0;
    this._previewTotalPages = 0;
  }

  _getCmapUrl() {
    if (PrintPanel._cmapUrlCache !== undefined) return PrintPanel._cmapUrlCache;
    let url = '';
    try {
      const rp = window.electronAPI && window.electronAPI.getResourcesPath
        ? window.electronAPI.getResourcesPath() : '';
      if (rp) url = 'file://' + rp + '/app.asar.unpacked/node_modules/pdfjs-dist/cmaps/';
    } catch (e) { /* fall through */ }
    if (!url) {
      url = window.location.href.replace(/\/src\/index\.html.*$/, '') + '/node_modules/pdfjs-dist/cmaps/';
    }
    PrintPanel._cmapUrlCache = url;
    return url;
  }

  // ===== File management =====
  async _selectFiles() {
    const filePaths = await window.electronAPI.selectInvoicesDialog();
    if (filePaths && filePaths.length > 0) {
      this.files = [];
      this._pathSet = new Set();
      await this._addFiles(filePaths);
    }
  }

  async _addFiles(filePaths) {
    const newPaths = [];
    for (const fp of filePaths) {
      if (!this._pathSet.has(fp)) {
        newPaths.push(fp);
        this._pathSet.add(fp);
      }
    }
    if (newPaths.length === 0) return;
    const results = await Promise.allSettled(
      newPaths.map(fp => window.electronAPI.getPDFInfo(fp))
    );
    for (let j = 0; j < results.length; j++) {
      const res = results[j];
      this.files.push(res.status === 'fulfilled'
        ? res.value
        : { name: newPaths[j].slice(newPaths[j].lastIndexOf('\\') + 1), path: newPaths[j], size: 0, pages: 0 });
    }
    this.previewCache = null;
    this._hidePreview();
    this._renderFileList();
    this._updateButtons();
    // Auto preview after files are added
    this._triggerAutoPreview();
  }

  _removeFile(index) {
    const removed = this.files[index];
    this.files.splice(index, 1);
    if (this._pathSet && removed) this._pathSet.delete(removed.path);
    this.previewCache = null;
    this._hidePreview();
    this._renderFileList();
    this._updateButtons();
    // Auto preview after file is removed
    this._triggerAutoPreview();
  }

  _renderFileList() {
    if (this.mode === 'invoice') {
      const tp = Math.ceil(this.files.length / 2);
      this.fileCount.textContent = `${this.files.length} 个文件 -> ${tp} 页 A4`;
    } else {
      this.fileCount.textContent = `${this.files.length} 个文件 (逐个打印)`;
    }

    if (this.files.length === 0) {
      this.fileList.innerHTML = '<div class="print-file-empty">暂无文件</div>';
    } else {
      this.fileList.innerHTML = this.files.map((f, i) => `
        <div class="print-file-item">
          <span class="print-file-icon">&#9679;</span>
          <span class="print-file-name" title="${f.path}">${f.name}</span>
          <span class="print-file-size">${this._formatSize(f.size)}</span>
          <button class="print-file-remove" data-index="${i}" title="移除"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg></button>
        </div>
      `).join('');
      this.fileList.querySelectorAll('.print-file-remove').forEach(btn => {
        btn.addEventListener('click', (e) => { e.stopPropagation(); this._removeFile(parseInt(btn.dataset.index)); });
      });
    }
  }

  async _refreshPrinters() {
    this.printerSelect.innerHTML = '<option value="">正在获取打印机列表...</option>';
    this.printerSelect.disabled = true;
    this.btnPrintProps.disabled = true;
    this.btnPrint.disabled = true;
    this.btnPreview.disabled = true;
    try {
      const printers = await window.electronAPI.getPrinters();
      this.printerSelect.innerHTML = printers.map(p => `<option value="${p}">${p}</option>`).join('');
      if (printers.length === 0) { this.printerSelect.innerHTML = '<option value="">未找到打印机</option>'; }
    } catch (_) {
      this.printerSelect.innerHTML = '<option value="">获取打印机列表失败</option>';
    }
    this.printerSelect.disabled = false;
    this._updateButtons();
  }

  _updateButtons() {
    const hasFiles = this.files.length > 0;
    const hasPrinter = this.printerSelect.value && this.printerSelect.value !== '';
    this.btnPrint.disabled = !hasFiles || !hasPrinter;
    this.btnPreview.disabled = !hasFiles;
    this.btnPrintProps.disabled = !hasPrinter;
  }

  async _openPrinterProperties() {
    const printer = this.printerSelect.value;
    if (!printer) return;
    try { await window.electronAPI.openPrinterProperties(printer); } catch (e) {
      document.getElementById('status-text').textContent = e.message;
    }
  }

  // ===== Print =====
  async _startPrint() {
    const printer = this.printerSelect.value;
    if (this.files.length === 0 || !printer) return;

    this._setUIActive(true);
    this._setProgress(0, '正在启动打印...');
    this.batchResult.style.display = 'none';
    this.batchResults = null;

    try {
      const filePaths = this.files.map(f => f.path);
      const options = this._getOptions();
      if (this.previewCache && this.mode === 'invoice') {
        options._cachedPdfBytes = this.previewCache.pdfBytes;
      }
      const result = await window.electronAPI.executePrint(filePaths, printer, options);
      if (result && result.totalFiles !== undefined) {
        this.batchResults = result;
        this._showBatchResult();
      } else {
        this.statusText.textContent = '打印完成';
        document.getElementById('status-text').textContent = '打印完成';
      }
    } catch (e) {
      this.statusText.textContent = `打印失败: ${e.message}`;
      document.getElementById('status-text').textContent = `打印失败: ${e.message}`;
    } finally {
      this._setUIActive(false);
    }
  }

  _showBatchResult() {
    const r = this.batchResults;
    if (!r) return;
    let html = '';
    if (r.failed && r.failed.length > 0) {
      html += `<div class="batch-result-header">成功 ${r.success.length}，失败 ${r.failed.length}</div>`;
      html += '<div class="batch-failed-title">失败文件：</div>';
      for (const f of r.failed) {
        html += `<div class="batch-failed-item">${f.name} — ${f.error}</div>`;
      }
      html += '<button id="btn-retry-failed" class="btn-secondary">重试失败项</button>';
    } else {
      html = `<div class="batch-result-header">全部完成（${r.success.length} 个文件）</div>`;
    }
    this.batchResult.innerHTML = html;
    this.batchResult.style.display = 'block';
    const retryBtn = document.getElementById('btn-retry-failed');
    if (retryBtn) {
      retryBtn.addEventListener('click', () => {
        if (r.failed && r.failed.length > 0) {
          this.files = r.failed.map(f => ({ name: f.name, path: f.path, size: 0 }));
          this._renderFileList();
          this.batchResult.style.display = 'none';
          this._updateButtons();
        }
      });
    }
  }

  // ===== Progress =====
  _onProgress(data) {
    if (data.stage === 'done') { this._setProgress(100, data.message); this._setUIActive(false); }
    else if (data.stage === 'error') { this._setProgress(0, `错误: ${data.message}`); this._setUIActive(false); }
    else { const pct = data.total > 0 ? Math.round((data.current / data.total) * 100) : 0; this._setProgress(pct, data.message); }
  }

  _setProgress(pct, message) {
    this.progressFill.style.width = pct + '%';
    this.progressBar.style.display = pct > 0 && pct < 100 ? 'block' : 'none';
    this.statusText.textContent = message;
  }

  _setUIActive(active) {
    const cls = 'ui-busy';
    const toggle = (el) => { if (el) el.classList.toggle(cls, active); };
    toggle(this.btnPrint); toggle(this.btnPreview); toggle(this.btnPrintProps);
    toggle(document.getElementById('btn-select-files'));
    toggle(this.printerSelect);
    toggle(document.getElementById('btn-refresh-printers'));
    toggle(this.dropZone);
    this.fileList.querySelectorAll('.print-file-remove').forEach(b => {
      toggle(b);
      b.style.opacity = active ? '0.4' : '1';
    });
  }

  _resetUI() { this._setProgress(0, '就绪'); this._setUIActive(false); }

  _formatSize(bytes) {
    if (!bytes) return '';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }
}
