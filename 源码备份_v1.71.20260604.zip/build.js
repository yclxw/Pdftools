const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const pkgPath = path.join(__dirname, 'package.json');
const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));

// Parse version: "大版本.修改次数.日期" (e.g., "1.49.20260604")
const [major, modCount, dateSuffix] = pkg.version.split('.').map(Number);
const newModCount = modCount + 1;

// Today's date as YYYYMMDD
const now = new Date();
const y = now.getFullYear();
const m = String(now.getMonth() + 1).padStart(2, '0');
const d = String(now.getDate()).padStart(2, '0');
const dateStr = `${y}${m}${d}`;

const newVersion = `${major}.${newModCount}.${dateStr}`;

// Update version and artifact name
pkg.version = newVersion;
const ext = '${ext}';
pkg.build.artifactName = `PDF发票打印工具 for Win7_v${newModCount}.${dateStr}.${ext}`;

fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n', 'utf8');

console.log(`Version: ${newVersion}  (v${newModCount}.${dateStr})`);

// Run electron-builder
const args = process.argv.slice(2).join(' ');
const cmd = `npx electron-builder ${args}`;
console.log(`Running: ${cmd}`);
execSync(cmd, { stdio: 'inherit' });
