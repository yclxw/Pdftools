const { app, BrowserWindow, dialog, Menu, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const { execFile } = require('child_process');
const { PDFDocument, PageSizes, StandardFonts, rgb } = require('pdf-lib');

const pkg = require('./package.json');

let logPath = '';
function log(msg) {
  try {
    if (!logPath) {
      const userData = app.getPath('userData');
      logPath = path.join(userData, 'app.log');
    }
    const line = `[${new Date().toISOString()}] ${msg}\n`;
    fs.appendFileSync(logPath, line);
  } catch (_) {}
  console.log(msg);
}

let mainWindow;
let pendingFile = null;

// Helper: run PowerShell with UTF-16LE input; force PowerShell to output UTF-8
function runPowerShell(cmd, opts, callback) {
  const fullCmd = '$OutputEncoding = [Console]::OutputEncoding = [Text.Encoding]::UTF8; ' + cmd;
  const encoded = Buffer.from(fullCmd, 'utf16le').toString('base64');
  if (callback) {
    return execFile('powershell', ['-NoProfile', '-EncodedCommand', encoded], opts, callback);
  }
  return execFile('powershell', ['-NoProfile', '-EncodedCommand', encoded], opts);
}

function createWindow() {
  log('Creating main window...');
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 800,
    minHeight: 600,
    title: 'PDF发票打印工具 for Win7',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'))
    .then(() => log('Main window loaded successfully'))
    .catch(err => log('Failed to load main window: ' + err.message));

  mainWindow.webContents.on('did-fail-load', (_, code, desc) => {
    log(`Page load failed: ${code} - ${desc}`);
  });

  mainWindow.webContents.on('console-message', (_, level, message) => {
    log(`[Renderer] ${message}`);
  });

  const menuTemplate = [
    {
      label: '打开PDF',
      click: () => sendToRenderer('menu:openPdf')
    },
    {
      label: '发票打印',
      click: () => sendToRenderer('menu:printPanel')
    },
    {
      label: '视图',
      submenu: [
        {
          label: '适应宽度',
          accelerator: 'CmdOrCtrl+1',
          click: () => sendToRenderer('view:fitWidth')
        },
        {
          label: '适应页面',
          accelerator: 'CmdOrCtrl+2',
          click: () => sendToRenderer('view:fitPage')
        },
        {
          label: '实际大小',
          accelerator: 'CmdOrCtrl+3',
          click: () => sendToRenderer('view:actualSize')
        },
        { type: 'separator' },
        { label: '放大', accelerator: 'CmdOrCtrl+=', click: () => sendToRenderer('view:zoomIn') },
        { label: '缩小', accelerator: 'CmdOrCtrl+-', click: () => sendToRenderer('view:zoomOut') },
        { type: 'separator' },
        { label: '切换开发者工具', role: 'toggleDevTools' }
      ]
    },
    {
      label: '帮助',
      submenu: [
        {
          label: '设为默认软件',
          click: () => setAsDefaultPdfViewer()
        },
        { type: 'separator' },
        {
          label: '关于',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: '关于 PDF发票打印工具 for Win7',
              message: 'PDF发票打印工具 for Win7',
              detail: `版本: ${pkg.version}\n作者: 帅气的锅巴`
            });
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(menuTemplate);
  Menu.setApplicationMenu(menu);
}

function sendToRenderer(channel, ...args) {
  if (mainWindow && mainWindow.webContents) {
    mainWindow.webContents.send(channel, ...args);
  }
}

function setAsDefaultPdfViewer() {
  if (!app.isPackaged) {
    dialog.showMessageBox(mainWindow, {
      type: 'warning', title: '开发模式',
      message: '设为默认软件仅在安装后的打包版本中生效。'
    });
    return;
  }

  const appExe = app.getPath('exe');
  const appName = 'PDF发票打印工具.exe';
  const openCmd = '\\"' + appExe + '\\" \\"%1\\"';
  const appReg = 'HKCU\\Software\\Classes\\Applications\\' + appName;

  // Step 1: Register app in Windows "Open With" list via registry
  const tasks = [
    // Register app command and friendly name for "Open With" dialog
    ['add', appReg + '\\shell\\open\\command', '/ve', '/d', openCmd, '/f'],
    ['add', appReg, '/v', 'FriendlyAppName', '/d', 'PDF发票打印工具', '/f'],
    // Also set ProgID for proper file type display
    ['add', 'HKCU\\Software\\Classes\\Pdftools.pdf', '/ve', '/d', 'PDF发票打印工具 文档', '/f'],
    ['add', 'HKCU\\Software\\Classes\\Pdftools.pdf\\DefaultIcon', '/ve', '/d', appExe + ',0', '/f'],
    ['add', 'HKCU\\Software\\Classes\\Pdftools.pdf\\shell\\open\\command', '/ve', '/d', openCmd, '/f'],
    // Set .pdf → ProgID at HKCU level (backup to UserChoice)
    ['add', 'HKCU\\Software\\Classes\\.pdf', '/ve', '/d', 'Pdftools.pdf', '/f'],
    // Also try HKLM for system-wide (admin needed, ignore errors)
    ['add', 'HKLM\\SOFTWARE\\Classes\\Applications\\' + appName + '\\shell\\open\\command', '/ve', '/d', openCmd, '/f'],
  ];

  let done = 0;
  for (const args of tasks) {
    execFile('reg', args, { windowsHide: true }, (err) => {
      if (err && !args[1].startsWith('HKLM')) log('Reg: ' + err.message);
      done++;
      if (done === tasks.length) openWithDialog();
    });
  }

  function openWithDialog() {
    const tempPdf = path.join(app.getPath('temp'), '_pdftools_default_temp.pdf');
    const minPdf = Buffer.from(
      '%PDF-1.0\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n' +
      '2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n' +
      '3 0 obj<</Type/Page/MediaBox[0 0 612 792]/Parent 2 0 R>>endobj\n' +
      'xref\n0 4\n0000000000 65535 f \n0000000009 00000 n \n0000000058 00000 n \n0000000115 00000 n \n' +
      'trailer<</Size 4/Root 1 0 R>>\nstartxref\n190\n%%EOF',
      'ascii'
    );
    try {
      fs.writeFileSync(tempPdf, minPdf);
      execFile('rundll32', ['shell32.dll,OpenAs_RunDLL', tempPdf],
        { windowsHide: false }, (err) => {
          if (err) log('OpenWith: ' + err.message);
          setTimeout(() => { try { fs.unlinkSync(tempPdf); } catch (_) {} }, 10000);
        });
    } catch (e) {
      dialog.showErrorBox('错误', '无法启动关联设置。');
    }
    log('设为默认软件: OpenWith 对话框已打开');
  }
}

ipcMain.handle('dialog:openPdf', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: '打开PDF文件',
    filters: [{ name: 'PDF文件', extensions: ['pdf'] }],
    properties: ['openFile', 'multiSelections']
  });
  if (result.canceled) return [];
  return result.filePaths;
});

ipcMain.handle('dialog:selectInvoices', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: '选择发票文件进行拼版',
    filters: [{ name: 'PDF文件', extensions: ['pdf'] }],
    properties: ['openFile', 'multiSelections']
  });
  if (result.canceled) return [];
  return result.filePaths;
});

ipcMain.handle('fs:readFile', async (_, filePath) => {
  try {
    const buffer = fs.readFileSync(filePath);
    return buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
  } catch (e) {
    throw new Error(`读取文件失败: ${e.message}`);
  }
});

ipcMain.handle('fs:getFileInfo', async (_, filePath) => {
  try {
    const stat = fs.statSync(filePath);
    return {
      name: path.basename(filePath),
      path: filePath,
      size: stat.size
    };
  } catch (e) {
    throw new Error(`获取文件信息失败: ${e.message}`);
  }
});

// Open Windows printer properties dialog
ipcMain.handle('print:printerProperties', async (_, printerName) => {
  return new Promise((resolve, reject) => {
    const args = ['printui.dll,PrintUIEntry', '/p', '/n', printerName];
    execFile('rundll32', args, { timeout: 15000, windowsHide: false }, (err) => {
      if (err) {
        log(`Printer properties error: ${err.message}`);
        reject(new Error(`无法打开打印机属性: ${err.message}`));
      } else {
        resolve();
      }
    });
  });
});

// Get Windows printer list
ipcMain.handle('print:getPrinters', async () => {
  // Windows 7 and 8/8.1 do not have Get-Printer (requires Win8+/Server2012+ with PrintManagement).
  // On those systems, skip the PowerShell attempt entirely to avoid a 10s timeout.
  const winVersion = process.platform === 'win32' ? require('os').release().split('.').map(Number) : [];
  const isLegacyWindows = winVersion.length > 0 && winVersion[0] < 10; // NT 6.x = Win7/8/8.1

  if (isLegacyWindows) {
    return getPrintersViaWmic();
  }

  return new Promise((resolve) => {
    runPowerShell(
      '(Get-Printer | Select-Object -ExpandProperty Name) -join "|"',
      { timeout: 10000, windowsHide: true }, (err, stdout) => {
        if (err) {
          getPrintersViaWmic().then(resolve);
          return;
        }
        const printers = stdout.trim().split('|').filter(Boolean);
        resolve(printers);
      });
  });
});

function getPrintersViaWmic() {
  return new Promise((resolve) => {
    execFile('wmic', ['printer', 'get', 'name'], { timeout: 10000, windowsHide: true, encoding: 'buffer' }, (err, stdout) => {
      if (err) { resolve([]); return; }
      let text;
      try {
        text = new TextDecoder('utf-8', { fatal: true }).decode(stdout);
      } catch {
        try {
          text = new TextDecoder('gbk').decode(stdout);
        } catch {
          text = stdout.toString('utf-8');
        }
      }
      const printers = text.split('\r\n')
        .map(l => l.trim())
        .filter(l => l && l !== 'Name' && !l.startsWith('==='));
      resolve(printers);
    });
  });
}

// Get SumatraPDF.exe path
// Priority: same directory as exe → extraResources → dev directory
function getSumatraPath() {
  const exeDir = app.isPackaged ? path.dirname(app.getPath('exe')) : __dirname;
  const candidates = [
    path.join(exeDir, 'SumatraPDF.exe'),
    path.join(exeDir, 'SumatraPDF', 'SumatraPDF.exe'),
    path.join(process.resourcesPath, 'SumatraPDF.exe'),
    path.join(process.resourcesPath, 'SumatraPDF', 'SumatraPDF.exe'),
  ];
  for (const p of candidates) {
    log(`Search SumatraPDF: ${p}`);
    if (fs.existsSync(p)) return p;
  }
  log('SumatraPDF.exe not found in any candidate path');
  return candidates[0];
}

// Imposition engine: 2-in-1 vector imposition using pdf-lib
// All files (single or multiple) use the same 2-in-1 A4 layout with 1cm margins.
// Each invoice is scaled to fit the available width; height scales proportionally.
async function runImposition(filePaths) {
  const outputDoc = await PDFDocument.create();

  const A4_WIDTH = PageSizes.A4[0];   // 595.28
  const A4_HEIGHT = PageSizes.A4[1];  // 841.89
  const MARGIN = 28.35;               // 1cm in points
  const availWidth = A4_WIDTH - 2 * MARGIN;
  const availHeight = A4_HEIGHT - 2 * MARGIN;
  const halfHeight = availHeight / 2;

  const font = await outputDoc.embedFont(StandardFonts.Helvetica);

  for (let i = 0; i < filePaths.length; i += 2) {
    const page = outputDoc.addPage([A4_WIDTH, A4_HEIGHT]);

    // Top half - first invoice (fills top, bottom-aligns to center line)
    const topY = MARGIN + halfHeight;
    await _embedInvoice(outputDoc, page, filePaths[i], font, MARGIN, topY, availWidth, halfHeight, 'top');

    // Bottom half - second invoice if exists (fills bottom, top-aligns to center line)
    if (i + 1 < filePaths.length) {
      await _embedInvoice(outputDoc, page, filePaths[i + 1], font, MARGIN, MARGIN, availWidth, halfHeight, 'bottom');
    }
  }

  return await outputDoc.save();
}

async function _embedInvoice(outputDoc, targetPage, sourcePath, font, x, y, maxWidth, maxHeight, alignTo) {
  try {
    const srcBytes = fs.readFileSync(sourcePath);
    const srcDoc = await PDFDocument.load(srcBytes);
    const srcPages = srcDoc.getPages();
    if (srcPages.length === 0) return;

    const [embeddedPage] = await outputDoc.embedPdf(srcDoc, [0]);
    const dims = embeddedPage.size();
    const width = dims.width;
    const height = dims.height;
    if (!width || !height) return;

    // Scale to fit width; height scales proportionally (may overflow half-area)
    const fitScale = maxWidth / width;
    const drawW = width * fitScale;
    const drawH = height * fitScale;

    const drawX = x + (maxWidth - drawW) / 2;
    let drawY;
    if (alignTo === 'top') {
      drawY = y + maxHeight - drawH;
    } else if (alignTo === 'bottom') {
      drawY = y;
    } else {
      drawY = y + (maxHeight - drawH) / 2;
    }

    targetPage.drawPage(embeddedPage, {
      x: drawX,
      y: drawY,
      width: drawW,
      height: drawH
    });
  } catch (e) {
    log(`嵌入发票失败: ${e.message}`);
    targetPage.drawText('Error: ' + (e.message || '').replace(/[^\x00-\x7F]/g, ''), {
      x: x + 10,
      y: y + maxHeight / 2,
      size: 10,
      font: font,
      color: rgb(0.8, 0.2, 0.2)
    });
  }
}

// Main print pipeline: impose → save temp → call SumatraPDF
ipcMain.handle('print:executePrint', async (_, filePaths, printerName) => {
  try {
    const totalPairs = Math.ceil(filePaths.length / 2);

    // Stage 1: Imposition
    sendToRenderer('print:progress', {
      stage: 'imposition',
      current: 0,
      total: totalPairs,
      message: `正在拼版 ${filePaths.length} 个文件...`
    });

    log(`Starting imposition for ${filePaths.length} files → ${totalPairs} A4 pages`);

    const pdfBytes = await runImposition(filePaths);

    sendToRenderer('print:progress', {
      stage: 'imposition',
      current: totalPairs,
      total: totalPairs,
      message: '拼版完成，正在准备打印...'
    });

    // Stage 2: Write temp PDF
    const tempDir = app.getPath('temp');
    const tempPdfPath = path.join(tempDir, `invoice_print_${Date.now()}.pdf`);
    fs.writeFileSync(tempPdfPath, Buffer.from(pdfBytes));
    log(`Temp PDF written: ${tempPdfPath}`);

    // Stage 3: Silent print via SumatraPDF
    const sumatraPath = getSumatraPath();
    if (!fs.existsSync(sumatraPath)) {
      throw new Error(
        `未找到 SumatraPDF.exe\n请将 SumatraPDF.exe 放置在:\n${path.dirname(sumatraPath)}`
      );
    }

    sendToRenderer('print:progress', {
      stage: 'printing',
      current: 0,
      total: 1,
      message: '正在发送到打印机...'
    });

    log(`Printing to "${printerName}" via SumatraPDF: ${sumatraPath}`);

    return new Promise((resolve, reject) => {
      const args = [
        '-print-to', printerName,
        '-exit-when-done',
        '-silent',
        tempPdfPath
      ];
      execFile(sumatraPath, args, { timeout: 120000, windowsHide: true }, (err) => {
        // Clean up temp file
        try { fs.unlinkSync(tempPdfPath); } catch (_) {}

        if (err) {
          log(`Print error: ${err.message}`);
          reject(new Error(`打印失败: ${err.message}`));
        } else {
          log('Print job sent successfully');
          sendToRenderer('print:progress', {
            stage: 'done',
            current: 1,
            total: 1,
            message: '打印完成'
          });
          resolve();
        }
      });
    });
  } catch (e) {
    log(`Print pipeline error: ${e.message}`);
    sendToRenderer('print:progress', {
      stage: 'error',
      message: e.message
    });
    throw e;
  }
});

// 禁用GPU硬件加速，避免GPU进程崩溃导致启动无响应
app.disableHardwareAcceleration();

// Handle file association — open PDF from command line or double-click
function openPendingFile() {
  if (pendingFile && mainWindow) {
    const fp = pendingFile;
    pendingFile = null;
    if (fs.existsSync(fp)) {
      mainWindow.webContents.send('open-file', fp);
    }
  }
}

// Windows: file path passed via process.argv or second-instance
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
  app.quit();
} else {
  app.on('second-instance', (_, argv) => {
    const pdfArg = argv.find(a => a.toLowerCase().endsWith('.pdf'));
    if (pdfArg && fs.existsSync(pdfArg)) {
      if (mainWindow) {
        mainWindow.focus();
        mainWindow.webContents.send('open-file', pdfArg);
      } else {
        pendingFile = pdfArg;
      }
    }
  });
}

app.on('ready', () => {
  // Check if launched by opening a PDF file
  const pdfArg = process.argv.find(a => a.toLowerCase().endsWith('.pdf'));
  if (pdfArg && fs.existsSync(pdfArg)) {
    pendingFile = pdfArg;
  }
});

app.whenReady().then(() => {
  createWindow();
  // After window loads, send pending file
  mainWindow.webContents.on('did-finish-load', () => {
    openPendingFile();
  });
});

app.on('window-all-closed', () => {
  app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});
