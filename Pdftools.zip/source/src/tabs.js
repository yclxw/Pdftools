class TabManager {
  constructor() {
    this.tabs = [];
    this.activeTabId = null;
    this.onTabChange = null;
    this.onTabCountChange = null;

    this.tabListEl = document.getElementById('tab-list');
    this.btnNewTab = document.getElementById('btn-new-tab');
    this.contentArea = document.getElementById('content-area');
    this.welcomeScreen = document.getElementById('welcome-screen');
    this.viewerContainer = document.getElementById('viewer-container');
    this.pageControls = document.getElementById('page-controls');
    this.fileInfo = document.getElementById('file-info');

    this.btnNewTab.addEventListener('click', () => this.openPdfDialog());

    this._initContextMenu();
    this._render();
  }

  async openPdfDialog() {
    const files = await window.electronAPI.openPdfDialog();
    for (const filePath of files) {
      await this.openPdf(filePath);
    }
  }

  async openPdf(filePath) {
    // Check if already open
    const existing = this.tabs.find(t => t.filePath === filePath);
    if (existing) {
      this.switchTab(existing.id);
      return;
    }

    try {
      const fileInfo = await window.electronAPI.getFileInfo(filePath);
      const fileData = await window.electronAPI.readFile(filePath);

      const tab = {
        id: Date.now().toString(),
        filePath: filePath,
        fileName: fileInfo.name,
        fileData: fileData,
        pdfDoc: null,
        currentPage: 1,
        totalPages: 0,
        scale: 1.0,
        viewer: null
      };

      this.tabs.push(tab);
      this._render();
      this.switchTab(tab.id);

      // Load PDF content
      await this._loadPdfForTab(tab);
    } catch (e) {
      this._showError('打开文件失败', e.message);
    }
  }

  async _loadPdfForTab(tab) {
    try {
      // Ensure CMap parameters use unpacked resources when packaged.
      let cMapUrl = '';
      try {
        const resourcesPath = window.electronAPI && window.electronAPI.getResourcesPath ? window.electronAPI.getResourcesPath() : '';
        if (resourcesPath) {
          cMapUrl = 'file://' + resourcesPath + '/app.asar.unpacked/node_modules/pdfjs-dist/cmaps/';
        }
      } catch (e) { cMapUrl = ''; }

      if (!cMapUrl) {
        const baseUrl = window.location.href.replace(/\/src\/index\.html.*$/, '');
        cMapUrl = baseUrl + '/node_modules/pdfjs-dist/cmaps/';
      }

      const pdfDoc = await pdfjsLib.getDocument({ data: tab.fileData.slice(0), cMapUrl: cMapUrl, cMapPacked: true }).promise;
      tab.pdfDoc = pdfDoc;
      tab.totalPages = pdfDoc.numPages;

      // Log font/text info for diagnostics (helps identify missing embedded fonts / ToUnicode maps)
      this._logFontInfo(tab);

      // Create viewer for this tab
      const viewerWrapper = document.createElement('div');
      viewerWrapper.className = 'viewer-wrapper';
      viewerWrapper.dataset.tabId = tab.id;
      viewerWrapper.style.display = 'none';

      const scrollContainer = document.createElement('div');
      scrollContainer.className = 'viewer-scroll';
      viewerWrapper.appendChild(scrollContainer);

      this.viewerContainer.appendChild(viewerWrapper);

      tab.viewer = new PdfViewer(scrollContainer, tab, () => this._updateUI());

      if (tab.id === this.activeTabId) {
        viewerWrapper.style.display = 'flex';
        this._updateUI();
        requestAnimationFrame(() => {
          tab.viewer.fitPage();
        });
      }
    } catch (e) {
      this._showError('加载PDF失败', e.message);
    }
  }

  switchTab(id) {
    const tab = this.tabs.find(t => t.id === id);
    if (!tab) return;

    // Hide all viewers
    this.viewerContainer.querySelectorAll('.viewer-wrapper').forEach(w => {
      w.style.display = 'none';
    });

    // Show active viewer
    const wrapper = this.viewerContainer.querySelector(`[data-tab-id="${id}"]`);
    if (wrapper) {
      wrapper.style.display = 'flex';
    }

    this.activeTabId = id;
    this.welcomeScreen.style.display = 'none';
    this.viewerContainer.style.display = 'block';

    if (tab.viewer) {
      requestAnimationFrame(() => {
        tab.viewer.fitPage();
      });
    }

    this._updateUI();
    this._render();

    if (this.onTabChange) this.onTabChange(tab);
  }

  closeTab(id, forceCloseAll = false) {
    const idx = this.tabs.findIndex(t => t.id === id);
    if (idx === -1) return;

    const tab = this.tabs[idx];

    // Remove viewer DOM
    const wrapper = this.viewerContainer.querySelector(`[data-tab-id="${id}"]`);
    if (wrapper) wrapper.remove();

    // Destroy viewer
    if (tab.viewer) {
      tab.viewer.destroy();
    }

    // Clean up pdfDoc
    if (tab.pdfDoc) {
      tab.pdfDoc.destroy();
      tab.pdfDoc = null;
    }

    this.tabs.splice(idx, 1);

    if (this.tabs.length === 0) {
      this.activeTabId = null;
      this.welcomeScreen.style.display = 'flex';
      this.viewerContainer.style.display = 'none';
      this.pageControls.style.display = 'none';
      this.fileInfo.textContent = '';
    } else if (this.activeTabId === id) {
      // Switch to adjacent tab
      const newIdx = Math.min(idx, this.tabs.length - 1);
      this.switchTab(this.tabs[newIdx].id);
    }

    this._render();
    if (this.onTabCountChange) this.onTabCountChange(this.tabs.length);
  }

  getActiveTab() {
    return this.tabs.find(t => t.id === this.activeTabId) || null;
  }

  closeAllTabs() {
    const ids = this.tabs.map(t => t.id);
    for (const id of ids) {
      this.closeTab(id);
    }
  }

  closeOtherTabs(id) {
    const otherIds = this.tabs.filter(t => t.id !== id).map(t => t.id);
    for (const oid of otherIds) {
      this.closeTab(oid);
    }
  }

  _updateUI() {
    const tab = this.getActiveTab();
    if (!tab) return;

    this.pageControls.style.display = 'flex';

    if (tab.viewer) {
      document.getElementById('zoom-level').textContent = Math.round(tab.scale * 100) + '%';
      document.getElementById('page-input').value = tab.currentPage;
      document.getElementById('total-pages').textContent = '/ ' + tab.totalPages;
    }

    this.fileInfo.textContent = tab.fileName;
  }

  _render() {
    this.tabListEl.innerHTML = '';

    for (const tab of this.tabs) {
      const tabEl = document.createElement('div');
      tabEl.className = 'tab-item' + (tab.id === this.activeTabId ? ' active' : '');
      tabEl.dataset.tabId = tab.id;
      tabEl.draggable = true;

      const title = document.createElement('span');
      title.className = 'tab-title';
      title.textContent = tab.fileName;
      title.title = tab.filePath;

      const closeBtn = document.createElement('button');
      closeBtn.className = 'tab-close';
      closeBtn.textContent = '×';
      closeBtn.onclick = (e) => {
        e.stopPropagation();
        this.closeTab(tab.id);
      };

      tabEl.appendChild(title);
      tabEl.appendChild(closeBtn);

      tabEl.onclick = () => this.switchTab(tab.id);
      tabEl.oncontextmenu = (e) => {
        e.preventDefault();
        this._showContextMenu(e.clientX, e.clientY, tab.id);
      };

      // Drag and drop for tab reordering
      tabEl.ondragstart = (e) => {
        e.dataTransfer.setData('text/plain', tab.id);
        e.dataTransfer.effectAllowed = 'move';
      };
      tabEl.ondragover = (e) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
      };
      tabEl.ondrop = (e) => {
        e.preventDefault();
        const fromId = e.dataTransfer.getData('text/plain');
        const toId = tab.id;
        if (fromId !== toId) {
          this._reorderTabs(fromId, toId);
        }
      };

      this.tabListEl.appendChild(tabEl);
    }
  }

  _reorderTabs(fromId, toId) {
    const fromIdx = this.tabs.findIndex(t => t.id === fromId);
    const toIdx = this.tabs.findIndex(t => t.id === toId);
    if (fromIdx === -1 || toIdx === -1) return;

    const [tab] = this.tabs.splice(fromIdx, 1);
    this.tabs.splice(toIdx, 0, tab);
    this._render();
  }

  _initContextMenu() {
    this.contextMenu = document.createElement('div');
    this.contextMenu.className = 'context-menu';
    this.contextMenu.style.display = 'none';
    document.body.appendChild(this.contextMenu);

    document.addEventListener('click', () => {
      this.contextMenu.style.display = 'none';
    });
  }

  _showContextMenu(x, y, tabId) {
    this.contextMenu.innerHTML = '';

    const items = [
      { label: '关闭标签', action: () => this.closeTab(tabId), cls: '' },
      { label: '关闭其他标签', action: () => this.closeOtherTabs(tabId), cls: '' },
      { label: '关闭所有标签', action: () => this.closeAllTabs(), cls: '' },
    ];

    for (const item of items) {
      const el = document.createElement('div');
      el.className = 'context-menu-item' + (item.cls ? ' ' + item.cls : '');
      el.textContent = item.label;
      el.onclick = () => {
        item.action();
        this.contextMenu.style.display = 'none';
      };
      this.contextMenu.appendChild(el);
    }

    this.contextMenu.style.display = 'block';
    this.contextMenu.style.left = x + 'px';
    this.contextMenu.style.top = y + 'px';

    // Keep menu within viewport
    const rect = this.contextMenu.getBoundingClientRect();
    if (rect.right > window.innerWidth) {
      this.contextMenu.style.left = (x - rect.width) + 'px';
    }
    if (rect.bottom > window.innerHeight) {
      this.contextMenu.style.top = (y - rect.height) + 'px';
    }
  }

  _showError(title, message) {
    document.getElementById('status-text').textContent = `错误: ${message}`;
    console.error(title, message);
  }

  async _logFontInfo(tab) {
    try {
      const page = await tab.pdfDoc.getPage(1);
      const text = await page.getTextContent();
      // Log styles and used font names to console for debugging
      console.group(`PDF 字体诊断: ${tab.fileName}`);
      console.log('styles:', text.styles);
      const fonts = new Set();
      if (text.items && text.items.length) {
        for (const item of text.items) {
          if (item.fontName) fonts.add(item.fontName);
        }
      }
      console.log('fonts used on page 1:', Array.from(fonts));
      console.log('text sample items:', text.items && text.items.slice(0, 20));
      console.groupEnd();
    } catch (e) {
      console.warn('获取 PDF 字体/文本信息失败:', e);
    }
  }
}
