class PrintPanel {
  constructor() {
    this.files = [];
    this.dialog = document.getElementById('print-panel-dialog');
    this.dropZone = document.getElementById('print-drop-zone');
    this.fileList = document.getElementById('print-file-list');
    this.fileCount = document.getElementById('print-file-count');
    this.printerSelect = document.getElementById('printer-select');
    this.btnPrintProps = document.getElementById('btn-print-properties');
    this.btnPrint = document.getElementById('btn-print-start');
    this.statusText = document.getElementById('print-status-text');
    this.progressBar = document.getElementById('print-progress-bar');
    this.progressFill = document.getElementById('print-progress-fill');
    this.queueSection = document.getElementById('print-queue-section');
    this.printerSection = document.getElementById('print-printer-section');

    this._bindEvents();
  }

  _bindEvents() {
    document.getElementById('print-dialog-close').addEventListener('click', () => this.hide());
    document.getElementById('btn-print-cancel').addEventListener('click', () => this.hide());
    document.getElementById('btn-select-files').addEventListener('click', () => this._selectFiles());
    document.getElementById('btn-refresh-printers').addEventListener('click', () => this._refreshPrinters());
    this.btnPrintProps.addEventListener('click', () => this._openPrinterProperties());
    this.printerSelect.addEventListener('change', () => this._updateButtons());

    this.btnPrint.addEventListener('click', () => this._startPrint());

    this.dropZone.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.stopPropagation();
      this.dropZone.classList.add('drag-over');
    });
    this.dropZone.addEventListener('dragleave', () => {
      this.dropZone.classList.remove('drag-over');
    });
    this.dropZone.addEventListener('drop', async (e) => {
      e.preventDefault();
      this.dropZone.classList.remove('drag-over');
      const droppedFiles = Array.from(e.dataTransfer.files);
      const pdfPaths = droppedFiles
        .filter(f => f.name.toLowerCase().endsWith('.pdf'))
        .map(f => f.path);
      if (pdfPaths.length > 0) {
        await this._addFiles(pdfPaths);
      }
    });

    window.electronAPI.onPrintProgress((data) => this._onProgress(data));
  }

  async open(files) {
    this.files = [];
    this._renderFileList();
    if (files && files.length > 0) {
      await this._addFiles(files);
    }
    await this._refreshPrinters();
    this._resetUI();
    this.dialog.style.display = 'flex';
  }

  hide() {
    this.dialog.style.display = 'none';
    this._resetUI();
  }

  async _selectFiles() {
    const filePaths = await window.electronAPI.selectInvoicesDialog();
    if (filePaths && filePaths.length > 0) {
      this.files = [];
      this._renderFileList();
      await this._addFiles(filePaths);
    }
  }

  async _addFiles(filePaths) {
    for (const fp of filePaths) {
      if (this.files.some(f => f.path === fp)) continue;
      try {
        const info = await window.electronAPI.getFileInfo(fp);
        this.files.push(info);
      } catch (_) {
        this.files.push({ name: fp.split(/[\\/]/).pop(), path: fp, size: 0 });
      }
    }
    this._renderFileList();
    this._updateButtons();
  }

  _removeFile(index) {
    this.files.splice(index, 1);
    this._renderFileList();
    this._updateButtons();
  }

  _renderFileList() {
    const totalPages = Math.ceil(this.files.length / 2);
    this.fileCount.textContent = `${this.files.length} 个文件 → 将生成 ${totalPages} 页 A4`;

    if (this.files.length === 0) {
      this.fileList.innerHTML = '<div class="print-file-empty">暂无文件，请拖拽或选择发票PDF</div>';
    } else {
      this.fileList.innerHTML = this.files.map((f, i) => `
        <div class="print-file-item">
          <span class="print-file-icon">📄</span>
          <span class="print-file-name" title="${f.path}">${f.name}</span>
          <span class="print-file-size">${this._formatSize(f.size)}</span>
          <button class="print-file-remove" data-index="${i}" title="移除">✕</button>
        </div>
      `).join('');

      this.fileList.querySelectorAll('.print-file-remove').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          this._removeFile(parseInt(btn.dataset.index));
        });
      });
    }
  }

  async _refreshPrinters() {
    this.printerSelect.innerHTML = '<option value="">正在获取打印机列表...</option>';
    this.printerSelect.disabled = true;
    this.btnPrintProps.disabled = true;
    this.btnPrint.disabled = true;
    try {
      const printers = await window.electronAPI.getPrinters();
      this.printerSelect.innerHTML = printers.map(p => `<option value="${p}">${p}</option>`).join('');
      if (printers.length === 0) {
        this.printerSelect.innerHTML = '<option value="">未找到打印机</option>';
      }
    } catch (_) {
      this.printerSelect.innerHTML = '<option value="">获取打印机列表失败</option>';
    }
    this.printerSelect.disabled = false;
    this._updateButtons();
  }

  _updateButtons() {
    const hasFiles = this.files.length > 0;
    const hasPrinter = this.printerSelect.value && this.printerSelect.value !== '';
    this.btnPrint.disabled = !hasFiles || !hasPrinter;
    this.btnPrintProps.disabled = !hasPrinter;
  }

  async _openPrinterProperties() {
    const printer = this.printerSelect.value;
    if (!printer) return;
    try {
      await window.electronAPI.openPrinterProperties(printer);
    } catch (e) {
      document.getElementById('status-text').textContent = e.message;
    }
  }

  async _startPrint() {
    const printer = this.printerSelect.value;
    if (!printer || this.files.length === 0) return;

    this._setUIActive(true);
    this._setProgress(0, '正在启动打印...');

    try {
      const filePaths = this.files.map(f => f.path);
      await window.electronAPI.executePrint(filePaths, printer);
      this._setProgress(100, '打印完成');
      document.getElementById('status-text').textContent = '打印完成';
    } catch (e) {
      this._setProgress(0, `打印失败: ${e.message}`);
      document.getElementById('status-text').textContent = `打印失败: ${e.message}`;
    } finally {
      this._setUIActive(false);
    }
  }

  _onProgress(data) {
    if (data.stage === 'done') {
      this._setProgress(100, '打印完成');
      this._setUIActive(false);
    } else if (data.stage === 'error') {
      this._setProgress(0, `错误: ${data.message}`);
      this._setUIActive(false);
    } else {
      const pct = data.total > 0 ? Math.round((data.current / data.total) * 100) : 0;
      this._setProgress(pct, data.message);
    }
  }

  _setProgress(pct, message) {
    this.progressFill.style.width = pct + '%';
    this.progressBar.style.display = pct > 0 && pct < 100 ? 'block' : 'none';
    this.statusText.textContent = message;
  }

  _setUIActive(active) {
    this.btnPrint.disabled = active;
    this.btnPrintProps.disabled = active;
    document.getElementById('btn-select-files').disabled = active;
    this.printerSelect.disabled = active;
    document.getElementById('btn-refresh-printers').disabled = active;
    this.dropZone.style.pointerEvents = active ? 'none' : 'auto';
    this.dropZone.style.opacity = active ? '0.5' : '1';
    this.fileList.querySelectorAll('.print-file-remove').forEach(b => {
      b.disabled = active;
      b.style.opacity = active ? '0.4' : '1';
    });
  }

  _resetUI() {
    this._setProgress(0, '就绪');
    this._setUIActive(false);
  }

  _formatSize(bytes) {
    if (!bytes) return '';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }
}
