const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  openPdfDialog: () => ipcRenderer.invoke('dialog:openPdf'),
  readFile: (filePath) => ipcRenderer.invoke('fs:readFile', filePath),
  getFileInfo: (filePath) => ipcRenderer.invoke('fs:getFileInfo', filePath),

  // Print pipeline
  getPrinters: () => ipcRenderer.invoke('print:getPrinters'),
  selectInvoicesDialog: () => ipcRenderer.invoke('dialog:selectInvoices'),
  executePrint: (filePaths, printerName) => ipcRenderer.invoke('print:executePrint', filePaths, printerName),
  openPrinterProperties: (printerName) => ipcRenderer.invoke('print:printerProperties', printerName),
  onPrintProgress: (callback) => {
    const handler = (_, data) => callback(data);
    ipcRenderer.on('print:progress', handler);
    return () => ipcRenderer.removeListener('print:progress', handler);
  },

  // Menu event listeners
  onOpenFile: (callback) => ipcRenderer.on('open-file', (_, fp) => callback(fp)),
  onMenuOpenPdf: (callback) => ipcRenderer.on('menu:openPdf', callback),
  onMenuPrintPanel: (callback) => ipcRenderer.on('menu:printPanel', callback),
  onViewFitWidth: (callback) => ipcRenderer.on('view:fitWidth', callback),
  onViewFitPage: (callback) => ipcRenderer.on('view:fitPage', callback),
  onViewActualSize: (callback) => ipcRenderer.on('view:actualSize', callback),
  onViewZoomIn: (callback) => ipcRenderer.on('view:zoomIn', callback),
  onViewZoomOut: (callback) => ipcRenderer.on('view:zoomOut', callback),

  // Expose resources path for renderer to locate unpacked files
  getResourcesPath: () => process.resourcesPath
});
