## 备份规则

```
bak/
├── source/              完整源代码 — 可在另一台电脑重建项目
├── dev-tools/           开发工具集 — 支撑开发环境重建
├── patches/             运行补丁集 — 随交付物进入目标环境
├── *.exe                最终构建产物（安装包）
└── 备份说明.md           备份清单说明
```

- 开发过程中新增的外部工具、插件放入 `dev-tools/`
- 交付物运行所需的环境依赖放入 `patches/`
- 构建产物直接输出到 `bak/` 根目录
- 每次重大变更后更新 `备份说明.md`

## 版本规则

- 版本号格式: `v{major}.{minor}.{date}`，如 `v1.45.20260523`
- `package.json` 中 `version` 和 `build.artifactName` 同步更新
- 不以 `build.js` 脚本构建（脚本会自动递增版本号），直接使用 `npx electron-builder`

## 构建规则

- 始终使用 `ELECTRON_MIRROR=https://npmmirror.com/mirrors/electron/` 环境变量
- 始终使用 `CSC_IDENTITY_AUTO_DISCOVERY=false` 跳过代码签名
- 分三步构建: `--dir` → rcedit 修复元数据+嵌入图标 → `--prepackaged` 生成安装包
- rcedit 修复项: FileDescription/ProductName/OriginalFilename/InternalName/CompanyName + icon
- 跳过原生模块重编译: `"npmRebuild": false`
- 构建目标: NSIS 安装包，仅 x64 架构

## 平台兼容

- 目标系统: Windows 7 SP1 x64，兼容 Windows 10/11
- Electron 版本锁定 22.3.27（最后一个支持 Win7 的版本）
- pdfjs-dist 保持 3.x（Chromium 108 支持 ES2022 API）
- 打印驱动: SumatraPDF.exe，查找路径优先级：exe 同级目录 → resources 目录

## 代码规则

- 主进程 (main.js): IPC 处理、拼版引擎、打印调度、菜单
- 渲染进程 (src/*.js): PDF.js 渲染、标签管理、打印面板 UI
- 预加载 (preload.js): contextBridge 暴露安全 API
- 所有文件打印统一走 `print:executePrint` 通道，2合1 拼版引擎
- 缩放仅按宽度适配 (`maxWidth / width`)，高度按比例自适应
- Win7 打印机枚举: NT 6.x 直接走 `wmic`，跳过 PowerShell 避免超时
- 中文字体栈包含 SimHei/SimSun 回退

## 下载规则

- 涉及下载各类软件都需要提醒用户：网络环境是否允许下载？
- npm 下载优先使用 npmmirror.com 镜像
- Electron 二进制使用 ELECTRON_MIRROR 环境变量指向镜像站
