const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const pkgPath = path.join(__dirname, 'package.json');
const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));

// Parse current version
const [major, minor, patch] = pkg.version.split('.').map(Number);
const newPatch = patch + 1;
const newVersion = `${major}.${minor}.${newPatch}`;

// Today's date as YYYYMMDD
const now = new Date();
const y = now.getFullYear();
const m = String(now.getMonth() + 1).padStart(2, '0');
const d = String(now.getDate()).padStart(2, '0');
const dateStr = `${y}${m}${d}`;

// Update version and artifact name
pkg.version = newVersion;
const ext = '${ext}';
pkg.build.artifactName = `PDF发票打印工具_v${newPatch}.${dateStr}.${ext}`;

fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n', 'utf8');

console.log(`Version: ${newVersion}  (v${newPatch}.${dateStr})`);

// Run electron-builder
const args = process.argv.slice(2).join(' ');
const cmd = `npx electron-builder ${args}`;
console.log(`Running: ${cmd}`);
execSync(cmd, { stdio: 'inherit' });
