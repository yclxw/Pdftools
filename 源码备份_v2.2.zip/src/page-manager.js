class PageManager {
  constructor() {
    this.filePath = null;
    this.pdfBytes = null;
    this.pages = []; // { originalIndex, rotation, deleted, thumbnail }
    this.selectedIndices = new Set();
    this.draggedIndex = null;
    this.onClose = null;

    this._createDialog();
  }

  _createDialog() {
    this.overlay = document.createElement('div');
    this.overlay.className = 'dialog-overlay';
    this.overlay.style.display = 'none';
    this.overlay.innerHTML = `
      <div class="dialog" style="max-width:1100px;">
        <div class="dialog-header">
          <h2>页面管理</h2>
          <button class="dialog-close" id="page-manager-close"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg></button>
        </div>
        <div class="dialog-body" style="display:flex;gap:16px;align-items:flex-start;">
          <!-- 左侧：缩略图网格 -->
          <div id="page-thumbnails-container" style="flex:1;min-height:400px;max-height:500px;overflow-y:auto;background:#f9f9f9;border:1px solid var(--border,#d9d9d9);border-radius:6px;padding:12px;">
            <div id="page-thumbnails-grid" class="page-thumbnails-grid"></div>
          </div>

          <!-- 右侧：操作面板 -->
          <div style="width:240px;display:flex;flex-direction:column;gap:10px;">
            <div style="padding:12px;background:#fafafa;border:1px solid var(--border,#d9d9d9);border-radius:6px;">
              <div style="font-weight:600;font-size:13px;margin-bottom:8px;">页面操作</div>
              <div style="display:flex;flex-direction:column;gap:6px;">
                <button id="page-rotate-left" class="btn-secondary" style="width:100%;" disabled>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:4px;"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
                  左旋转 90°
                </button>
                <button id="page-rotate-right" class="btn-secondary" style="width:100%;" disabled>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:4px;"><path d="M21 12a9 9 0 1 1-9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/></svg>
                  右旋转 90°
                </button>
                <button id="page-delete" class="btn-secondary" style="width:100%;color:#c42b1c;" disabled>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:4px;"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
                  删除页面
                </button>
              </div>
            </div>

            <div style="padding:12px;background:#fafafa;border:1px solid var(--border,#d9d9d9);border-radius:6px;">
              <div style="font-weight:600;font-size:13px;margin-bottom:8px;">提示</div>
              <div style="font-size:11px;color:var(--text-secondary,#616161);line-height:1.5;">
                • 点击页面缩略图选中<br>
                • 拖拽页面可调整顺序<br>
                • 支持多选操作<br>
                • 所有更改将在保存时应用
              </div>
            </div>
          </div>
        </div>
        <div class="dialog-footer">
          <div class="dialog-footer-left">
            <span id="page-status-text" style="font-size:12px;color:var(--text-secondary,#616161);"></span>
          </div>
          <div class="dialog-footer-right">
            <button id="page-btn-cancel">取消</button>
            <button id="page-btn-save" class="btn-primary" disabled>保存更改</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(this.overlay);
    this._bindEvents();
  }

  _bindEvents() {
    const sel = (id) => this.overlay.querySelector(id);

    sel('#page-manager-close').addEventListener('click', () => this.hide());
    sel('#page-btn-cancel').addEventListener('click', () => this.hide());
    this.overlay.addEventListener('click', (e) => { if (e.target === this.overlay) this.hide(); });

    sel('#page-rotate-left').addEventListener('click', () => this._rotateSelected(-90));
    sel('#page-rotate-right').addEventListener('click', () => this._rotateSelected(90));
    sel('#page-delete').addEventListener('click', () => this._deleteSelected());
    sel('#page-btn-save').addEventListener('click', () => this._saveChanges());
  }

  _sel(id) { return this.overlay.querySelector(id); }

  async open(filePath) {
    if (!filePath) {
      document.getElementById('status-text').textContent = '请先打开一个 PDF 文件';
      return;
    }

    this.overlay.style.display = 'flex';
    this.filePath = filePath;
    this.selectedIndices.clear();
    this.draggedIndex = null;
    this._sel('#page-status-text').textContent = '';
    this._sel('#page-btn-save').disabled = true;

    try {
      this._sel('#page-status-text').textContent = '正在加载页面...';
      this.pdfBytes = await window.electronAPI.readFile(filePath);
      
      // Load page info from main process
      const pageInfo = await window.electronAPI.getPageInfo(filePath);
      
      // Initialize pages array
      this.pages = pageInfo.map((info, idx) => ({
        originalIndex: idx,
        rotation: info.rotation || 0,
        deleted: false,
        thumbnail: null
      }));

      await this._renderThumbnails();
      this._updateButtons();
      this._sel('#page-status-text').textContent = `共 ${this.pages.length} 页`;
    } catch (e) {
      this._sel('#page-status-text').textContent = '加载失败: ' + e.message;
      console.error('PageManager load error:', e);
    }
  }

  hide() {
    this.overlay.style.display = 'none';
    this.filePath = null;
    this.pdfBytes = null;
    this.pages = [];
    this.selectedIndices.clear();
    document.getElementById('status-text').textContent = '就绪';
    if (this.onClose) this.onClose();
  }

  async _renderThumbnails() {
    const grid = this._sel('#page-thumbnails-grid');
    grid.innerHTML = '';

    // Use pdfjs to generate thumbnails
    let pdfDoc = null;
    try {
      pdfDoc = await pdfjsLib.getDocument({
        data: this.pdfBytes.slice(0),
        cMapUrl: this._getCmapUrl(),
        cMapPacked: true
      }).promise;

      const renderPromises = this.pages.map(async (page, idx) => {
        if (page.deleted) return null;

        try {
          const pdfPage = await pdfDoc.getPage(idx + 1);
          const viewport = pdfPage.getViewport({ scale: 0.3 });

          const canvas = document.createElement('canvas');
          canvas.width = viewport.width;
          canvas.height = viewport.height;
          canvas.style.width = '120px';
          canvas.style.height = 'auto';

          const ctx = canvas.getContext('2d');
          await pdfPage.render({ canvasContext: ctx, viewport: viewport }).promise;

          page.thumbnail = canvas.toDataURL();
          return { index: idx, thumbnail: page.thumbnail };
        } catch (e) {
          console.warn(`Thumbnail render failed for page ${idx + 1}:`, e);
          return { index: idx, thumbnail: null };
        }
      });

      await Promise.all(renderPromises);
    } catch (e) {
      console.error('PDF document load error:', e);
    } finally {
      if (pdfDoc) {
        try { pdfDoc.destroy(); } catch (_) {}
      }
    }

    // Render grid items
    this.pages.forEach((page, idx) => {
      if (page.deleted) return;

      const item = document.createElement('div');
      item.className = 'page-thumb-item';
      item.dataset.index = idx;
      item.draggable = true;

      if (this.selectedIndices.has(idx)) {
        item.classList.add('page-thumb-selected');
      }

      const rotation = page.rotation % 360;
      const rotationStyle = rotation !== 0 ? `transform: rotate(${rotation}deg);` : '';

      item.innerHTML = `
        <div class="page-thumb-number">${idx + 1}</div>
        <div class="page-thumb-image" style="${rotationStyle}">
          ${page.thumbnail ? `<img src="${page.thumbnail}" alt="Page ${idx + 1}">` : '<div class="page-thumb-placeholder">无预览</div>'}
        </div>
        <div class="page-thumb-label">第 ${idx + 1} 页</div>
      `;

      // Click to select - handle clicks on the item itself, not just excluding IMG
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        // Don't select if we just finished dragging
        if (this._justDragged) {
          this._justDragged = false;
          return;
        }
        this._toggleSelection(idx);
      });

      // Right-click context menu
      item.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        // Select this item if not already selected
        if (!this.selectedIndices.has(idx)) {
          this.selectedIndices.clear();
          this.selectedIndices.add(idx);
          this._updateSelectionVisuals();
          this._updateButtons();
        }
        
        this._showContextMenu(e.clientX, e.clientY, idx);
      });

      // Drag events
      item.addEventListener('dragstart', (e) => {
        this.draggedIndex = idx;
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', String(idx));
        item.style.opacity = '0.5';
      });

      item.addEventListener('dragend', () => {
        item.style.opacity = '1';
        // Mark that we just dragged to prevent click selection
        this._justDragged = true;
        setTimeout(() => { this._justDragged = false; }, 100);
        this.draggedIndex = null;
      });

      item.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        item.classList.add('page-thumb-dragover');
      });

      item.addEventListener('dragleave', () => {
        item.classList.remove('page-thumb-dragover');
      });

      item.addEventListener('drop', (e) => {
        e.preventDefault();
        item.classList.remove('page-thumb-dragover');
        const fromIdx = parseInt(e.dataTransfer.getData('text/plain'));
        const toIdx = idx;
        if (fromIdx !== toIdx && fromIdx !== null) {
          this._reorderPages(fromIdx, toIdx);
        }
      });

      grid.appendChild(item);
    });
  }

  _showContextMenu(x, y, idx) {
    // Remove existing context menu
    const existingMenu = document.querySelector('.page-context-menu');
    if (existingMenu) existingMenu.remove();

    const menu = document.createElement('div');
    menu.className = 'page-context-menu';
    menu.style.left = x + 'px';
    menu.style.top = y + 'px';

    menu.innerHTML = `
      <div class="page-context-menu-item" data-action="rotate-left">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
        左旋转 90°
      </div>
      <div class="page-context-menu-item" data-action="rotate-right">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/></svg>
        右旋转 90°
      </div>
      <div class="page-context-menu-divider"></div>
      <div class="page-context-menu-item page-context-menu-item-danger" data-action="delete">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
        删除页面
      </div>
    `;

    document.body.appendChild(menu);

    // Handle menu item clicks
    menu.addEventListener('click', (e) => {
      const item = e.target.closest('.page-context-menu-item');
      if (!item) return;

      const action = item.dataset.action;
      switch (action) {
        case 'rotate-left':
          this._rotateSelected(-90);
          break;
        case 'rotate-right':
          this._rotateSelected(90);
          break;
        case 'delete':
          this._deleteSelected();
          break;
      }

      menu.remove();
    });

    // Close menu when clicking outside
    setTimeout(() => {
      document.addEventListener('click', function closeMenu() {
        menu.remove();
        document.removeEventListener('click', closeMenu);
      }, { once: true });
    }, 10);
  }

  _toggleSelection(idx) {
    if (this.selectedIndices.has(idx)) {
      this.selectedIndices.delete(idx);
    } else {
      this.selectedIndices.add(idx);
    }
    // Only update visual state, don't re-render thumbnails
    this._updateSelectionVisuals();
    this._updateButtons();
  }

  _updateSelectionVisuals() {
    const grid = this._sel('#page-thumbnails-grid');
    const items = grid.querySelectorAll('.page-thumb-item');
    items.forEach(item => {
      const idx = parseInt(item.dataset.index);
      if (this.selectedIndices.has(idx)) {
        item.classList.add('page-thumb-selected');
      } else {
        item.classList.remove('page-thumb-selected');
      }
    });
  }

  _rotateSelected(degrees) {
    this.selectedIndices.forEach(idx => {
      if (idx >= 0 && idx < this.pages.length && !this.pages[idx].deleted) {
        this.pages[idx].rotation = (this.pages[idx].rotation + degrees + 360) % 360;
      }
    });
    this._renderThumbnails();
    this._sel('#page-btn-save').disabled = false;
    this._sel('#page-status-text').textContent = `已旋转 ${this.selectedIndices.size} 个页面`;
  }

  _deleteSelected() {
    if (this.selectedIndices.size === 0) return;

    const count = this.selectedIndices.size;
    this.selectedIndices.forEach(idx => {
      if (idx >= 0 && idx < this.pages.length) {
        this.pages[idx].deleted = true;
      }
    });
    this.selectedIndices.clear();
    this._renderThumbnails();
    this._updateButtons();
    this._sel('#page-btn-save').disabled = false;
    this._sel('#page-status-text').textContent = `已删除 ${count} 个页面`;
  }

  _reorderPages(fromIdx, toIdx) {
    // Swap pages in array
    const fromPage = this.pages[fromIdx];
    const toPage = this.pages[toIdx];
    
    this.pages[fromIdx] = toPage;
    this.pages[toIdx] = fromPage;

    this._renderThumbnails();
    this._sel('#page-btn-save').disabled = false;
    this._sel('#page-status-text').textContent = '页面顺序已调整';
  }

  async _saveChanges() {
    if (!this.filePath) return;

    this._sel('#page-btn-save').disabled = true;
    this._sel('#page-status-text').textContent = '正在保存...';

    try {
      const result = await window.electronAPI.savePageChanges(this.filePath, this.pages);
      this._sel('#page-status-text').textContent = '保存成功！';
      document.getElementById('status-text').textContent = '页面已保存';
      
      setTimeout(() => {
        this.hide();
      }, 1000);
    } catch (e) {
      this._sel('#page-status-text').textContent = '保存失败: ' + e.message;
      this._sel('#page-btn-save').disabled = false;
      console.error('Save error:', e);
    }
  }

  _updateButtons() {
    const hasSelection = this.selectedIndices.size > 0;
    this._sel('#page-rotate-left').disabled = !hasSelection;
    this._sel('#page-rotate-right').disabled = !hasSelection;
    this._sel('#page-delete').disabled = !hasSelection;
  }

  _getCmapUrl() {
    // 优先使用 app.js 中定义的统一 CMap URL 获取函数
    if (typeof window.getCMapUrl === 'function') {
      return window.getCMapUrl();
    }
    // Fallback: 本地实现（与 app.js 逻辑保持一致）
    if (PageManager._cmapUrlCache !== undefined) return PageManager._cmapUrlCache;
    let url = '';
    try {
      const rp = window.electronAPI && window.electronAPI.getResourcesPath
        ? window.electronAPI.getResourcesPath() : '';
      if (rp) {
        const cmapDir = rp.replace(/\\/g, '/') + '/app.asar.unpacked/node_modules/pdfjs-dist/cmaps/';
        url = 'file:///' + cmapDir.replace(/^\/+/, '');
      }
    } catch (e) { /* fall through */ }
    if (!url) {
      url = window.location.href.replace(/\/src\/index\.html.*$/, '') + '/node_modules/pdfjs-dist/cmaps/';
    }
    PageManager._cmapUrlCache = url;
    return url;
  }
}
