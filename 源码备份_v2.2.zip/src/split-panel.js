class SplitPanel {
  constructor() {
    this.sourcePath = null;
    this.totalPages = 0;
    this.splitMode = 'single'; // 'single' | 'everyN' | 'custom'
    this.everyN = 2;
    this.customRanges = '';
    this.outputDir = null;

    this._createDialog();
  }

  _createDialog() {
    this.overlay = document.createElement('div');
    this.overlay.className = 'dialog-overlay';
    this.overlay.style.display = 'none';
    this.overlay.innerHTML = `
      <div class="dialog" style="max-width:600px;">
        <div class="dialog-header">
          <h2>拆分文档</h2>
          <button class="dialog-close" id="split-panel-close"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg></button>
        </div>
        <div class="dialog-body">
          <div style="margin-bottom:16px;">
            <label style="display:block;margin-bottom:6px;font-weight:500;font-size:13px;">源文件</label>
            <div style="display:flex;gap:8px;">
              <input type="text" id="split-source-path" readonly style="flex:1;height:30px;border:1px solid var(--border,#d9d9d9);border-radius:4px;padding:0 8px;font-size:12px;background:#fafafa;">
              <button id="split-select-source" class="btn-secondary">选择文件</button>
            </div>
          </div>

          <div style="margin-bottom:16px;">
            <label style="display:block;margin-bottom:8px;font-weight:500;font-size:13px;">拆分方式</label>
            <div style="display:flex;flex-direction:column;gap:8px;">
              <label class="split-radio-label">
                <input type="radio" name="split-mode" value="single" checked> 每页独立（共 <span id="split-single-count">—</span> 页）
              </label>
              <label class="split-radio-label">
                <input type="radio" name="split-mode" value="everyN">
                每 <input type="number" id="split-every-n" value="2" min="1" max="99" style="width:48px;height:24px;border:1px solid var(--border,#d9d9d9);border-radius:3px;text-align:center;font-size:12px;" disabled> 页一组
              </label>
              <label class="split-radio-label">
                <input type="radio" name="split-mode" value="custom">
                自定义范围：
                <input type="text" id="split-custom-ranges" placeholder="例如: 1-3, 4-7, 8-10" disabled style="flex:1;height:28px;border:1px solid var(--border,#d9d9d9);border-radius:4px;padding:0 8px;font-size:12px;">
              </label>
            </div>
          </div>

          <div style="margin-bottom:16px;">
            <label style="display:block;margin-bottom:6px;font-weight:500;font-size:13px;">输出目录</label>
            <div style="display:flex;gap:8px;">
              <input type="text" id="split-output-dir" readonly style="flex:1;height:30px;border:1px solid var(--border,#d9d9d9);border-radius:4px;padding:0 8px;font-size:12px;background:#fafafa;">
              <button id="split-select-dir" class="btn-secondary">选择目录</button>
            </div>
          </div>

          <div id="split-result-area" style="display:none;padding:10px;border:1px solid var(--border,#d9d9d9);border-radius:4px;background:#fafafa;font-size:12px;max-height:150px;overflow-y:auto;"></div>
        </div>
        <div class="dialog-footer">
          <div class="dialog-footer-left">
            <span id="split-status-text" style="font-size:12px;color:var(--text-secondary,#616161);"></span>
          </div>
          <div class="dialog-footer-right">
            <button id="split-btn-cancel">取消</button>
            <button id="split-btn-execute" class="btn-primary" disabled>开始拆分</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(this.overlay);

    this._bindEvents();
  }

  _bindEvents() {
    const sel = (id) => this.overlay.querySelector(id);

    sel('#split-panel-close').addEventListener('click', () => this.hide());
    sel('#split-btn-cancel').addEventListener('click', () => this.hide());
    this.overlay.addEventListener('click', (e) => { if (e.target === this.overlay) this.hide(); });

    sel('#split-select-source').addEventListener('click', () => this._selectSource());
    sel('#split-select-dir').addEventListener('click', () => this._selectDir());
    sel('#split-btn-execute').addEventListener('click', () => this._executeSplit());

    // Radio mode switching
    const radios = this.overlay.querySelectorAll('input[name="split-mode"]');
    radios.forEach(r => r.addEventListener('change', () => this._onModeChange()));

    sel('#split-every-n').addEventListener('input', () => this._updateExecuteButton());
    sel('#split-custom-ranges').addEventListener('input', () => this._updateExecuteButton());
  }

  _sel(id) { return this.overlay.querySelector(id); }

  async open(filePath) {
    this.overlay.style.display = 'flex';
    this.sourcePath = null;
    this.totalPages = 0;
    this.outputDir = null;
    this._sel('#split-result-area').style.display = 'none';
    this._sel('#split-status-text').textContent = '';
    document.getElementById('status-text').textContent = '就绪';

    // Reset UI
    this._sel('input[name="split-mode"][value="single"]').checked = true;
    this._sel('#split-every-n').value = 2;
    this._sel('#split-every-n').disabled = true;
    this._sel('#split-custom-ranges').value = '';
    this._sel('#split-custom-ranges').disabled = true;
    this._sel('#split-source-path').value = '';
    this._sel('#split-output-dir').value = '';
    this._sel('#split-single-count').textContent = '0';
    this._sel('#split-btn-execute').disabled = true;

    // If a file path was provided, load it
    if (filePath) {
      await this._loadSource(filePath);
    }
  }

  hide() {
    this.overlay.style.display = 'none';
    document.getElementById('status-text').textContent = '就绪';
  }

  async _selectSource() {
    const files = await window.electronAPI.openPdfDialog();
    if (files && files.length > 0) {
      await this._loadSource(files[0]);
    }
  }

  async _loadSource(filePath) {
    try {
      const info = await window.electronAPI.getPDFInfo(filePath);
      this.sourcePath = filePath;
      this.totalPages = info.pages;
      this._sel('#split-source-path').value = info.name + ' (' + info.pages + ' 页)';
      this._sel('#split-single-count').textContent = info.pages;
      this._updateExecuteButton();
    } catch (e) {
      this._sel('#split-source-path').value = '加载失败: ' + e.message;
      this.sourcePath = null;
      this.totalPages = 0;
    }
  }

  async _selectDir() {
    const dir = await window.electronAPI.selectDirectory();
    if (dir) {
      this.outputDir = dir;
      this._sel('#split-output-dir').value = dir;
      this._updateExecuteButton();
    }
  }

  _onModeChange() {
    const mode = this.overlay.querySelector('input[name="split-mode"]:checked').value;
    this.splitMode = mode;
    this._sel('#split-every-n').disabled = mode !== 'everyN';
    this._sel('#split-custom-ranges').disabled = mode !== 'custom';
    this._updateExecuteButton();
  }

  _getRanges() {
    if (this.splitMode === 'single') {
      return Array.from({ length: this.totalPages }, (_, i) => [i + 1, i + 1]);
    } else if (this.splitMode === 'everyN') {
      const n = parseInt(this._sel('#split-every-n').value) || 1;
      const ranges = [];
      for (let i = 1; i <= this.totalPages; i += n) {
        ranges.push([i, Math.min(i + n - 1, this.totalPages)]);
      }
      return ranges;
    } else {
      const text = this._sel('#split-custom-ranges').value.trim();
      if (!text) return [];
      return text.split(',').map(s => {
        const parts = s.trim().split('-').map(Number);
        if (parts.length === 1) return [parts[0], parts[0]];
        return [parts[0], parts[1]];
      }).filter(r => !isNaN(r[0]) && !isNaN(r[1]) && r[0] <= r[1] && r[0] >= 1 && r[1] <= this.totalPages);
    }
  }

  _updateExecuteButton() {
    const hasSource = !!this.sourcePath;
    const hasOutput = !!this.outputDir;
    this._sel('#split-btn-execute').disabled = !hasSource || !hasOutput;
  }

  async _executeSplit() {
    const ranges = this._getRanges();
    if (ranges.length === 0) {
      this._sel('#split-status-text').textContent = '无效的拆分范围';
      return;
    }

    this._sel('#split-btn-execute').disabled = true;
    this._sel('#split-status-text').textContent = '正在拆分...';

    try {
      const results = await window.electronAPI.splitPDF(this.sourcePath, ranges, this.outputDir);
      this._showResults(results);
      this._sel('#split-status-text').textContent = '拆分完成（' + results.length + ' 个文件）';
    } catch (e) {
      this._sel('#split-status-text').textContent = '拆分失败: ' + e.message;
      this._sel('#split-btn-execute').disabled = false;
    }
  }

  _showResults(results) {
    const area = this._sel('#split-result-area');
    area.style.display = 'block';
    // Path separator regex: hoisted outside loop
    const sep = /[\\/]/;
    area.innerHTML = '<div style="font-weight:600;margin-bottom:6px;">生成的文件：</div>' +
      results.map((r, i) => `<div style="padding:2px 0;border-bottom:1px solid #eee;">${i + 1}. ${r.path.split(sep).pop()} (${r.pages} 页)</div>`).join('');
  }
}
