// ===== 通用工具函数 =====

// 统一的 CMap URL 获取函数，挂载到 window 供所有模块共享
function _getCmapUrl() {
  if (window.__cmapUrlCache !== undefined) return window.__cmapUrlCache;
  let url = '';
  try {
    // 打包环境：使用 asar.unpacked 中的 cmaps
    const rp = window.electronAPI && window.electronAPI.getResourcesPath
      ? window.electronAPI.getResourcesPath() : '';
    if (rp) {
      const cmapDir = rp.replace(/\\/g, '/') + '/app.asar.unpacked/node_modules/pdfjs-dist/cmaps/';
      url = 'file:///' + cmapDir.replace(/^\/+/, '');
    }
  } catch (e) {
    console.warn('[CMap] getResourcesPath failed:', e);
  }
  if (!url) {
    // 开发环境：使用相对路径
    const baseUrl = window.location.href.replace(/\/src\/index\.html.*$/, '');
    url = baseUrl + '/node_modules/pdfjs-dist/cmaps/';
  }
  window.__cmapUrlCache = url;
  console.log('[CMap] CMap URL:', url);
  return url;
}

// 暴露到 window，供 tabs.js / print-panel.js / page-manager.js 统一使用
window.getCMapUrl = _getCmapUrl;

// ===== 应用入口 =====
(function () {
  // Initialize PDF.js worker and CMap for Chinese font support
  // 策略：优先 asar.unpacked 路径 → 相对路径 → 内联 Blob Worker 兜底
  let resourcesPath = '';
  try {
    resourcesPath = window.electronAPI && window.electronAPI.getResourcesPath ? window.electronAPI.getResourcesPath() : '';
  } catch (e) { resourcesPath = ''; }

  let workerSrc = '';

  if (resourcesPath) {
    // 打包环境：从 asar.unpacked 加载 worker
    const unpackedBase = resourcesPath.replace(/\\/g, '/') + '/app.asar.unpacked/node_modules/pdfjs-dist';
    workerSrc = 'file:///' + unpackedBase.replace(/^\/+/, '') + '/build/pdf.worker.min.js';
  }

  if (!workerSrc) {
    // 开发环境：从 node_modules 加载
    const baseUrl = window.location.href.replace(/\/src\/index\.html.*$/, '');
    workerSrc = baseUrl + '/node_modules/pdfjs-dist/build/pdf.worker.min.js';
  }

  console.log('[PDF.js] Worker path:', workerSrc);
  pdfjsLib.GlobalWorkerOptions.workerSrc = workerSrc;

  // CMap 配置：使用统一的获取函数
  pdfjsLib.GlobalWorkerOptions.cMapUrl = _getCmapUrl();
  pdfjsLib.GlobalWorkerOptions.cMapPacked = true;

  // 验证 worker 是否可访问（仅记录警告，不阻断启动）
  fetch(workerSrc, { method: 'HEAD' }).catch(() => {
    console.warn('[PDF.js] Worker 文件可能不可访问:', workerSrc);
    console.warn('[PDF.js] 如果打开 PDF 失败，请检查打包后 app.asar.unpacked 目录是否存在');
  });

  console.log('[PDF.js] Init complete: worker=' + workerSrc + ', cmap=' + pdfjsLib.GlobalWorkerOptions.cMapUrl);

  // Initialize managers
  const tabManager = new TabManager();
  const printPanel = new PrintPanel();
  const splitPanel = new SplitPanel();
  const mergePanel = new MergePanel();
  const pageManager = new PageManager();

  // Wire print panel close → restore previous view
  printPanel.onClose = () => {
    if (tabManager.tabs.length === 0) {
      document.getElementById('welcome-screen').style.display = 'flex';
    } else {
      document.getElementById('viewer-container').style.display = 'block';
    }
  };

  // ===== Menu event listeners =====
  window.electronAPI.onOpenFile(async (filePath) => {
    await tabManager.openPdf(filePath);
  });
  window.electronAPI.onMenuOpenPdf(async () => {
    await tabManager.openPdfDialog();
  });
  window.electronAPI.onMenuInvoicePanel(() => {
    const filePaths = tabManager.tabs.map(t => t.filePath).filter(Boolean);
    printPanel.open(filePaths, 'invoice');
  });
  window.electronAPI.onMenuPrintPanel(() => {
    const filePaths = tabManager.tabs.map(t => t.filePath).filter(Boolean);
    printPanel.open(filePaths, 'document');
  });
  window.electronAPI.onMenuSplitPanel(() => {
    const activeTab = tabManager.getActiveTab();
    splitPanel.open(activeTab ? activeTab.filePath : null);
  });
  window.electronAPI.onMenuMergePanel(() => {
    mergePanel.open();
  });
  window.electronAPI.onMenuPagePanel(() => {
    const activeTab = tabManager.getActiveTab();
    pageManager.open(activeTab ? activeTab.filePath : null);
  });

  window.electronAPI.onViewFitWidth(() => {
    const tab = tabManager.getActiveTab();
    if (tab && tab.viewer) { tab.viewer.fitWidth(); }
  });
  window.electronAPI.onViewFitPage(() => {
    const tab = tabManager.getActiveTab();
    if (tab && tab.viewer) { tab.viewer.fitPage(); }
  });
  window.electronAPI.onViewActualSize(() => {
    const tab = tabManager.getActiveTab();
    if (tab && tab.viewer) { tab.viewer.actualSize(); updateZoomSelect(tab.scale); }
  });
  window.electronAPI.onViewZoomIn(() => {
    const tab = tabManager.getActiveTab();
    if (tab && tab.viewer) tab.viewer.zoomIn();
  });
  window.electronAPI.onViewZoomOut(() => {
    const tab = tabManager.getActiveTab();
    if (tab && tab.viewer) tab.viewer.zoomOut();
  });

  // ===== Custom input dialog for default view =====
  function showInputDialog(message, defaultValue) {
    return new Promise((resolve) => {
      // Create dialog overlay
      const overlay = document.createElement('div');
      overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
      `;

      const dialog = document.createElement('div');
      dialog.style.cssText = `
        background: white;
        border-radius: 8px;
        padding: 24px;
        min-width: 320px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.3);
      `;

      dialog.innerHTML = `
        <div style="margin-bottom: 16px; font-size: 14px; color: #333;">${message}</div>
        <input type="number" value="${defaultValue}" style="
          width: 100%;
          padding: 8px 12px;
          border: 1px solid #d9d9d9;
          border-radius: 4px;
          font-size: 14px;
          margin-bottom: 16px;
          box-sizing: border-box;
        ">
        <div style="display: flex; justify-content: flex-end; gap: 8px;">
          <button class="btn-cancel" style="
            padding: 6px 16px;
            border: 1px solid #d9d9d9;
            border-radius: 4px;
            background: white;
            cursor: pointer;
          ">取消</button>
          <button class="btn-ok" style="
            padding: 6px 16px;
            border: none;
            border-radius: 4px;
            background: #1890ff;
            color: white;
            cursor: pointer;
          ">确定</button>
        </div>
      `;

      overlay.appendChild(dialog);
      document.body.appendChild(overlay);

      const input = dialog.querySelector('input');
      const btnOk = dialog.querySelector('.btn-ok');
      const btnCancel = dialog.querySelector('.btn-cancel');

      input.focus();
      input.select();

      const handleOk = () => {
        const value = input.value;
        document.body.removeChild(overlay);
        resolve(value);
      };

      const handleCancel = () => {
        document.body.removeChild(overlay);
        resolve(null);
      };

      const handleKeydown = (e) => {
        if (e.key === 'Enter') {
          handleOk();
        } else if (e.key === 'Escape') {
          handleCancel();
        }
      };

      btnOk.addEventListener('click', handleOk);
      btnCancel.addEventListener('click', handleCancel);
      input.addEventListener('keydown', handleKeydown);
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) handleCancel();
      });
    });
  }

  window.electronAPI.onViewSetCustomDefault(async () => {
    // Show custom input dialog
    const input = await showInputDialog('请输入默认视图缩放比例（例如：100 表示 100%）<br>设置后将自动应用于所有打开的 PDF 文件', '100');
    if (input === null) return;

    const percentage = parseInt(input);
    if (isNaN(percentage) || percentage < 10 || percentage > 500) {
      alert('请输入 10 到 500 之间的数字');
      return;
    }

    const viewConfig = {
      type: 'custom',
      scale: percentage / 100,
      percentage: percentage
    };

    const saved = await window.electronAPI.setDefaultView(viewConfig);
    if (saved) {
      document.getElementById('status-text').textContent = `默认视图已设置为 ${percentage}%，将自动应用于所有 PDF 文件`;
    }
  });

  // ===== Toolbar buttons =====
  document.getElementById('btn-open').addEventListener('click', () => tabManager.openPdfDialog());
  document.getElementById('btn-invoice').addEventListener('click', () => {
    const filePaths = tabManager.tabs.map(t => t.filePath).filter(Boolean);
    printPanel.open(filePaths, 'invoice');
  });
  document.getElementById('btn-print-panel').addEventListener('click', () => printPanel.open(null, 'document'));

  document.getElementById('btn-zoom-in').addEventListener('click', () => {
    const tab = tabManager.getActiveTab();
    if (tab && tab.viewer) tab.viewer.zoomIn();
  });
  document.getElementById('btn-zoom-out').addEventListener('click', () => {
    const tab = tabManager.getActiveTab();
    if (tab && tab.viewer) tab.viewer.zoomOut();
  });

  document.getElementById('zoom-select').addEventListener('change', (e) => {
    const tab = tabManager.getActiveTab();
    if (!tab || !tab.viewer) return;

    const value = e.target.value;
    if (value === 'fit-width') {
      tab.viewer.fitWidth();
    } else if (value === 'fit-page') {
      tab.viewer.fitPage();
    } else {
      tab.viewer.setScale(parseFloat(value));
    }
    // Reset select to current scale
    updateZoomSelect(tab.scale);
  });

  document.getElementById('btn-prev').addEventListener('click', () => {
    const tab = tabManager.getActiveTab();
    if (tab && tab.viewer) tab.viewer.prevPage();
  });
  document.getElementById('btn-next').addEventListener('click', () => {
    const tab = tabManager.getActiveTab();
    if (tab && tab.viewer) tab.viewer.nextPage();
  });
  document.getElementById('page-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const tab = tabManager.getActiveTab();
      if (tab && tab.viewer) {
        const num = parseInt(e.target.value);
        if (!isNaN(num)) tab.viewer.goToPage(num);
      }
    }
  });

  // ===== Welcome screen buttons =====
  document.getElementById('welcome-open').addEventListener('click', () => tabManager.openPdfDialog());
  document.getElementById('welcome-invoice').addEventListener('click', () => printPanel.open(null, 'invoice'));
  document.getElementById('welcome-print').addEventListener('click', () => printPanel.open(null, 'document'));

  // ===== Drag and drop =====
  const contentArea = document.getElementById('content-area');

  function handleDragOver(e) {
    e.preventDefault();
    e.stopPropagation();
    e.dataTransfer.dropEffect = 'copy';
  }

  contentArea.addEventListener('dragover', handleDragOver);
  contentArea.addEventListener('drop', async (e) => {
    e.preventDefault();
    await handleDropFiles(e);
  });

  async function handleDropFiles(e) {
    const files = Array.from(e.dataTransfer.files);
    for (const file of files) {
      if (file.name.toLowerCase().endsWith('.pdf')) {
        await tabManager.openPdf(file.path);
      }
    }
  }

  // ===== Tab change handler =====
  tabManager.onTabChange = (tab) => {
    updateZoomSelect(tab.scale);
  };

  // Apply default view to a tab
  async function applyDefaultView(tab) {
    if (!tab || !tab.viewer) return;

    try {
      const viewConfig = await window.electronAPI.getDefaultView();
      if (!viewConfig) return;

      setTimeout(() => {
        switch (viewConfig.type) {
          case 'fit-width':
            tab.viewer.fitWidth();
            break;
          case 'fit-page':
            tab.viewer.fitPage();
            break;
          case 'actual-size':
            tab.viewer.actualSize();
            break;
          case 'custom':
            if (viewConfig.scale) {
              tab.viewer.setScale(viewConfig.scale);
            }
            break;
        }
        updateZoomSelect(tab.scale);
      }, 100);
    } catch (e) {
      console.error('Failed to apply default view:', e);
    }
  }

  function updateZoomSelect(scale) {
    const select = document.getElementById('zoom-select');
    const pct = Math.round(scale * 100);
    // Only set to predefined values if they match
    const predefined = [50, 75, 100, 125, 150, 200];
    if (predefined.includes(pct)) {
      select.value = String(pct / 100);
    } else {
      select.value = ''; // custom value
    }
  }

  // ===== Keyboard shortcuts (global) =====
  document.addEventListener('keydown', (e) => {
    const tab = tabManager.getActiveTab();
    if (!tab || !tab.viewer) return;

    // Don't handle if focus is in an input
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;

    switch (e.key) {
      case 'PageDown':
        e.preventDefault();
        tab.viewer.nextPage();
        break;
      case 'PageUp':
        e.preventDefault();
        tab.viewer.prevPage();
        break;
      case 'Home':
        e.preventDefault();
        tab.viewer.goToPage(1);
        break;
      case 'End':
        e.preventDefault();
        tab.viewer.goToPage(tab.totalPages);
        break;
    }
  });

  // ===== Ctrl+MouseWheel zoom (throttled with accumulation) =====
  let wheelZoomTimeout;
  let wheelAccumDelta = 0;
  contentArea.addEventListener('wheel', (e) => {
    if (e.ctrlKey) {
      e.preventDefault();
      wheelAccumDelta += e.deltaY > 0 ? -0.05 : 0.05;
      if (wheelZoomTimeout) return; // Throttle: process after interval
      wheelZoomTimeout = setTimeout(() => {
        wheelZoomTimeout = null;
        const delta = wheelAccumDelta;
        wheelAccumDelta = 0;
        const tab = tabManager.getActiveTab();
        if (tab && tab.viewer) {
          tab.viewer.setScale(tab.scale + delta);
          updateZoomSelect(tab.scale);
        }
      }, 80);
    }
  }, { passive: false });

  // ===== Window resize → re-render for fit modes =====
  let resizeTimeout;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(() => {
      const tab = tabManager.getActiveTab();
      if (tab && tab.viewer && tab.viewer.scrollMode === 'continuous') {
        tab.viewer.renderCurrentPage();
      }
    }, 200);
  });

  document.getElementById('status-text').textContent = '就绪';
})();
