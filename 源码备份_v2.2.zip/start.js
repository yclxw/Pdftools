const { spawn } = require('child_process');
const electronPath = require('electron');

// Remove ELECTRON_RUN_AS_NODE which breaks Electron
delete process.env.ELECTRON_RUN_AS_NODE;

const child = spawn(electronPath, ['.'], {
  stdio: 'inherit',
  env: process.env
});

child.on('close', (code) => process.exit(code));
