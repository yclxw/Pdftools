const { app, BrowserWindow, dialog, Menu, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const { execFile } = require('child_process');
const { PDFDocument, PageSizes, StandardFonts, rgb, degrees } = require('pdf-lib');
const fontkit = require('@pdf-lib/fontkit');

const pkg = require('./package.json');

let logPath = '';
function log(msg) {
  try {
    if (!logPath) {
      const userData = app.getPath('userData');
      logPath = path.join(userData, 'app.log');
    }
    const line = `[${new Date().toISOString()}] ${msg}\n`;
    fs.appendFileSync(logPath, line);
  } catch (_) {}
  console.log(msg);
}

let mainWindow;
let pendingFile = null;

// Helper: run PowerShell with UTF-16LE input; force PowerShell to output UTF-8
function runPowerShell(cmd, opts, callback) {
  const fullCmd = '$OutputEncoding = [Console]::OutputEncoding = [Text.Encoding]::UTF8; ' + cmd;
  const encoded = Buffer.from(fullCmd, 'utf16le').toString('base64');
  if (callback) {
    return execFile('powershell', ['-NoProfile', '-EncodedCommand', encoded], opts, callback);
  }
  return execFile('powershell', ['-NoProfile', '-EncodedCommand', encoded], opts);
}

// Helper: convert Uint8Array/Buffer to a clean ArrayBuffer for IPC transfer
function toArrayBuffer(data) {
  const buf = Buffer.from(data);
  return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
}

function createWindow() {
  log('Creating main window...');
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 800,
    minHeight: 600,
    title: '会计必备PDF工具',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'src', 'index.html'))
    .then(() => log('Main window loaded successfully'))
    .catch(err => log('Failed to load main window: ' + err.message));

  mainWindow.webContents.on('did-fail-load', (_, code, desc) => {
    log(`Page load failed: ${code} - ${desc}`);
  });

  mainWindow.webContents.on('console-message', (_, level, message) => {
    log(`[Renderer] ${message}`);
  });

  const menuTemplate = [
    {
      label: '阅读',
      click: () => sendToRenderer('menu:openPdf')
    },
    {
      label: '发票',
      click: () => sendToRenderer('menu:invoicePanel')
    },
    {
      label: '打印',
      click: () => sendToRenderer('menu:printPanel')
    },
    {
      label: '工具',
      submenu: [
        {
          label: '拆分文档',
          click: () => sendToRenderer('menu:splitPanel')
        },
        {
          label: '合并文档',
          click: () => sendToRenderer('menu:mergePanel')
        },
        {
          label: '页面管理',
          click: () => sendToRenderer('menu:pagePanel')
        }
      ]
    },
    {
      label: '视图',
      submenu: [
        {
          label: '默认视图定义',
          click: () => sendToRenderer('view:setCustomDefault')
        },
        { type: 'separator' },
        {
          label: '适应宽度',
          accelerator: 'CmdOrCtrl+1',
          click: () => sendToRenderer('view:fitWidth')
        },
        {
          label: '适应页面',
          accelerator: 'CmdOrCtrl+2',
          click: () => sendToRenderer('view:fitPage')
        },
        {
          label: '实际大小',
          accelerator: 'CmdOrCtrl+3',
          click: () => sendToRenderer('view:actualSize')
        },
        { type: 'separator' },
        { label: '放大', accelerator: 'CmdOrCtrl+=', click: () => sendToRenderer('view:zoomIn') },
        { label: '缩小', accelerator: 'CmdOrCtrl+-', click: () => sendToRenderer('view:zoomOut') },
        { type: 'separator' },
        { label: '切换开发者工具', role: 'toggleDevTools' }
      ]
    },
    {
      label: '帮助',
      submenu: [
        {
          label: '设为默认软件',
          click: () => setAsDefaultPdfViewer()
        },
        { type: 'separator' },
        {
          label: '关于',
          click: () => {
            const ver = pkg.version.split('.');
            const dateStr = ver.length === 3 ? `${ver[2].slice(0,4)}-${ver[2].slice(4,6)}-${ver[2].slice(6,8)}` : '';
            const shortVer = ver.length >= 2 ? `v${ver[0]}.${ver[1]}` : `v${pkg.version}`;
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: '关于 会计必备PDF工具',
              message: '会计必备PDF工具',
              detail: `版本: ${shortVer}\n日期: ${dateStr}\n平台: Windows 7 SP1 x64+ / Windows 11\n作者: 帅气的锅巴`
            });
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(menuTemplate);
  Menu.setApplicationMenu(menu);
}

function sendToRenderer(channel, ...args) {
  if (mainWindow && mainWindow.webContents) {
    mainWindow.webContents.send(channel, ...args);
  }
}

function setAsDefaultPdfViewer() {
  if (!app.isPackaged) {
    dialog.showMessageBox(mainWindow, {
      type: 'warning', title: '开发模式',
      message: '设为默认软件仅在安装后的打包版本中生效。'
    });
    return;
  }

  const appExe = app.getPath('exe');
  const appName = '会计必备PDF工具.exe';
  const openCmd = '\\"' + appExe + '\\" \\"%1\\"';
  const appReg = 'HKCU\\Software\\Classes\\Applications\\' + appName;

  // Step 1: Register app in Windows "Open With" list via registry
  const tasks = [
    // Register app command and friendly name for "Open With" dialog
    ['add', appReg + '\\shell\\open\\command', '/ve', '/d', openCmd, '/f'],
    ['add', appReg, '/v', 'FriendlyAppName', '/d', '会计必备PDF工具', '/f'],
    // Also set ProgID for proper file type display
    ['add', 'HKCU\\Software\\Classes\\Pdftools.pdf', '/ve', '/d', '会计必备PDF工具 文档', '/f'],
    ['add', 'HKCU\\Software\\Classes\\Pdftools.pdf\\DefaultIcon', '/ve', '/d', appExe + ',0', '/f'],
    ['add', 'HKCU\\Software\\Classes\\Pdftools.pdf\\shell\\open\\command', '/ve', '/d', openCmd, '/f'],
    // Set .pdf → ProgID at HKCU level (backup to UserChoice)
    ['add', 'HKCU\\Software\\Classes\\.pdf', '/ve', '/d', 'Pdftools.pdf', '/f'],
    // Also try HKLM for system-wide (admin needed, ignore errors)
    ['add', 'HKLM\\SOFTWARE\\Classes\\Applications\\' + appName + '\\shell\\open\\command', '/ve', '/d', openCmd, '/f'],
  ];

  let done = 0;
  let errors = [];
  for (const args of tasks) {
    execFile('reg', args, { windowsHide: true }, (err) => {
      if (err) {
        if (!args[1].startsWith('HKLM')) {
          errors.push(args[1]);
        }
        log('Reg: ' + err.message);
      }
      done++;
      if (done === tasks.length) {
        if (errors.length > 0) {
          log(`设为默认软件: 部分注册失败 (${errors.length}/${tasks.length})`);
        }
        openWithDialog();
      }
    });
  }

  function openWithDialog() {
    const tempPdf = path.join(app.getPath('temp'), '_pdftools_default_temp.pdf');
    const minPdf = Buffer.from(
      '%PDF-1.0\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n' +
      '2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n' +
      '3 0 obj<</Type/Page/MediaBox[0 0 612 792]/Parent 2 0 R>>endobj\n' +
      'xref\n0 4\n0000000000 65535 f \n0000000009 00000 n \n0000000058 00000 n \n0000000115 00000 n \n' +
      'trailer<</Size 4/Root 1 0 R>>\nstartxref\n190\n%%EOF',
      'ascii'
    );
    try {
      fs.writeFileSync(tempPdf, minPdf);
      execFile('rundll32', ['shell32.dll,OpenAs_RunDLL', tempPdf],
        { windowsHide: false }, (err) => {
          if (err) log('OpenWith: ' + err.message);
          setTimeout(() => { try { fs.unlinkSync(tempPdf); } catch (_) {} }, 10000);
        });
    } catch (e) {
      dialog.showErrorBox('错误', '无法启动关联设置。');
    }
    log('设为默认软件: OpenWith 对话框已打开');
  }
}

ipcMain.handle('dialog:openPdf', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: '打开PDF文件',
    filters: [{ name: 'PDF文件', extensions: ['pdf'] }],
    properties: ['openFile', 'multiSelections']
  });
  if (result.canceled) return [];
  return result.filePaths;
});

ipcMain.handle('dialog:selectInvoices', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: '选择发票文件进行拼版',
    filters: [{ name: 'PDF文件', extensions: ['pdf'] }],
    properties: ['openFile', 'multiSelections']
  });
  if (result.canceled) return [];
  return result.filePaths;
});

ipcMain.handle('fs:readFile', async (_, filePath) => {
  try {
    if (!fs.existsSync(filePath)) {
      throw new Error(`文件不存在: ${filePath}`);
    }
    const stat = fs.statSync(filePath);
    if (!stat.isFile()) {
      throw new Error(`路径不是文件: ${filePath}`);
    }
    if (stat.size === 0) {
      throw new Error(`文件为空: ${filePath}`);
    }
    const buffer = fs.readFileSync(filePath);
    log(`[fs:readFile] "${path.basename(filePath)}" — ${buffer.length} bytes`);
    return toArrayBuffer(buffer);
  } catch (e) {
    log(`[fs:readFile] 失败: ${e.message}`);
    throw new Error(`读取文件失败: ${e.message}`);
  }
});

ipcMain.handle('fs:getFileInfo', async (_, filePath) => {
  try {
    const stat = fs.statSync(filePath);
    return {
      name: path.basename(filePath),
      path: filePath,
      size: stat.size
    };
  } catch (e) {
    throw new Error(`获取文件信息失败: ${e.message}`);
  }
});

// Open Windows printer properties dialog
ipcMain.handle('print:printerProperties', async (_, printerName) => {
  return new Promise((resolve, reject) => {
    const args = ['printui.dll,PrintUIEntry', '/p', '/n', printerName];
    execFile('rundll32', args, { timeout: 15000, windowsHide: false }, (err) => {
      if (err) {
        log(`Printer properties error: ${err.message}`);
        reject(new Error(`无法打开打印机属性: ${err.message}`));
      } else {
        resolve();
      }
    });
  });
});

// Get Windows printer list
ipcMain.handle('print:getPrinters', async () => {
  // Windows 7 and 8/8.1 do not have Get-Printer (requires Win8+/Server2012+ with PrintManagement).
  // On those systems, skip the PowerShell attempt entirely to avoid a 10s timeout.
  const winVersion = process.platform === 'win32' ? require('os').release().split('.').map(Number) : [];
  const isLegacyWindows = winVersion.length > 0 && winVersion[0] < 10; // NT 6.x = Win7/8/8.1

  if (isLegacyWindows) {
    return getPrintersViaWmic();
  }

  return new Promise((resolve) => {
    runPowerShell(
      '(Get-Printer | Select-Object -ExpandProperty Name) -join "|"',
      { timeout: 10000, windowsHide: true }, (err, stdout) => {
        if (err) {
          getPrintersViaWmic().then(resolve);
          return;
        }
        const printers = stdout.trim().split('|').filter(Boolean);
        resolve(printers);
      });
  });
});

function getPrintersViaWmic() {
  return new Promise((resolve) => {
    execFile('wmic', ['printer', 'get', 'name'], { timeout: 10000, windowsHide: true, encoding: 'buffer' }, (err, stdout) => {
      if (err) { resolve([]); return; }
      let text;
      try {
        text = new TextDecoder('utf-8', { fatal: true }).decode(stdout);
      } catch {
        try {
          text = new TextDecoder('gbk').decode(stdout);
        } catch {
          text = stdout.toString('utf-8');
        }
      }
      const printers = [];
      const lines = text.split('\r\n');
      for (let i = 0; i < lines.length; i++) {
        const l = lines[i].trim();
        if (l && l !== 'Name' && !l.startsWith('===')) printers.push(l);
      }
      resolve(printers);
    });
  });
}

// Get SumatraPDF.exe path
// Priority: same directory as exe → extraResources → dev directory
function getSumatraPath() {
  const exeDir = app.isPackaged ? path.dirname(app.getPath('exe')) : __dirname;
  const candidates = [
    path.join(exeDir, 'SumatraPDF.exe'),
    path.join(exeDir, 'SumatraPDF', 'SumatraPDF.exe'),
    path.join(process.resourcesPath, 'SumatraPDF.exe'),
    path.join(process.resourcesPath, 'SumatraPDF', 'SumatraPDF.exe'),
  ];
  for (const p of candidates) {
    log(`Search SumatraPDF: ${p}`);
    if (fs.existsSync(p)) return p;
  }
  log('SumatraPDF.exe not found in any candidate path');
  return candidates[0];
}

// Imposition engine: 2-in-1 vector imposition using pdf-lib
// All files (single or multiple) use the same 2-in-1 A4 layout with configurable margins.
// Each invoice is scaled to fit the available width; height scales proportionally.
async function runImposition(filePaths, options = {}) {
  const outputDoc = await PDFDocument.create();

  const A4_WIDTH = PageSizes.A4[0];   // 595.28
  const A4_HEIGHT = PageSizes.A4[1];  // 841.89
  const marginCm = options.marginCm != null ? options.marginCm : 1.0;
  const MARGIN = marginCm * 28.35;    // cm to points
  const availWidth = A4_WIDTH - 2 * MARGIN;
  const availHeight = A4_HEIGHT - 2 * MARGIN;
  const halfHeight = availHeight / 2;

  const font = await outputDoc.embedFont(StandardFonts.Helvetica);

  for (let i = 0; i < filePaths.length; i += 2) {
    const page = outputDoc.addPage([A4_WIDTH, A4_HEIGHT]);

    // Top half - first invoice (fills top, bottom-aligns to center line)
    const topY = MARGIN + halfHeight;
    await _embedInvoice(outputDoc, page, filePaths[i], font, MARGIN, topY, availWidth, halfHeight, 'top');

    // Bottom half - second invoice if exists (fills bottom, top-aligns to center line)
    if (i + 1 < filePaths.length) {
      await _embedInvoice(outputDoc, page, filePaths[i + 1], font, MARGIN, MARGIN, availWidth, halfHeight, 'bottom');
    }
  }

  return await outputDoc.save();
}

async function _embedInvoice(outputDoc, targetPage, sourcePath, font, x, y, maxWidth, maxHeight, alignTo) {
  try {
    const srcBytes = fs.readFileSync(sourcePath);
    const srcDoc = await PDFDocument.load(srcBytes);
    const srcPages = srcDoc.getPages();
    if (srcPages.length === 0) return;

    let embeddedPage;
    try {
      [embeddedPage] = await outputDoc.embedPdf(srcDoc, [0]);
    } catch (embedErr) {
      log(`嵌入发票失败 (embedPdf): ${embedErr.message}, 尝试 copyPages fallback`);
      try {
        const [fallbackPage] = await outputDoc.copyPages(srcDoc, [0]);
        if (fallbackPage) {
          const { width: fw, height: fh } = fallbackPage.getSize();
          const blankScale = maxWidth / fw;
          targetPage.drawPage(fallbackPage, {
            x: x + (maxWidth - fw * blankScale) / 2,
            y: alignTo === 'top' ? y + maxHeight - fh * blankScale : y,
            width: fw * blankScale,
            height: fh * blankScale
          });
        }
      } catch (fbErr) {
        log(`嵌入发票 copyPages 也失败: ${fbErr.message}`);
      }
      return;
    }
    const dims = embeddedPage.size();
    const width = dims.width;
    const height = dims.height;
    if (!width || !height) return;

    // Scale to fit width; height scales proportionally (may overflow half-area)
    const fitScale = maxWidth / width;
    const drawW = width * fitScale;
    const drawH = height * fitScale;

    const drawX = x + (maxWidth - drawW) / 2;
    let drawY;
    if (alignTo === 'top') {
      drawY = y + maxHeight - drawH;
    } else if (alignTo === 'bottom') {
      drawY = y;
    } else {
      drawY = y + (maxHeight - drawH) / 2;
    }

    targetPage.drawPage(embeddedPage, {
      x: drawX,
      y: drawY,
      width: drawW,
      height: drawH
    });
  } catch (e) {
    log(`嵌入发票失败: ${e.message}`);
    targetPage.drawText('Error: ' + (e.message || '').replace(/[^\x00-\x7F]/g, ''), {
      x: x + 10,
      y: y + maxHeight / 2,
      size: 10,
      font: font,
      color: rgb(0.8, 0.2, 0.2)
    });
  }
}

// ============================================================
// Print mode: Invoice (发票模式)
// 2-in-1 imposition on A4, then silent print via SumatraPDF
// Supports multi-copy: imposition runs once, printed N times
// ============================================================
async function printInvoiceMode(filePaths, printerName, options = {}) {
  const copies = options.copies || 1;
  const totalPairs = Math.ceil(filePaths.length / 2);

  // Stage 1: Imposition (run once for all copies)
  // Use cached bytes from preview if available to avoid redundant work
  let pdfBytes;
  if (options._cachedPdfBytes) {
    log(`[Invoice] Using cached preview bytes, skipping re-imposition`);
    pdfBytes = Buffer.from(options._cachedPdfBytes);
    sendToRenderer('print:progress', {
      stage: 'imposition',
      current: totalPairs,
      total: totalPairs,
      message: copies > 1 ? `将打印 ${copies} 份...` : '正在准备打印...'
    });
  } else {
    sendToRenderer('print:progress', {
      stage: 'imposition',
      current: 0,
      total: totalPairs,
      message: `正在拼版 ${filePaths.length} 个文件...`
    });
    log(`[Invoice] Starting imposition for ${filePaths.length} files → ${totalPairs} A4 pages, ${copies} copies`);
    pdfBytes = await runImposition(filePaths, options);
    // Apply mask overlay if configured
    if (options.maskBlocks && options.maskBlocks.length > 0) {
      log(`[Invoice] Applying mask (${options.maskBlocks.length} blocks)`);
      pdfBytes = Buffer.from(await applyMaskToPdf(pdfBytes, options.maskBlocks, {
        batchSize: 0,
        onProgress: (done, total) => {
          sendToRenderer('print:progress', {
            stage: 'masking', current: done, total,
            message: `正在应用遮挡 (${done}/${total})...`
          });
        }
      }));
    }
    sendToRenderer('print:progress', {
      stage: 'imposition',
      current: totalPairs,
      total: totalPairs,
      message: copies > 1 ? `拼版完成，将打印 ${copies} 份...` : '拼版完成，正在准备打印...'
    });
  }

  // Stage 2: Write temp PDF
  const tempDir = app.getPath('temp');
  const tempPdfPath = path.join(tempDir, `invoice_print_${Date.now()}.pdf`);
  fs.writeFileSync(tempPdfPath, Buffer.from(pdfBytes));
  log(`[Invoice] Temp PDF written: ${tempPdfPath}`);

  // Stage 3: Print N copies via SumatraPDF
  for (let copy = 1; copy <= copies; copy++) {
    if (copies > 1) {
      sendToRenderer('print:progress', {
        stage: 'printing',
        current: copy,
        total: copies,
        message: `正在打印第 ${copy}/${copies} 份...`
      });
    } else {
      sendToRenderer('print:progress', {
        stage: 'printing',
        current: 0,
        total: 1,
        message: '正在发送到打印机...'
      });
    }

    log(`[Invoice] Printing copy ${copy}/${copies} → "${printerName}"`);
    await _sumatraPrint(tempPdfPath, printerName, copy === copies);
  }

  sendToRenderer('print:progress', {
    stage: 'done',
    current: copies,
    total: copies,
    message: `打印完成（共 ${copies} 份）`
  });
  log(`[Invoice] Complete: ${copies} copies printed`);
}

// ============================================================
// Print mode: Document (文件模式)
// Direct print without imposition, supports multi-copy, batch,
// auto-rotate and portrait/landscape orientation
// ============================================================
async function printDocumentMode(filePaths, printerName, options = {}) {
  const copies = options.copies || 1;
  const results = { success: [], failed: [], totalFiles: filePaths.length, totalCopies: 0 };

  for (let fi = 0; fi < filePaths.length; fi++) {
    const fp = filePaths[fi];
    const fileName = path.basename(fp);

    // Pre-process: apply page orientation if needed
    let printPath = fp;
    let tempPath = null;
    const needsTransform = (options.pageOrientation && options.pageOrientation !== 'auto') ||
                           (options.paperOrientation && options.paperOrientation !== 'auto');
    const needsMask = options.maskBlocks && options.maskBlocks.length > 0;

    if (needsTransform) {
      try {
        const pdfBytes = await applyPrintSettings(fp, options);
        tempPath = path.join(app.getPath('temp'), `doc_transformed_${Date.now()}_${fi}.pdf`);
        fs.writeFileSync(tempPath, Buffer.from(pdfBytes));
        printPath = tempPath;
        log(`[Document] Transformed "${fileName}": pageOrientation=${options.pageOrientation}, paperOrientation=${options.paperOrientation}`);
      } catch (e) {
        log(`[Document] Transform failed for "${fileName}": ${e.message}, using original`);
        // Fall back to original file if transform fails
      }
    }

    // Apply mask overlay after transform (or directly on original if no transform)
    if (needsMask) {
      try {
        const currentBytes = fs.readFileSync(printPath);
        log(`[Document] Applying mask to "${fileName}" (${currentBytes.length} bytes)...`);
        const maskedBytes = await applyMaskToPdf(currentBytes, options.maskBlocks, {
          batchSize: 200,
          onProgress: (done, total) => {
            sendToRenderer('print:progress', {
              stage: 'masking', current: done, total,
              message: `正在遮挡 ${fileName} (${done}/${total})...`
            });
          }
        });
        // Write masked result to new temp file
        const maskTempPath = path.join(app.getPath('temp'), `doc_masked_${Date.now()}_${fi}.pdf`);
        fs.writeFileSync(maskTempPath, Buffer.from(maskedBytes));
        // Clean up previous transform temp file AFTER mask write succeeds
        if (tempPath) { try { fs.unlinkSync(tempPath); } catch (_) {} }
        tempPath = maskTempPath;
        printPath = tempPath;
        log(`[Document] Mask applied to "${fileName}": ${maskedBytes.length} bytes`);
      } catch (e) {
        log(`[Document] Mask failed for "${fileName}": ${e.message}, using unmasked`);
        // Fall back to unmasked file if mask fails (keep transform temp if it exists)
      }
    }

    for (let ci = 0; ci < copies; ci++) {
      results.totalCopies++;
      const copyLabel = copies > 1 ? ` (第${ci + 1}/${copies}份)` : '';
      const progressTotal = filePaths.length * copies;
      const progressCurrent = fi * copies + ci + 1;

      sendToRenderer('print:progress', {
        stage: 'printing',
        current: progressCurrent,
        total: progressTotal,
        message: `正在打印 ${fileName}${copyLabel} (${progressCurrent}/${progressTotal})`
      });

      log(`[Document] Printing "${fileName}" copy ${ci + 1}/${copies} → "${printerName}"`);

      try {
        await _sumatraPrint(printPath, printerName, false);
      } catch (e) {
        log(`[Document] Print failed for "${fileName}": ${e.message}`);
        results.failed.push({ path: fp, name: fileName, error: e.message });
        // Clean up temp file and reset to original for remaining copies
        if (tempPath) { try { fs.unlinkSync(tempPath); } catch (_) {} tempPath = null; }
        printPath = fp;
        if (!options.continueOnError) {
          sendToRenderer('print:progress', {
            stage: 'done',
            current: progressCurrent,
            total: progressTotal,
            message: `打印中断：成功 ${results.success.length}，失败 ${results.failed.length}`
          });
          throw new Error(`打印 "${fileName}" 失败: ${e.message}`);
        }
        continue;
      }
      results.success.push(fp);
    }

    // Clean up temp file after all copies of this file
    if (tempPath) {
      try { fs.unlinkSync(tempPath); } catch (_) {}
      tempPath = null;
    }
  }

  // Final progress report
  sendToRenderer('print:progress', {
    stage: 'done',
    current: results.totalCopies,
    total: results.totalCopies,
    message: `打印完成：成功 ${results.success.length}，失败 ${results.failed.length}`
  });

  log(`[Document] Batch complete: ${results.success.length} OK, ${results.failed.length} failed`);
  return results;
}

// Helper: parse page range string like "1-3,5,7-9" into array of page numbers
function parsePageRange(rangeStr, totalPages) {
  if (!rangeStr || rangeStr.trim() === '') {
    return Array.from({ length: totalPages }, (_, i) => i + 1);
  }

  const pages = new Set();
  const parts = rangeStr.split(',').map(p => p.trim()).filter(p => p);

  for (const part of parts) {
    if (part.includes('-')) {
      // Range like "1-3"
      const [start, end] = part.split('-').map(n => parseInt(n.trim()));
      if (!isNaN(start) && !isNaN(end)) {
        const from = Math.max(1, Math.min(start, end));
        const to = Math.min(totalPages, Math.max(start, end));
        for (let i = from; i <= to; i++) {
          pages.add(i);
        }
      }
    } else {
      // Single page like "5"
      const pageNum = parseInt(part);
      if (!isNaN(pageNum) && pageNum >= 1 && pageNum <= totalPages) {
        pages.add(pageNum);
      }
    }
  }

  return Array.from(pages).sort((a, b) => a - b);
}

// Helper: extract specific pages from PDF document
async function extractPages(srcDoc, pageNumbers) {
  const newDoc = await PDFDocument.create();
  const indices = pageNumbers.map(n => n - 1);
  for (const idx of indices) {
    try {
      const [p] = await newDoc.copyPages(srcDoc, [idx]);
      newDoc.addPage(p);
    } catch (pageErr) {
      log(`[extractPages] Skipping page ${idx + 1}: ${pageErr.message}`);
      newDoc.addPage();
    }
  }
  return newDoc;
}

// ============================================================
// Apply print settings: page orientation + page range filtering
// Uses pdf-lib to rotate pages and extract page ranges before printing
// ============================================================
async function applyPrintSettings(filePath, options = {}) {
  log(`[applyPrintSettings] file=${path.basename(filePath)}, pageOrientation=${options.pageOrientation}, paperOrientation=${options.paperOrientation}, pageRangeMode=${options.pageRangeMode}, pageRangeValue=${options.pageRangeValue}`);

  const srcBytes = fs.readFileSync(filePath);
  let srcDoc = await PDFDocument.load(srcBytes);
  let pages = srcDoc.getPages();

  log(`[applyPrintSettings] Loaded ${pages.length} pages`);

  // Step 1: Apply page range filtering if needed
  if (options.pageRangeMode === 'custom' && options.pageRangeValue) {
    const totalPages = pages.length;
    const selectedPages = parsePageRange(options.pageRangeValue, totalPages);

    if (selectedPages.length === 0) {
      log(`[applyPrintSettings] No valid pages in range, using all pages`);
    } else if (selectedPages.length < totalPages) {
      log(`[applyPrintSettings] Extracting pages: ${selectedPages.join(', ')} (${selectedPages.length}/${totalPages})`);
      srcDoc = await extractPages(srcDoc, selectedPages);
      pages = srcDoc.getPages();
      log(`[applyPrintSettings] After extraction: ${pages.length} pages`);
    } else {
      log(`[applyPrintSettings] All pages selected, no extraction needed`);
    }
  }

  // Determine effective orientation: paperOrientation takes priority (physical constraint),
  // pageOrientation is used when paperOrientation is 'auto'
  const pageOrientValue = options.pageOrientation || 'auto';
  const paperOrientValue = options.paperOrientation || 'auto';
  const effectiveOrientation = paperOrientValue !== 'auto' ? paperOrientValue :
                                (pageOrientValue !== 'auto' ? pageOrientValue : 'auto');

  if (effectiveOrientation === 'auto') {
    log(`[applyPrintSettings] Both orientations are auto, no rotation needed`);
    return await srcDoc.save(); // No changes needed
  }

  const targetPageIsLandscape = effectiveOrientation === 'landscape';
  log(`[applyPrintSettings] Target orientation: ${targetPageIsLandscape ? 'landscape' : 'portrait'} (page=${pageOrientValue}, paper=${paperOrientValue})`);

  for (let i = 0; i < pages.length; i++) {
    const page = pages[i];
    const { width, height } = page.getSize();
    if (!width || !height) {
      log(`[applyPrintSettings] Page ${i + 1}: invalid size, skipping`);
      continue;
    }

    const mediaIsLandscape = width > height;
    let currentRotation = 0;
    try {
      const rot = page.getRotation();
      currentRotation = rot ? rot.angle : 0;
    } catch (e) {
      currentRotation = 0;
    }
    // Effective visual orientation: rotation 90/270 swaps the MediaBox dimensions visually
    const effectiveIsLandscape = (currentRotation % 180 === 0) ? mediaIsLandscape : !mediaIsLandscape;

    log(`[applyPrintSettings] Page ${i + 1}: ${width}x${height}, mediaLandscape=${mediaIsLandscape}, effectiveLandscape=${effectiveIsLandscape}, currentRotation=${currentRotation}`);

    // Check if rotation is needed (compare effective visual orientation to target)
    if (effectiveIsLandscape !== targetPageIsLandscape) {
      // Calculate new rotation: add 90 degrees to current rotation
      const newRotation = (currentRotation + 90) % 360;

      // Ensure newRotation is a multiple of 90
      const normalizedRotation = Math.round(newRotation / 90) * 90;

      page.setRotation(degrees(normalizedRotation));
      log(`[applyPrintSettings] Page ${i + 1}: rotated from ${effectiveIsLandscape ? 'landscape' : 'portrait'} to ${targetPageIsLandscape ? 'landscape' : 'portrait'}, rotation: ${currentRotation}° → ${normalizedRotation}°`);
    } else {
      log(`[applyPrintSettings] Page ${i + 1}: already in desired orientation (${targetPageIsLandscape ? 'landscape' : 'portrait'})`);
    }
  }

  const result = await srcDoc.save();
  log(`[applyPrintSettings] Saved: ${result.length} bytes`);
  return result;
}

// ============================================================
// SumatraPDF silent print executor
// Always uses silent mode: -print-to <printer> -exit-when-done -silent
// ============================================================
async function _sumatraPrint(pdfPath, printerName, cleanupTemp = false) {
  const sumatraPath = getSumatraPath();
  if (!fs.existsSync(sumatraPath)) {
    throw new Error(
      `未找到 SumatraPDF.exe\n请将 SumatraPDF.exe 放置在:\n${path.dirname(sumatraPath)}`
    );
  }

  return new Promise((resolve, reject) => {
    const args = ['-print-to', printerName, '-exit-when-done', '-silent', pdfPath];
    log(`[Sumatra] Silent print to "${printerName}": ${path.basename(pdfPath)}`);

    execFile(sumatraPath, args, {
      timeout: 120000,
      windowsHide: true
    }, (err) => {
      // Clean up temp file if requested (last copy)
      if (cleanupTemp) {
        try { fs.unlinkSync(pdfPath); } catch (_) {}
      }

      if (err) {
        log(`[Sumatra] Error: ${err.message}`);
        reject(new Error(`打印失败: ${err.message}`));
      } else {
        log('[Sumatra] OK');
        resolve();
      }
    });
  });
}

// Main print IPC handler: route by mode
ipcMain.handle('print:executePrint', async (_, filePaths, printerName, options = {}) => {
  try {
    log(`Print: mode=${options.mode || 'invoice'}, files=${filePaths.length}, printer="${printerName}", copies=${options.copies || 1}`);

    if (options.mode === 'document') {
      return await printDocumentMode(filePaths, printerName, options);
    } else {
      // Default: invoice mode (backward compatible)
      return await printInvoiceMode(filePaths, printerName, options);
    }
  } catch (e) {
    log(`Print pipeline error: ${e.message}`);
    sendToRenderer('print:progress', {
      stage: 'error',
      message: e.message
    });
    throw e;
  }
});

// ============================================================
// PDF split: extract pages into separate PDF files
// Each page is copied individually so a single missing-Contents
// page doesn't crash the entire operation.
// ============================================================
ipcMain.handle('pdf:split', async (_, filePath, ranges, outputDir) => {
  log(`[Split] Splitting "${path.basename(filePath)}" into ${ranges.length} parts`);
  const srcBytes = fs.readFileSync(filePath);
  const srcDoc = await PDFDocument.load(srcBytes);
  const results = [];

  for (let i = 0; i < ranges.length; i++) {
    const [start, end] = ranges[i];
    const newDoc = await PDFDocument.create();
    const indices = Array.from(
      { length: end - start + 1 },
      (_, idx) => start - 1 + idx
    );
    let copiedCount = 0;
    for (const idx of indices) {
      try {
        const [page] = await newDoc.copyPages(srcDoc, [idx]);
        newDoc.addPage(page);
        copiedCount++;
      } catch (pageErr) {
        log(`[Split] Skipping page ${idx + 1}: ${pageErr.message}`);
        newDoc.addPage();
        copiedCount++;
      }
    }

    const outBytes = await newDoc.save();
    const baseName = path.basename(filePath, '.pdf');
    const outPath = path.join(outputDir, `${baseName}_part${i + 1}.pdf`);
    fs.writeFileSync(outPath, Buffer.from(outBytes));
    results.push({ path: outPath, pages: copiedCount });
    log(`[Split] Part ${i + 1}: ${outPath} (pages ${start}-${end}, copied ${copiedCount})`);
  }

  return results;
});

// ============================================================
// PDF merge: combine multiple PDFs into one
// Each page is copied individually so a single missing-Contents
// page doesn't crash the entire operation.
// ============================================================
ipcMain.handle('pdf:merge', async (_, filePaths, outputPath) => {
  log(`[Merge] Merging ${filePaths.length} files → "${path.basename(outputPath)}"`);
  const mergedDoc = await PDFDocument.create();

  for (const fp of filePaths) {
    try {
      const srcBytes = fs.readFileSync(fp);
      const srcDoc = await PDFDocument.load(srcBytes);
      const pageIndices = srcDoc.getPageIndices();
      for (const idx of pageIndices) {
        try {
          const [page] = await mergedDoc.copyPages(srcDoc, [idx]);
          mergedDoc.addPage(page);
        } catch (pageErr) {
          log(`[Merge] Skipping page ${idx + 1} in "${path.basename(fp)}": ${pageErr.message}`);
          mergedDoc.addPage();
        }
      }
    } catch (e) {
      log(`[Merge] Skipping file "${path.basename(fp)}": ${e.message}`);
    }
  }

  const outBytes = await mergedDoc.save();
  fs.writeFileSync(outputPath, Buffer.from(outBytes));
  const totalPages = mergedDoc.getPageCount();
  log(`[Merge] Complete: ${outputPath} (${totalPages} pages)`);

  return { outputPath, totalPages };
});

// ============================================================
// Page Manager: get page info and save page changes
// ============================================================
ipcMain.handle('pdf:getPageInfo', async (_, filePath) => {
  try {
    const srcBytes = fs.readFileSync(filePath);
    const srcDoc = await PDFDocument.load(srcBytes);
    const pages = srcDoc.getPages();
    return pages.map(page => ({
      rotation: page.getRotation().angle
    }));
  } catch (e) {
    return [];
  }
});

ipcMain.handle('pdf:savePageChanges', async (_, args) => {
  try {
    const { sourcePath, outputPath, pageChanges } = typeof args === 'object' && args.sourcePath
      ? args
      : { sourcePath: args, outputPath: args, pageChanges: arguments[2] };

    // Read source PDF
    const srcBytes = fs.readFileSync(sourcePath);
    const srcDoc = await PDFDocument.load(srcBytes);
    const finalDoc = await PDFDocument.create();

    for (const change of pageChanges) {
      if (!change.deleted) {
        if (change.isBlank) {
          finalDoc.addPage([612, 792]);
        } else {
          try {
            const [page] = await finalDoc.copyPages(srcDoc, [change.originalIndex]);
            page.setRotation(degrees(change.rotation || 0));
            finalDoc.addPage(page);
          } catch (pageErr) {
            log(`[savePageChanges] Skipping page originalIndex=${change.originalIndex}: ${pageErr.message}`);
            finalDoc.addPage([612, 792]);
          }
        }
      }
    }

    const outBytes = await finalDoc.save();
    const tempPath = outputPath + '.tmp';
    fs.writeFileSync(tempPath, outBytes);
    if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
    fs.renameSync(tempPath, outputPath);

    return { success: true, path: outputPath };
  } catch (e) {
    throw new Error('保存页面更改失败: ' + e.message);
  }
});

// ============================================================
// PDF info: get page count and file size
// ============================================================
ipcMain.handle('pdf:getInfo', async (_, filePath) => {
  try {
    const stat = fs.statSync(filePath);
    const srcBytes = fs.readFileSync(filePath);
    const srcDoc = await PDFDocument.load(srcBytes);
    return {
      name: path.basename(filePath),
      path: filePath,
      size: stat.size,
      pages: srcDoc.getPageCount()
    };
  } catch (e) {
    throw new Error(`获取PDF信息失败: ${e.message}`);
  }
});

// ============================================================
// Mask engine: overlay white blocks + custom text on PDF pages
// ============================================================
const MM_TO_PT = 2.83464567; // 1 mm = 72/25.4 pt

/** Parse hex color string (#RRGGBB) to {r,g,b} values in 0-1 range */
function hexToRgb(hex) {
  if (!hex || typeof hex !== 'string') return { r: 0, g: 0, b: 0 };
  let h = hex.replace('#', '');
  if (h.length === 3) h = h[0]+h[0]+h[1]+h[1]+h[2]+h[2];
  if (h.length !== 6) return { r: 0, g: 0, b: 0 };
  return {
    r: parseInt(h.slice(0,2), 16) / 255,
    g: parseInt(h.slice(2,4), 16) / 255,
    b: parseInt(h.slice(4,6), 16) / 255,
  };
}

/** Check if a string contains any CJK (Chinese/Japanese/Korean) characters */
function containsCJK(str) {
  if (!str) return false;
  for (let i = 0; i < str.length; i++) {
    const code = str.charCodeAt(i);
    // CJK Unified Ideographs, CJK Radicals, Fullwidth Forms, etc.
    if (code > 0x2E80) return true;
  }
  return false;
}

/**
 * Build a single-page overlay PDF containing colored rectangles + optional text
 * The overlay is built once then applied to every page via embedPdf + drawPage,
 * which is far more efficient than drawing N rectangles per page.
 *
 * @param {number} pageW - Page width in PDF points
 * @param {number} pageH - Page height in PDF points
 * @param {Array} blocks - Mask block configs (coords in mm, from top-left)
 * @returns {Promise<Uint8Array>} Overlay PDF bytes
 */
async function buildMaskTemplate(pageW, pageH, blocks) {
  const overlayDoc = await PDFDocument.create();
  // Register fontkit to enable custom TTF/TTC font embedding
  overlayDoc.registerFontkit(fontkit);
  const overlayPage = overlayDoc.addPage([pageW, pageH]);

  // Try to embed a CJK font — iterate all candidates until one works
  const fontCandidates = [
    { path: 'C:/Windows/Fonts/simfang.ttf', name: '仿宋' },
    { path: 'C:/Windows/Fonts/simhei.ttf', name: '黑体' },
    { path: 'C:/Windows/Fonts/simkai.ttf', name: '楷体' },
    { path: 'C:/Windows/Fonts/simsunb.ttf', name: '宋体粗体' },
    { path: 'C:/Windows/Fonts/msyh.ttc', name: '微软雅黑' },
  ];
  let cjkFont = null;
  let cjkFontName = '';

  for (const fc of fontCandidates) {
    if (!fs.existsSync(fc.path)) {
      log(`[Mask] Font not found: ${fc.path}`);
      continue;
    }
    try {
      const fBytes = fs.readFileSync(fc.path);
      log(`[Mask] Trying to embed ${fc.name} (${fBytes.length} bytes)...`);

      // Try with subset option first (smaller output, faster)
      try {
        cjkFont = await overlayDoc.embedFont(fBytes, { subset: true });
        cjkFontName = fc.name;
        log(`[Mask] CJK font embedded (subset): ${fc.name}`);
        break;
      } catch (e1) {
        log(`[Mask] Subset embed failed: ${e1.message}`);
      }

      // Try full embed as fallback
      try {
        cjkFont = await overlayDoc.embedFont(fBytes);
        cjkFontName = fc.name;
        log(`[Mask] CJK font embedded (full): ${fc.name}`);
        break;
      } catch (e2) {
        log(`[Mask] Full embed failed: ${e2.message}`);
      }

    } catch (e) {
      log(`[Mask] Font ${fc.name} failed completely: ${e.message}`);
    }
  }

  // If TTF/TTC fonts all failed, try TTC with fontIndex as last resort
  if (!cjkFont) {
    const ttcCandidates = [
      { path: 'C:/Windows/Fonts/simsun.ttc', name: '宋体' },
      { path: 'C:/Windows/Fonts/msyh.ttc', name: '微软雅黑' },
    ];
    for (const fc of ttcCandidates) {
      if (!fs.existsSync(fc.path)) continue;
      try {
        const fBytes = fs.readFileSync(fc.path);
        cjkFont = await overlayDoc.embedFont(fBytes, { fontIndex: 0, subset: true });
        cjkFontName = fc.name;
        log(`[Mask] CJK font embedded (TTC): ${fc.name}`);
        break;
      } catch (e) {
        log(`[Mask] TTC ${fc.name} failed: ${e.message}`);
      }
    }
  }

  if (!cjkFont) {
    log(`[Mask] WARNING: No CJK font could be embedded! Chinese text will not render.`);
    const hasCJKText = blocks.some(b => b.text && containsCJK(b.text));
    if (hasCJKText) {
      sendToRenderer('print:progress', {
        stage: 'masking',
        message: '警告：系统中未找到中文字体文件，遮挡文字中的中文可能无法显示。请确认 C:\\Windows\\Fonts 目录下存在 simhei.ttf 或 simfang.ttf 等字体文件。'
      });
    }
  }

  // Embed standard font as fallback for ASCII-only text
  let helvFont = null;
  try { helvFont = await overlayDoc.embedFont(StandardFonts.Helvetica); } catch (_) {}

  for (const block of blocks) {
    const xPt = block.x * MM_TO_PT;
    const yPt = pageH - block.y * MM_TO_PT - block.height * MM_TO_PT; // bottom-up
    const wPt = block.width * MM_TO_PT;
    const hPt = block.height * MM_TO_PT;

    // Background rectangle (opaque, no border)
    const bc = hexToRgb(block.bgColor);
    overlayPage.drawRectangle({
      x: xPt,
      y: yPt,
      width: wPt,
      height: hPt,
      color: bc,
      borderColor: bc,
      borderWidth: 0
    });

    // Draw overlay text if provided
    if (block.text && block.text.trim()) {
      const drawFont = (cjkFont && containsCJK(block.text)) ? cjkFont : helvFont;
      if (drawFont) {
        const fontSize = block.fontSize || 12;
        const tc = hexToRgb(block.textColor || '#000000');
        overlayPage.drawText(block.text, {
          x: xPt + 4,
          y: yPt + hPt / 2 - fontSize / 2,
          size: fontSize,
          font: drawFont,
          color: tc
        });
      }
    }
  }

  return await overlayDoc.save();
}

/**
 * Apply mask overlay to all pages of a PDF document.
 * Builds the overlay template once, then applies to all pages.
 * Supports batching for large documents to control memory.
 *
 * @param {Buffer|Uint8Array} srcBytes - Source PDF bytes
 * @param {Array} blocks - Mask block definitions (mm, top-left)
 * @param {Object} [opts]
 * @param {number} [opts.batchSize=200] - Pages per batch (0 = disable batching)
 * @param {Function} [opts.onProgress] - Progress callback(done, total)
 * @returns {Promise<Buffer>} Masked PDF bytes
 */
async function applyMaskToPdf(srcBytes, blocks, opts = {}) {
  const batchSize = opts.batchSize || 200;
  const onProgress = opts.onProgress || null;

  const srcDoc = await PDFDocument.load(srcBytes);
  const totalPages = srcDoc.getPageCount();
  if (totalPages === 0) return Buffer.from(srcBytes);

  const page0 = srcDoc.getPage(0);
  const { width: pageW, height: pageH } = page0.getSize();
  log(`[Mask] Processing ${totalPages} page(s) @ ${pageW.toFixed(0)}x${pageH.toFixed(0)} pt, ${blocks.length} blocks`);

  // Check for mixed page sizes (mask overlay built from page 0 may misalign on other pages)
  if (totalPages > 1) {
    let hasMixedSizes = false;
    for (let i = 1; i < totalPages; i++) {
      const { width: pw, height: ph } = srcDoc.getPage(i).getSize();
      if (Math.abs(pw - pageW) > 1 || Math.abs(ph - pageH) > 1) {
        hasMixedSizes = true;
        break;
      }
    }
    if (hasMixedSizes) {
      log(`[Mask] WARNING: Document has mixed page sizes — mask overlay may be misaligned on pages with different dimensions`);
      sendToRenderer('print:progress', {
        stage: 'masking',
        message: '警告：文档包含不同尺寸的页面，遮挡位置可能在部分页面上偏移'
      });
    }
  }

  // Build overlay template once
  const overlayBytes = await buildMaskTemplate(pageW, pageH, blocks);

  // --- No batching needed ---
  if (batchSize <= 0 || totalPages <= batchSize) {
    let overlayRef;
    try {
      [overlayRef] = await srcDoc.embedPdf(await PDFDocument.load(overlayBytes), [0]);
    } catch (embedErr) {
      log(`[Mask] embedPdf overlay failed (non-batch): ${embedErr.message}`);
      return Buffer.from(await srcDoc.save());
    }
    for (let i = 0; i < totalPages; i++) {
      const p = srcDoc.getPage(i);
      const { width: pw, height: ph } = p.getSize();
      p.drawPage(overlayRef, { x: 0, y: 0, width: pw, height: ph });
    }
    if (onProgress) onProgress(totalPages, totalPages);
    return Buffer.from(await srcDoc.save());
  }

  // --- Batching mode ---
  log(`[Mask] Batching ${totalPages} pages @ ${batchSize}/batch`);
  const allIndices = Array.from({ length: totalPages }, (_, i) => i);
  const outputDoc = await PDFDocument.create();
  let processed = 0;

  for (let start = 0; start < totalPages; start += batchSize) {
    const end = Math.min(start + batchSize, totalPages);
    const count = end - start;

    // Extract batch pages into temporary document (skip problem pages)
    const batchDoc = await PDFDocument.create();
    let batchPageCount = 0;
    for (const idx of allIndices.slice(start, end)) {
      try {
        const [bp] = await batchDoc.copyPages(srcDoc, [idx]);
        batchDoc.addPage(bp);
        batchPageCount++;
      } catch (pageErr) {
        log(`[Mask] Skipping page ${idx + 1} in batch: ${pageErr.message}`);
        batchDoc.addPage();
        batchPageCount++;
      }
    }

    // Apply overlay
    let overlayRef;
    try {
      [overlayRef] = await batchDoc.embedPdf(await PDFDocument.load(overlayBytes), [0]);
    } catch (embedErr) {
      log(`[Mask] embedPdf overlay failed (batch ${start}-${end}): ${embedErr.message}`);
      processed += count;
      if (onProgress) onProgress(processed, totalPages);
      continue;
    }
    for (const p of batchDoc.getPages()) {
      const { width: pw, height: ph } = p.getSize();
      p.drawPage(overlayRef, { x: 0, y: 0, width: pw, height: ph });
    }

    // Merge batch into output
    const savedBytes = await batchDoc.save();
    const tempDoc = await PDFDocument.load(savedBytes);
    for (const ti of tempDoc.getPageIndices()) {
      try {
        const [tp] = await outputDoc.copyPages(tempDoc, [ti]);
        outputDoc.addPage(tp);
      } catch (pageErr) {
        log(`[Mask] Skipping temp page ${ti} during merge: ${pageErr.message}`);
      }
    }

    processed += count;
    if (onProgress) onProgress(processed, totalPages);
  }

  return Buffer.from(await outputDoc.save());
}

// ============================================================
// Dialog: select directory
// ============================================================
ipcMain.handle('dialog:selectDirectory', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: '选择目录',
    properties: ['openDirectory']
  });
  if (result.canceled) return null;
  return result.filePaths[0];
});

// ============================================================
// Dialog: save file
// ============================================================
ipcMain.handle('dialog:saveFile', async (_, defaultName) => {
  const result = await dialog.showSaveDialog(mainWindow, {
    title: '保存文件',
    defaultPath: defaultName || 'merged.pdf',
    filters: [{ name: 'PDF文件', extensions: ['pdf'] }]
  });
  if (result.canceled) return null;
  return result.filePath;
});

// ============================================================
// Config: default view settings (persisted to user data)
// ============================================================
const configPath = () => path.join(app.getPath('userData'), 'default-view.json');

ipcMain.handle('config:getDefaultView', async () => {
  try {
    const cp = configPath();
    if (fs.existsSync(cp)) {
      return JSON.parse(fs.readFileSync(cp, 'utf8'));
    }
    return null;
  } catch (e) {
    log(`[Config] getDefaultView error: ${e.message}`);
    return null;
  }
});

ipcMain.handle('config:setDefaultView', async (_, viewConfig) => {
  try {
    const cp = configPath();
    fs.writeFileSync(cp, JSON.stringify(viewConfig, null, 2), 'utf8');
    log(`[Config] Default view saved: ${JSON.stringify(viewConfig)}`);
    return true;
  } catch (e) {
    log(`[Config] setDefaultView error: ${e.message}`);
    return false;
  }
});

ipcMain.handle('dialog:inputDefaultView', async (_, currentValue) => {
  return { value: currentValue };
});

// ============================================================
// Preview: generate PDF bytes for preview in renderer
// Uses per-page copyPages with individual try-catch, so a single
// missing-Contents page doesn't crash the entire preview.
// ============================================================
ipcMain.handle('print:generatePreview', async (_, filePaths, options = {}) => {
  log(`[Preview] mode=${options.mode || 'invoice'}, files=${filePaths.length}, pageOrientation=${options.pageOrientation}, paperOrientation=${options.paperOrientation}`);

  if (!filePaths || filePaths.length === 0) {
    throw new Error('没有选择文件');
  }

  let pdfBytes;
  if (options.mode === 'document') {
    // Document mode: preprocess all files and merge for preview
    const needsTransform = (options.pageOrientation && options.pageOrientation !== 'auto') ||
                           (options.paperOrientation && options.paperOrientation !== 'auto');
    log(`[Preview] needsTransform=${needsTransform}`);

    if (filePaths.length === 1 && !needsTransform) {
      // Single file, no transform needed: read directly
      pdfBytes = fs.readFileSync(filePaths[0]);
      log(`[Preview] Direct read: ${pdfBytes.length} bytes`);
    } else {
      // Multiple files or transform needed: build merged preview doc
      const previewDoc = await PDFDocument.create();
      let addedPages = 0;
      for (const fp of filePaths) {
        let fileBytes;
        try {
          if (needsTransform) {
            log(`[Preview] Applying transform to: ${path.basename(fp)}`);
            fileBytes = Buffer.from(await applyPrintSettings(fp, options));
            log(`[Preview] Transform result: ${fileBytes.length} bytes`);
          } else {
            fileBytes = fs.readFileSync(fp);
          }
          const srcDoc = await PDFDocument.load(fileBytes);
          const pageIndices = srcDoc.getPageIndices();
          log(`[Preview] Source has ${pageIndices.length} pages`);
          // Copy pages one by one, skipping pages that fail (e.g. missing Contents)
          for (const idx of pageIndices) {
            try {
              const [page] = await previewDoc.copyPages(srcDoc, [idx]);
              previewDoc.addPage(page);
              addedPages++;
            } catch (pageErr) {
              log(`[Preview] Skipping page ${idx + 1} in "${path.basename(fp)}": ${pageErr.message}`);
              // Insert a blank placeholder page so page numbering stays aligned
              previewDoc.addPage();
              addedPages++;
            }
          }
        } catch (e) {
          log(`[Preview] Error processing "${path.basename(fp)}": ${e.message}`);
          // Continue with other files instead of failing completely
          continue;
        }
      }
      if (addedPages === 0) {
        throw new Error('没有可预览的页面');
      }
      pdfBytes = Buffer.from(await previewDoc.save());
      log(`[Preview] Merged PDF: ${pdfBytes.length} bytes, ${addedPages} pages`);
    }

    // Apply mask overlay if configured (on the merged preview)
    if (options.maskBlocks && options.maskBlocks.length > 0) {
      log(`[Preview] Applying mask to preview (${options.maskBlocks.length} blocks)`);
      pdfBytes = Buffer.from(await applyMaskToPdf(pdfBytes, options.maskBlocks, { batchSize: 0 }));
      log(`[Preview] After mask: ${pdfBytes.length} bytes`);
    }

    const infoDoc = await PDFDocument.load(pdfBytes);
    return {
      pdfBytes: toArrayBuffer(pdfBytes),
      totalPages: infoDoc.getPageCount()
    };
  } else {
    // Invoice mode: run imposition, return bytes
    pdfBytes = await runImposition(filePaths, options);
    // Apply mask overlay if configured
    if (options.maskBlocks && options.maskBlocks.length > 0) {
      log(`[Preview] Applying mask to invoice preview (${options.maskBlocks.length} blocks)`);
      pdfBytes = Buffer.from(await applyMaskToPdf(pdfBytes, options.maskBlocks, { batchSize: 0 }));
    }
    const doc = await PDFDocument.load(pdfBytes);
    return {
      pdfBytes: toArrayBuffer(pdfBytes),
      totalPages: doc.getPageCount()
    };
  }
});

// 禁用GPU硬件加速，避免GPU进程崩溃导致启动无响应
app.disableHardwareAcceleration();

// Handle file association — open PDF from command line or double-click
function openPendingFile() {
  if (pendingFile && mainWindow) {
    const fp = pendingFile;
    pendingFile = null;
    if (fs.existsSync(fp)) {
      mainWindow.webContents.send('open-file', fp);
    }
  }
}

// Windows: file path passed via process.argv or second-instance
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
  app.quit();
} else {
  app.on('second-instance', (_, argv) => {
    const pdfArg = argv.find(a => a.toLowerCase().endsWith('.pdf'));
    if (pdfArg && fs.existsSync(pdfArg)) {
      if (mainWindow) {
        mainWindow.focus();
        mainWindow.webContents.send('open-file', pdfArg);
      } else {
        pendingFile = pdfArg;
      }
    }
  });
}

app.whenReady().then(() => {
  // Register PDF file association if not already registered
  if (app.isPackaged) {
    app.setAsDefaultProtocolClient('pdftools');
  }

  createWindow();

  // Handle command-line PDF arguments (double-click .pdf file)
  const pdfArg = process.argv.find(a => a.toLowerCase().endsWith('.pdf'));
  if (pdfArg) {
    pendingFile = pdfArg;
  }

  openPendingFile();
});

app.on('window-all-closed', () => {
  app.quit();
});

app.on('activate', () => {
  if (!mainWindow) {
    createWindow();
    openPendingFile();
  }
});
