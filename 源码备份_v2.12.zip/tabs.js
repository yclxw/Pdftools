class TabManager {
  constructor() {
    this.tabs = [];
    this._tabMap = new Map(); // O(1) lookup by id
    this.activeTabId = null;
    this.onTabChange = null;
    this.onTabCountChange = null;

    this.tabListEl = document.getElementById('tab-list');
    this.btnNewTab = document.getElementById('btn-new-tab');
    this.contentArea = document.getElementById('content-area');
    this.welcomeScreen = document.getElementById('welcome-screen');
    this.viewerContainer = document.getElementById('viewer-container');
    this.pageControls = document.getElementById('page-controls');
    this.fileInfo = document.getElementById('file-info');

    this.btnNewTab.addEventListener('click', () => this.openPdfDialog());

    this._initContextMenu();
    this._render();
  }

  async openPdfDialog() {
    const files = await window.electronAPI.openPdfDialog();
    // Open files sequentially (not parallel) to ensure each tab gets a unique ID
    // and the PDF loading doesn't race. Concurrent Promise.all can cause:
    // 1. Duplicate tab IDs from Date.now()
    // 2. Viewer container display state conflicts
    for (const fp of files) {
      await this.openPdf(fp);
    }
  }

  async openPdf(filePath) {
    // Check if already open (linear scan acceptable here — bounded by open tabs)
    const existing = this.tabs.find(t => t.filePath === filePath);
    if (existing) {
      this.switchTab(existing.id);
      return;
    }

    try {
      const [fileInfo, fileData] = await Promise.all([
        window.electronAPI.getFileInfo(filePath),
        window.electronAPI.readFile(filePath)
      ]);

      // 验证数据有效性
      if (!fileData || fileData.byteLength === 0) {
        throw new Error('文件数据为空或读取失败');
      }
      console.log('[Tab] 文件已读取:', filePath, '大小:', fileData.byteLength, '名称:', fileInfo.name);

      const tab = {
        id: Date.now().toString(),
        filePath: filePath,
        fileName: fileInfo.name,
        fileData: fileData,
        pdfDoc: null,
        currentPage: 1,
        totalPages: 0,
        scale: 1.0,
        viewer: null
      };

      this.tabs.push(tab);
      this._tabMap.set(tab.id, tab);
      this._render();

      // Create viewer wrapper BEFORE switching tab, so switchTab can show it
      const viewerWrapper = document.createElement('div');
      viewerWrapper.className = 'viewer-wrapper';
      viewerWrapper.dataset.tabId = tab.id;
      viewerWrapper.style.display = 'none';

      const scrollContainer = document.createElement('div');
      scrollContainer.className = 'viewer-scroll';
      viewerWrapper.appendChild(scrollContainer);
      this.viewerContainer.appendChild(viewerWrapper);

      this.switchTab(tab.id);

      // Show loading indicator
      document.getElementById('status-text').innerHTML = '<span class="tab-loading-spinner"></span>正在加载: ' + tab.fileName;

      // Load PDF content
      await this._loadPdfForTab(tab);
      document.getElementById('status-text').textContent = '就绪';
    } catch (e) {
      console.error('[Tab] 打开文件失败:', filePath, e);
      this._showError('打开文件失败', e.message + '\n文件: ' + (filePath || '未知'));
    }
  }

  async _loadPdfForTab(tab) {
    try {
      // 使用统一的 CMap URL 获取函数（来自 app.js）
      const cMapUrl = (typeof window.getCMapUrl === 'function')
        ? window.getCMapUrl()
        : (window.location.href.replace(/\/src\/index\.html.*$/, '') + '/node_modules/pdfjs-dist/cmaps/');

      console.log('[Tab] 加载 PDF, CMap URL:', cMapUrl);

      const pdfDoc = await pdfjsLib.getDocument({
        data: tab.fileData.slice(0),
        cMapUrl: cMapUrl,
        cMapPacked: true
      }).promise;

      tab.pdfDoc = pdfDoc;
      tab.totalPages = pdfDoc.numPages;
      console.log('[Tab] PDF 加载成功:', tab.fileName, '页数:', tab.totalPages);

      // Log font/text info for diagnostics (deferred)
      if (window.requestIdleCallback) {
        window.requestIdleCallback(() => this._logFontInfo(tab));
      } else {
        setTimeout(() => this._logFontInfo(tab), 100);
      }

      // Use the existing viewerWrapper/scrollContainer created in openPdf()
      const viewerWrapper = this.viewerContainer.querySelector(`[data-tab-id="${tab.id}"]`);
      if (!viewerWrapper) {
        // Fallback: should not happen if openPdf created it
        const vw = document.createElement('div');
        vw.className = 'viewer-wrapper';
        vw.dataset.tabId = tab.id;
        vw.style.display = 'none';
        const sc = document.createElement('div');
        sc.className = 'viewer-scroll';
        vw.appendChild(sc);
        this.viewerContainer.appendChild(vw);
        tab.viewer = new PdfViewer(sc, tab, () => this._updateUI());
      } else {
        const scrollContainer = viewerWrapper.querySelector('.viewer-scroll');
        if (!scrollContainer) return;
        tab.viewer = new PdfViewer(scrollContainer, tab, () => this._updateUI());
      }

      if (tab.id === this.activeTabId) {
        viewerWrapper.style.display = 'flex';
        this._updateUI();
      }
      // Apply default view config on first load for EVERY tab (not just active tab).
      // The viewConfig is cached so we read it once and apply to all tabs.
      this._applyDefaultView(tab);
    } catch (e) {
      console.error('[Tab] PDF 解析失败:', tab.fileName, e);
      this._showError('加载PDF失败',
        e.message + '\n文件: ' + tab.fileName +
        '\n可能原因：PDF文件损坏、PDF.js Worker 加载失败、或文件格式不正确。' +
        '\n请尝试用其他软件打开该文件验证是否正常。');
      // Remove failed tab so it doesn't stay in the list
      this.closeTab(tab.id);
    }
  }

  switchTab(id) {
    const tab = this._tabMap.get(id);
    if (!tab) return;

    // Hide all viewers
    this.viewerContainer.querySelectorAll('.viewer-wrapper').forEach(w => {
      w.style.display = 'none';
    });

    // Show active viewer
    const wrapper = this.viewerContainer.querySelector(`[data-tab-id="${id}"]`);
    if (wrapper) {
      wrapper.style.display = 'flex';
    }

    this.activeTabId = id;
    this.welcomeScreen.style.display = 'none';
    this.viewerContainer.style.display = 'block';

    if (tab.viewer) {
      // Render the current page whenever switching to this tab.
      if (!tab._hasAutoFitted && tab.pdfDoc) {
        // First time viewing this tab — apply saved default view config
        this._applyDefaultView(tab);
      } else if (tab.pdfDoc) {
        tab.viewer.renderCurrentPage();
      }
    }

    this._updateUI();
    this._render();

    if (this.onTabChange) this.onTabChange(tab);
  }

  closeTab(id) {
    const tab = this._tabMap.get(id);
    if (!tab) return;
    const idx = this.tabs.indexOf(tab);

    // Remove viewer DOM
    const wrapper = this.viewerContainer.querySelector(`[data-tab-id="${id}"]`);
    if (wrapper) wrapper.remove();

    // Destroy viewer
    if (tab.viewer) {
      tab.viewer.destroy();
    }

    // Clean up pdfDoc
    if (tab.pdfDoc) {
      tab.pdfDoc.destroy();
      tab.pdfDoc = null;
    }

    this.tabs.splice(idx, 1);
    this._tabMap.delete(id);

    if (this.tabs.length === 0) {
      this.activeTabId = null;
      this.welcomeScreen.style.display = 'flex';
      this.viewerContainer.style.display = 'none';
      this.pageControls.style.display = 'none';
      this.fileInfo.textContent = '';
    } else if (this.activeTabId === id) {
      // Switch to adjacent tab
      const newIdx = Math.min(idx, this.tabs.length - 1);
      this.switchTab(this.tabs[newIdx].id);
    }

    this._render();
    if (this.onTabCountChange) this.onTabCountChange(this.tabs.length);
  }

  getActiveTab() {
    return this._tabMap.get(this.activeTabId) || null;
  }

  closeAllTabs() {
    const ids = this.tabs.map(t => t.id);
    for (const id of ids) {
      this.closeTab(id);
    }
  }

  closeOtherTabs(id) {
    const otherIds = this.tabs.filter(t => t.id !== id).map(t => t.id);
    for (const oid of otherIds) {
      this.closeTab(oid);
    }
  }

  _updateUI() {
    const tab = this.getActiveTab();
    if (!tab) return;

    this.pageControls.style.display = 'flex';

    if (tab.viewer) {
      document.getElementById('zoom-level').textContent = Math.round(tab.scale * 100) + '%';
      document.getElementById('zoom-percent').textContent = Math.round(tab.scale * 100) + '%';
      document.getElementById('page-input').value = tab.currentPage;
      document.getElementById('total-pages').textContent = '/ ' + tab.totalPages;
      // Update zoom select dropdown to match actual scale
      const select = document.getElementById('zoom-select');
      const pct = Math.round(tab.scale * 100);
      const predefined = [50, 75, 100, 125, 150, 200];
      if (predefined.includes(pct)) {
        select.value = String(pct / 100);
      } else {
        select.value = '';
      }
    }

    this.fileInfo.textContent = tab.fileName;
  }

  _render() {
    this.tabListEl.innerHTML = '';

    for (const tab of this.tabs) {
      const tabEl = document.createElement('div');
      tabEl.className = 'tab-item' + (tab.id === this.activeTabId ? ' active' : '');
      tabEl.dataset.tabId = tab.id;
      tabEl.draggable = true;

      const title = document.createElement('span');
      title.className = 'tab-title';
      title.textContent = tab.fileName;
      title.title = tab.filePath;

      const closeBtn = document.createElement('button');
      closeBtn.className = 'tab-close';
      closeBtn.textContent = '×';
      closeBtn.onclick = (e) => {
        e.stopPropagation();
        this.closeTab(tab.id);
      };

      tabEl.appendChild(title);
      tabEl.appendChild(closeBtn);

      tabEl.onclick = () => this.switchTab(tab.id);
      tabEl.oncontextmenu = (e) => {
        e.preventDefault();
        this._showContextMenu(e.clientX, e.clientY, tab.id);
      };

      // Drag and drop for tab reordering
      tabEl.ondragstart = (e) => {
        e.dataTransfer.setData('text/plain', tab.id);
        e.dataTransfer.effectAllowed = 'move';
      };
      tabEl.ondragover = (e) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
      };
      tabEl.ondrop = (e) => {
        e.preventDefault();
        const fromId = e.dataTransfer.getData('text/plain');
        const toId = tab.id;
        if (fromId !== toId) {
          this._reorderTabs(fromId, toId);
        }
      };

      this.tabListEl.appendChild(tabEl);
    }
  }

  _reorderTabs(fromId, toId) {
    const fromTab = this._tabMap.get(fromId);
    const toTab = this._tabMap.get(toId);
    if (!fromTab || !toTab) return;
    const fromIdx = this.tabs.indexOf(fromTab);
    const toIdx = this.tabs.indexOf(toTab);
    if (fromIdx === -1 || toIdx === -1) return;

    const [tab] = this.tabs.splice(fromIdx, 1);
    this.tabs.splice(toIdx, 0, tab);
    this._render();
  }

  _initContextMenu() {
    this.contextMenu = document.createElement('div');
    this.contextMenu.className = 'context-menu';
    this.contextMenu.style.display = 'none';
    document.body.appendChild(this.contextMenu);

    document.addEventListener('click', () => {
      this.contextMenu.style.display = 'none';
    });
  }

  _showContextMenu(x, y, tabId) {
    this.contextMenu.innerHTML = '';

    const items = [
      { label: '关闭标签', action: () => this.closeTab(tabId), cls: '' },
      { label: '关闭其他标签', action: () => this.closeOtherTabs(tabId), cls: '' },
      { label: '关闭所有标签', action: () => this.closeAllTabs(), cls: '' },
    ];

    for (const item of items) {
      const el = document.createElement('div');
      el.className = 'context-menu-item' + (item.cls ? ' ' + item.cls : '');
      el.textContent = item.label;
      el.onclick = () => {
        item.action();
        this.contextMenu.style.display = 'none';
      };
      this.contextMenu.appendChild(el);
    }

    this.contextMenu.style.display = 'block';
    this.contextMenu.style.left = x + 'px';
    this.contextMenu.style.top = y + 'px';

    // Keep menu within viewport
    const rect = this.contextMenu.getBoundingClientRect();
    if (rect.right > window.innerWidth) {
      this.contextMenu.style.left = (x - rect.width) + 'px';
    }
    if (rect.bottom > window.innerHeight) {
      this.contextMenu.style.top = (y - rect.height) + 'px';
    }
  }

  _showError(title, message) {
    document.getElementById('status-text').textContent = `错误: ${message}`;
    console.error(title, message);
  }

  // Apply saved default view config to a tab.
  // viewConfig is cached so it's read once from the main process.
  async _applyDefaultView(tab, viewConfig) {
    if (!tab || !tab.viewer) return;
    try {
      const config = viewConfig || await window.electronAPI.getDefaultView();
      if (!config) {
        // No config saved — fitPage as default behavior
        if (!tab._hasAutoFitted) {
          tab._hasAutoFitted = true;
          if (tab.id === this.activeTabId) {
            tab.viewer.fitPage();
          }
        }
        return;
      }
      tab._hasAutoFitted = true;
      if (tab.id !== this.activeTabId) return; // Only render visible tab
      switch (config.type) {
        case 'fit-width':
          tab.viewer.fitWidth();
          break;
        case 'fit-page':
          tab.viewer.fitPage();
          break;
        case 'actual-size':
          tab.viewer.actualSize();
          break;
        case 'custom':
          if (config.scale) {
            tab.viewer.setScale(config.scale);
          }
          break;
        default:
          tab.viewer.fitPage();
      }
    } catch (e) {
      console.warn('Failed to apply default view to', tab.fileName, e);
      if (!tab._hasAutoFitted) {
        tab._hasAutoFitted = true;
        if (tab.id === this.activeTabId) tab.viewer.fitPage();
      }
    }
  }

  async _logFontInfo(tab) {
    try {
      const page = await tab.pdfDoc.getPage(1);
      const text = await page.getTextContent();
      // Log styles and used font names to console for debugging
      console.group(`PDF 字体诊断: ${tab.fileName}`);
      console.log('styles:', text.styles);
      const fonts = new Set();
      if (text.items && text.items.length) {
        for (const item of text.items) {
          if (item.fontName) fonts.add(item.fontName);
        }
      }
      console.log('fonts used on page 1:', Array.from(fonts));
      console.log('text sample items:', text.items && text.items.slice(0, 20));
      console.groupEnd();
    } catch (e) {
      console.warn('获取 PDF 字体/文本信息失败:', e);
    }
  }
}
