class PrintPanel {
  constructor() {
    this.files = [];
    this.mode = 'invoice';
    this.batchResults = null;
    this.previewCache = null;
    this._previewPage = 0;
    this._previewTotalPages = 0;
    this.onClose = null;  // callback when workspace is closed
    this._previewDebounceTimer = null;  // debounce timer for auto preview

    // Mask state
    this.maskEnabled = false;
    this.maskBlocks = [];  // { x, y, width, height, text, fontSize }

    this.workspace = document.getElementById('print-workspace');
    this.dropZone = null; // removed
    this.fileList = document.getElementById('print-file-list');
    this.fileCount = document.getElementById('print-file-count');
    this.printerSelect = document.getElementById('printer-select');
    this.btnPrintProps = null; // removed
    this.btnPrint = document.getElementById('btn-print-start');
    this.btnPreview = null; // removed
    this.statusText = document.getElementById('print-status-text');
    this.progressBar = document.getElementById('print-progress-bar');
    this.progressFill = document.getElementById('print-progress-fill');
    this.queueSection = document.getElementById('print-queue-section');

    // Preview area
    this.previewArea = document.getElementById('print-preview-area');
    this.previewPlaceholder = document.querySelector('.preview-placeholder');
    this.previewCanvas = document.getElementById('print-preview-canvas');
    this.previewPrevBtn = document.getElementById('preview-page-prev');
    this.previewNextBtn = document.getElementById('preview-page-next');
    this.previewPageNum = document.getElementById('preview-page-num');
    this.previewTotal = document.getElementById('preview-total-pages');

    // Mode switch
    this.modeInvoiceBtn = document.getElementById('print-mode-invoice');
    this.modeDocumentBtn = document.getElementById('print-mode-document');

    // Invoice settings
    this.settingsInvoice = document.getElementById('print-settings-invoice');
    this.marginSlider = document.getElementById('print-margin-slider');
    this.marginValue = document.getElementById('print-margin-value');
    this.copiesInvoice = document.getElementById('print-copies-invoice');

    // Document settings
    this.settingsDocument = document.getElementById('print-settings-document');
    this.copiesDocument = document.getElementById('print-copies-document');
    this.continueCheck = document.getElementById('print-continue-check');
    
    // Page range settings
    this.pageRangeRadios = document.querySelectorAll('input[name="pageRange"]');
    this.pageRangeInput = document.getElementById('print-page-range-input');
    this._pageRangeMode = 'all'; // 'all' or 'custom'
    this._pageRangeValue = '';

    // Batch result
    this.batchResult = document.getElementById('print-batch-result');

    // Mask elements
    this.maskEnableCheck = document.getElementById('print-mask-enable');
    this.maskBlocksContainer = document.getElementById('print-mask-blocks');
    this.maskBlockList = document.getElementById('print-mask-block-list');
    this.btnMaskAddBlock = document.getElementById('btn-mask-add-block');

    this._bindEvents();
  }

  _bindEvents() {
    document.getElementById('print-workspace-close').addEventListener('click', () => this.hide());
    document.getElementById('btn-select-files').addEventListener('click', () => this._selectFiles());
    document.getElementById('btn-refresh-printers').addEventListener('click', () => this._refreshPrinters());
    this.printerSelect.addEventListener('change', () => this._updateButtons());

    this.btnPrint.addEventListener('click', () => this._startPrint());

    this.modeInvoiceBtn.addEventListener('click', () => this._setMode('invoice'));
    this.modeDocumentBtn.addEventListener('click', () => this._setMode('document'));

    this.marginSlider.addEventListener('input', () => {
      this.marginValue.textContent = parseFloat(this.marginSlider.value).toFixed(1) + ' cm';
      this.previewCache = null;
      // Auto preview when margin changes
      this._triggerAutoPreview();
    });
    
    // Orientation buttons - Page orientation
    this.pageOrientationButtons = document.querySelectorAll('.orientation-btn[data-type="page"]');
    this._pageOrientation = 'auto';
    this.pageOrientationButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        this.pageOrientationButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this._pageOrientation = btn.dataset.value;
        this.previewCache = null;
        // Auto preview when page orientation changes
        this._triggerAutoPreview();
      });
    });

    // Orientation buttons - Paper orientation
    this.paperOrientationButtons = document.querySelectorAll('.orientation-btn[data-type="paper"]');
    this._paperOrientation = 'auto';
    this.paperOrientationButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        this.paperOrientationButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this._paperOrientation = btn.dataset.value;
        this.previewCache = null;
        // Auto preview when paper orientation changes
        this._triggerAutoPreview();
      });
    });

    // Page range radio buttons
    this.pageRangeRadios.forEach(radio => {
      radio.addEventListener('change', () => {
        this._pageRangeMode = radio.value;
        if (radio.value === 'custom') {
          this.pageRangeInput.disabled = false;
          this.pageRangeInput.focus();
        } else {
          this.pageRangeInput.disabled = true;
          this._pageRangeValue = '';
        }
        this.previewCache = null;
        // Auto preview when page range mode changes
        this._triggerAutoPreview();
      });
    });
    
    // Page range input
    this.pageRangeInput.addEventListener('input', () => {
      this._pageRangeValue = this.pageRangeInput.value.trim();
      this.previewCache = null;
      // Auto preview when page range value changes (with debounce)
      this._triggerAutoPreview();
    });

    // Copies validation: clamp to 1-99 range on blur
    const validateCopies = (input) => {
      let val = parseInt(input.value);
      if (isNaN(val) || val < 1) val = 1;
      if (val > 99) val = 99;
      input.value = val;
    };
    this.copiesInvoice.addEventListener('blur', () => validateCopies(this.copiesInvoice));
    this.copiesDocument.addEventListener('blur', () => validateCopies(this.copiesDocument));

    this.previewPrevBtn.addEventListener('click', () => this._previewGoTo(this._previewPage - 1));
    this.previewNextBtn.addEventListener('click', () => this._previewGoTo(this._previewPage + 1));

    // Ctrl+MouseWheel zoom for print preview
    const previewWrap = document.getElementById('preview-canvas-wrap');
    let previewWheelAccum = 0;
    let previewWheelTimeout = null;
    previewWrap.addEventListener('wheel', (e) => {
      if (e.ctrlKey) {
        e.preventDefault();
        previewWheelAccum += e.deltaY > 0 ? -0.1 : 0.1;
        if (previewWheelTimeout) return;
        previewWheelTimeout = setTimeout(() => {
          previewWheelTimeout = null;
          const delta = previewWheelAccum;
          previewWheelAccum = 0;
          if (this.previewCache) {
            const zoomInfo = document.getElementById('preview-zoom-info');
            // Re-render with adjusted scale — store current scale
            if (!this._previewScale) this._previewScale = 1;
            this._previewScale = Math.max(0.25, Math.min(5, this._previewScale + delta));
            if (zoomInfo) zoomInfo.textContent = Math.round(this._previewScale * 100) + '%';
            // Re-render current page with new scale
            this._renderPreviewPage(this._previewPage);
          }
        }, 150);
      }
    }, { passive: false });

    this._cleanupProgress = window.electronAPI.onPrintProgress((data) => this._onProgress(data));

    // Mask events
    this.maskEnableCheck.addEventListener('change', () => {
      this.maskEnabled = this.maskEnableCheck.checked;
      this.maskBlocksContainer.style.display = this.maskEnabled ? 'block' : 'none';
      this.previewCache = null;
      this._triggerAutoPreview();
    });
    this.btnMaskAddBlock.addEventListener('click', () => this._addMaskBlock());
  }

  _setMode(mode) {
    this.mode = mode;
    this.previewCache = null;
    this.modeInvoiceBtn.classList.toggle('active', mode === 'invoice');
    this.modeDocumentBtn.classList.toggle('active', mode === 'document');
    this.settingsInvoice.style.display = mode === 'invoice' ? 'block' : 'none';
    this.settingsDocument.style.display = mode === 'document' ? 'block' : 'none';
    // Mask section only available in document mode
    const maskSection = document.getElementById('print-mask-settings');
    if (maskSection) {
      maskSection.style.display = mode === 'document' ? 'block' : 'none';
      // Reset mask state when switching to invoice mode
      if (mode === 'invoice') {
        this.maskEnabled = false;
        if (this.maskEnableCheck) this.maskEnableCheck.checked = false;
        if (this.maskBlocksContainer) this.maskBlocksContainer.style.display = 'none';
      }
    }
    this._hidePreview();
    this._renderFileList();
    // Auto preview when mode changes
    this._triggerAutoPreview();
  }

  _getOptions() {
    const opts = { mode: this.mode, continueOnError: this.continueCheck.checked };
    if (this.mode === 'invoice') {
      opts.marginCm = parseFloat(this.marginSlider.value) || 1.0;
      opts.copies = Math.max(1, Math.min(99, parseInt(this.copiesInvoice.value) || 1));
    } else {
      opts.copies = Math.max(1, Math.min(99, parseInt(this.copiesDocument.value) || 1));
      opts.pageOrientation = this._pageOrientation;
      opts.paperOrientation = this._paperOrientation;
      opts.pageRangeMode = this._pageRangeMode;
      opts.pageRangeValue = this._pageRangeValue;
    }
    // Mask blocks
    if (this.maskEnabled && this.maskBlocks.length > 0) {
      opts.maskBlocks = this.maskBlocks.map(b => ({
        x: parseFloat(b.x) || 0,
        y: parseFloat(b.y) || 0,
        width: parseFloat(b.width) || 30,
        height: parseFloat(b.height) || 10,
        text: b.text || '',
        fontSize: parseInt(b.fontSize) || 9,
        textColor: b.textColor || '#000000',
        bgColor: b.bgColor || '#c6efce',
      }));
    }
    return opts;
  }

  // ===== Open / Close =====
  async open(files, mode) {
    const initMode = mode || 'invoice';
    this.files = [];
    this._pathSet = new Set();
    this.batchResults = null;
    this.batchResult.style.display = 'none';
    this._hidePreview();
    this._renderFileList();

    // Set initial mode before adding files (affects mask visibility)
    this._setMode(initMode);

    // Reset mask state
    this.maskEnabled = false;
    this.maskBlocks = [];
    if (this.maskEnableCheck) this.maskEnableCheck.checked = false;
    if (this.maskBlocksContainer) this.maskBlocksContainer.style.display = 'none';
    if (this.maskBlockList) this.maskBlockList.innerHTML = '';
    if (files && files.length > 0) { await this._addFiles(files); }

    // Show workspace, hide welcome + viewer
    document.getElementById('welcome-screen').style.display = 'none';
    document.getElementById('viewer-container').style.display = 'none';
    this.workspace.style.display = 'flex';

    await this._refreshPrinters();
    this._resetUI();
  }

  hide() {
    this.workspace.style.display = 'none';
    this._resetUI();
    this._hidePreview();
    // Notify app to restore previous view
    if (this.onClose) this.onClose();
  }

  // ===== Preview =====
  /**
   * Auto preview with debounce - triggers preview generation after changes
   * Waits 500ms after last change to avoid excessive API calls
   */
  _triggerAutoPreview() {
    // Clear existing timer
    if (this._previewDebounceTimer) {
      clearTimeout(this._previewDebounceTimer);
    }
    
    // Only auto-preview if there are files
    if (this.files.length === 0) {
      this._hidePreview();
      return;
    }
    
    // Set new timer
    this._previewDebounceTimer = setTimeout(() => {
      this._showPreview();
    }, 500);
  }

  async _showPreview() {
    if (this.files.length === 0) return;
    const options = this._getOptions();
    const filePaths = this.files.map(f => f.path);

    this.statusText.textContent = '正在生成预览...';
    this.previewPlaceholder.style.display = 'none';
    this.previewArea.style.display = 'flex';
    this._previewScale = 1; // Reset zoom when new preview is generated

    try {
      const result = await window.electronAPI.generatePreview(filePaths, options);
      this.previewCache = { pdfBytes: result.pdfBytes, totalPages: result.totalPages };
      this._previewTotalPages = result.totalPages;
      this._previewPage = 1;
      this.previewTotal.textContent = '/' + result.totalPages;
      await this._renderPreviewPage(1);
      this.statusText.textContent = result.totalPages > 1
        ? `预览就绪（共 ${result.totalPages} 页）` : '预览就绪';
    } catch (e) {
      this.statusText.textContent = '预览失败: ' + e.message;
      this.previewCache = null;
      this.previewArea.style.display = 'none';
      this.previewPlaceholder.style.display = 'flex';
    }
  }

  async _renderPreviewPage(pageNum) {
    if (!this.previewCache) return;
    // Render-ID guard: prevent stale async renders from overwriting newer navigation
    const renderId = Date.now();
    this._previewRenderId = renderId;
    let pdfDoc = null;
    try {
      pdfDoc = await pdfjsLib.getDocument({
        data: this.previewCache.pdfBytes.slice(0),
        cMapUrl: this._getCmapUrl(),
        cMapPacked: true
      }).promise;
      if (this._previewRenderId !== renderId) return; // Superseded

      const page = await pdfDoc.getPage(pageNum);
      if (this._previewRenderId !== renderId) return; // Superseded

      const wrap = document.getElementById('preview-canvas-wrap');
      const maxW = wrap.clientWidth - 32;
      const vp1 = page.getViewport({ scale: 1 });
      const baseScale = Math.min(1, maxW / vp1.width);
      // Use stored preview zoom scale if available
      const effectiveScale = this._previewScale ? baseScale * this._previewScale : baseScale;
      const viewport = page.getViewport({ scale: effectiveScale });

      const canvas = this.previewCanvas;
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      canvas.style.width = viewport.width + 'px';
      canvas.style.height = viewport.height + 'px';

      const ctx = canvas.getContext('2d');
      await page.render({ canvasContext: ctx, viewport: viewport }).promise;
      if (this._previewRenderId !== renderId) return; // Superseded before DOM update

      this._previewPage = pageNum;
      this.previewPageNum.textContent = pageNum;
      this.previewPrevBtn.disabled = pageNum <= 1;
      this.previewNextBtn.disabled = pageNum >= this._previewTotalPages;

      const zoomInfo = document.getElementById('preview-zoom-info');
      if (zoomInfo) { zoomInfo.textContent = Math.round(effectiveScale * 100) + '%'; }
    } catch (e) {
      if (this._previewRenderId !== renderId) return; // Superseded, ignore error
      console.error('Preview render error:', e);
      // Clear canvas on error to avoid showing stale content
      const canvas = this.previewCanvas;
      const ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      canvas.width = 0;
      canvas.height = 0;
      canvas.style.width = '0px';
      canvas.style.height = '0px';
      this.statusText.textContent = '预览渲染失败: ' + (e.message || '未知错误');
    } finally {
      if (pdfDoc) {
        try { pdfDoc.destroy(); } catch (_) {}
      }
    }
  }

  _previewGoTo(pageNum) {
    if (pageNum < 1 || pageNum > this._previewTotalPages) return;
    this._renderPreviewPage(pageNum);
  }

  _hidePreview() {
    if (this.previewPlaceholder) this.previewPlaceholder.style.display = 'flex';
    if (this.previewArea) this.previewArea.style.display = 'none';
    this.previewCache = null;
    this._previewPage = 0;
    this._previewTotalPages = 0;
  }

  _getCmapUrl() {
    // 优先使用 app.js 中定义的统一 CMap URL 获取函数
    if (typeof window.getCMapUrl === 'function') {
      return window.getCMapUrl();
    }
    // Fallback: 本地实现（与 app.js 逻辑保持一致）
    if (PrintPanel._cmapUrlCache !== undefined) return PrintPanel._cmapUrlCache;
    let url = '';
    try {
      const rp = window.electronAPI && window.electronAPI.getResourcesPath
        ? window.electronAPI.getResourcesPath() : '';
      if (rp) {
        const cmapDir = rp.replace(/\\/g, '/') + '/app.asar.unpacked/node_modules/pdfjs-dist/cmaps/';
        url = 'file:///' + cmapDir.replace(/^\/+/, '');
      }
    } catch (e) { /* fall through */ }
    if (!url) {
      url = window.location.href.replace(/\/src\/index\.html.*$/, '') + '/node_modules/pdfjs-dist/cmaps/';
    }
    PrintPanel._cmapUrlCache = url;
    return url;
  }

  // ===== File management =====
  async _selectFiles() {
    const filePaths = await window.electronAPI.selectInvoicesDialog();
    if (filePaths && filePaths.length > 0) {
      this.files = [];
      this._pathSet = new Set();
      await this._addFiles(filePaths);
    }
  }

  async _addFiles(filePaths) {
    const newPaths = [];
    for (const fp of filePaths) {
      if (!this._pathSet.has(fp)) {
        newPaths.push(fp);
        this._pathSet.add(fp);
      }
    }
    if (newPaths.length === 0) return;
    const results = await Promise.allSettled(
      newPaths.map(fp => window.electronAPI.getPDFInfo(fp))
    );
    for (let j = 0; j < results.length; j++) {
      const res = results[j];
      if (res.status === 'fulfilled') {
        this.files.push(res.value);
      } else {
        console.warn(`获取文件信息失败，已跳过: ${newPaths[j]}`, res.reason);
      }
    }
    this.previewCache = null;
    this._hidePreview();
    this._renderFileList();
    this._updateButtons();
    // Auto preview after files are added
    this._triggerAutoPreview();
  }

  _removeFile(index) {
    const removed = this.files[index];
    this.files.splice(index, 1);
    if (this._pathSet && removed) this._pathSet.delete(removed.path);
    this.previewCache = null;
    this._hidePreview();
    this._renderFileList();
    this._updateButtons();
    // Auto preview after file is removed
    this._triggerAutoPreview();
  }

  _renderFileList() {
    if (this.mode === 'invoice') {
      const tp = Math.ceil(this.files.length / 2);
      this.fileCount.textContent = `${this.files.length} 个文件 -> ${tp} 页 A4`;
    } else {
      this.fileCount.textContent = `${this.files.length} 个文件 (逐个打印)`;
    }

    if (this.files.length === 0) {
      this.fileList.innerHTML = '<div class="print-file-empty">暂无文件</div>';
    } else {
      this.fileList.innerHTML = this.files.map((f, i) => `
        <div class="print-file-item">
          <span class="print-file-icon">&#9679;</span>
          <span class="print-file-name" title="${f.path}">${f.name}</span>
          <span class="print-file-size">${this._formatSize(f.size)}</span>
          <button class="print-file-remove" data-index="${i}" title="移除"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg></button>
        </div>
      `).join('');
      this.fileList.querySelectorAll('.print-file-remove').forEach(btn => {
        btn.addEventListener('click', (e) => { e.stopPropagation(); this._removeFile(parseInt(btn.dataset.index)); });
      });
    }
  }

  async _refreshPrinters() {
    this.printerSelect.innerHTML = '<option value="">正在获取打印机列表...</option>';
    this.printerSelect.disabled = true;
    this.btnPrint.disabled = true;
    try {
      const printers = await window.electronAPI.getPrinters();
      this.printerSelect.innerHTML = printers.map(p => `<option value="${p}">${p}</option>`).join('');
      if (printers.length === 0) { this.printerSelect.innerHTML = '<option value="">未找到打印机</option>'; }
    } catch (_) {
      this.printerSelect.innerHTML = '<option value="">获取打印机列表失败</option>';
    }
    this.printerSelect.disabled = false;
    this._updateButtons();
  }

  _updateButtons() {
    const hasFiles = this.files.length > 0;
    const hasPrinter = this.printerSelect.value && this.printerSelect.value !== '';
    this.btnPrint.disabled = !hasFiles || !hasPrinter;
  }

  async _openPrinterProperties() {
    const printer = this.printerSelect.value;
    if (!printer) return;
    try { await window.electronAPI.openPrinterProperties(printer); } catch (e) {
      document.getElementById('status-text').textContent = e.message;
    }
  }

  // ===== Print =====
  async _startPrint() {
    const printer = this.printerSelect.value;
    if (this.files.length === 0 || !printer) return;

    this._setUIActive(true);
    this._setProgress(0, '正在启动打印...');
    this.batchResult.style.display = 'none';
    this.batchResults = null;

    try {
      const filePaths = this.files.map(f => f.path);
      const options = this._getOptions();
      if (this.previewCache && this.mode === 'invoice') {
        options._cachedPdfBytes = this.previewCache.pdfBytes;
      }
      const result = await window.electronAPI.executePrint(filePaths, printer, options);
      if (result && result.totalFiles !== undefined) {
        this.batchResults = result;
        this._showBatchResult();
      } else {
        this.statusText.textContent = '打印完成';
        document.getElementById('status-text').textContent = '打印完成';
      }
    } catch (e) {
      this.statusText.textContent = `打印失败: ${e.message}`;
      document.getElementById('status-text').textContent = `打印失败: ${e.message}`;
    } finally {
      this._setUIActive(false);
    }
  }

  _showBatchResult() {
    const r = this.batchResults;
    if (!r) return;
    let html = '';
    if (r.failed && r.failed.length > 0) {
      html += `<div class="batch-result-header">成功 ${r.success.length}，失败 ${r.failed.length}</div>`;
      html += '<div class="batch-failed-title">失败文件：</div>';
      for (const f of r.failed) {
        html += `<div class="batch-failed-item">${f.name} — ${f.error}</div>`;
      }
      html += '<button id="btn-retry-failed" class="btn-secondary">重试失败项</button>';
    } else {
      html = `<div class="batch-result-header">全部完成（${r.success.length} 个文件）</div>`;
    }
    this.batchResult.innerHTML = html;
    this.batchResult.style.display = 'block';
    const retryBtn = document.getElementById('btn-retry-failed');
    if (retryBtn) {
      retryBtn.addEventListener('click', () => {
        if (r.failed && r.failed.length > 0) {
          this.files = r.failed.map(f => ({ name: f.name, path: f.path, size: 0 }));
          this.previewCache = null;
          this._renderFileList();
          this.batchResult.style.display = 'none';
          this._updateButtons();
        }
      });
    }
  }

  // ===== Progress =====
  _onProgress(data) {
    if (data.stage === 'done') { this._setProgress(100, data.message); this._setUIActive(false); }
    else if (data.stage === 'error') { this._setProgress(0, `错误: ${data.message}`); this._setUIActive(false); }
    else { const pct = data.total > 0 ? Math.round((data.current / data.total) * 100) : 0; this._setProgress(pct, data.message); }
  }

  _setProgress(pct, message) {
    this.progressFill.style.width = pct + '%';
    this.progressBar.style.display = pct > 0 && pct < 100 ? 'block' : 'none';
    this.statusText.textContent = message;
  }

  _setUIActive(active) {
    const cls = 'ui-busy';
    const toggle = (el) => { if (el) el.classList.toggle(cls, active); };
    toggle(this.btnPrint);
    toggle(document.getElementById('btn-select-files'));
    toggle(this.printerSelect);
    toggle(document.getElementById('btn-refresh-printers'));
    this.fileList.querySelectorAll('.print-file-remove').forEach(b => {
      toggle(b);
      b.style.opacity = active ? '0.4' : '1';
    });
  }

  _resetUI() { this._setProgress(0, '就绪'); this._setUIActive(false); }

  _formatSize(bytes) {
    if (bytes == null) return '';
    if (bytes === 0) return '0 B';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }

  // ===== Mask block management =====

  /** Add a new empty mask block (with sensible defaults) */
  _addMaskBlock() {
    this.maskBlocks.push({ x: 0, y: 0, width: 30, height: 10, text: '', fontSize: 9, textColor: '#000000', bgColor: '#c6efce' });
    this._renderMaskBlocks();
    this.previewCache = null;
    this._triggerAutoPreview();
  }

  /** Remove mask block at index */
  _removeMaskBlock(index) {
    this.maskBlocks.splice(index, 1);
    this._renderMaskBlocks();
    this.previewCache = null;
    this._triggerAutoPreview();
  }

  /** Render all mask block entries into the DOM */
  _renderMaskBlocks() {
    if (!this.maskBlockList) return;

    if (this.maskBlocks.length === 0) {
      this.maskBlockList.innerHTML = '<div style="padding:6px;text-align:center;color:#999;font-size:11px;">暂无遮挡块，点击上方"+"添加</div>';
      return;
    }

    this.maskBlockList.innerHTML = this.maskBlocks.map((block, i) => `
      <div class="mask-block-item" data-index="${i}">
        <button class="mask-block-del" data-index="${i}" title="删除此遮挡块">✕</button>
        <div class="mask-block-row">
          <span class="mask-block-label">X</span>
          <input type="number" class="mask-block-input" data-idx="${i}" data-field="x" value="${block.x}" step="1" min="0">
          <span class="mask-block-label">Y</span>
          <input type="number" class="mask-block-input" data-idx="${i}" data-field="y" value="${block.y}" step="1" min="0">
          <span class="mask-block-label">W</span>
          <input type="number" class="mask-block-input" data-idx="${i}" data-field="width" value="${block.width}" step="1" min="1">
          <span class="mask-block-label">H</span>
          <input type="number" class="mask-block-input" data-idx="${i}" data-field="height" value="${block.height}" step="1" min="1">
        </div>
        <div class="mask-block-row">
          <span class="mask-block-label">文</span>
          <input type="text" class="mask-block-input text" data-idx="${i}" data-field="text" value="${this._escapeHtml(block.text)}" placeholder="遮挡上显示的文字（留空只盖不写）">
          <span class="mask-block-label" style="min-width:14px;">号</span>
          <input type="number" class="mask-block-input" style="width:40px;" data-idx="${i}" data-field="fontSize" value="${block.fontSize}" min="6" max="72">
          <span class="mask-block-label">字</span>
          <input type="color" class="mask-block-color" data-idx="${i}" data-field="textColor" value="${block.textColor || '#000000'}">
          <span class="mask-block-label">背</span>
          <input type="color" class="mask-block-color" data-idx="${i}" data-field="bgColor" value="${block.bgColor || '#c6efce'}">
        </div>
      </div>
    `).join('');

    // Bind events for all inputs in mask blocks
    this.maskBlockList.querySelectorAll('.mask-block-input').forEach(input => {
      input.addEventListener('input', (e) => {
        const idx = parseInt(e.target.dataset.idx);
        const field = e.target.dataset.field;
        const val = e.target.type === 'number' ? parseFloat(e.target.value) : e.target.value;
        if (idx >= 0 && idx < this.maskBlocks.length) {
          if (field === 'text') {
            this.maskBlocks[idx][field] = val || '';
          } else {
            this.maskBlocks[idx][field] = isNaN(val) ? 0 : val;
          }
          this.previewCache = null;
          this._triggerAutoPreview();
        }
      });
    });

    // Bind events for color inputs (separate handler for type=color)
    this.maskBlockList.querySelectorAll('.mask-block-color').forEach(input => {
      input.addEventListener('input', (e) => {
        const idx = parseInt(e.target.dataset.idx);
        const field = e.target.dataset.field;
        if (idx >= 0 && idx < this.maskBlocks.length) {
          this.maskBlocks[idx][field] = e.target.value;
          this.previewCache = null;
          this._triggerAutoPreview();
        }
      });
    });

    // Bind delete buttons
    this.maskBlockList.querySelectorAll('.mask-block-del').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const idx = parseInt(e.target.dataset.index);
        this._removeMaskBlock(idx);
      });
    });
  }

  /** Simple HTML entity escaping for input values */
  _escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }
}
