const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const pkgPath = path.join(__dirname, 'package.json');
const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));

// 版本号格式: "大版本.小版本.日期"  (如 "2.3.20260610")
// 每次构建小版本自动 +1:  v2.3 → v2.4 → v2.5 ...
const [major, minor, dateSuffix] = pkg.version.split('.').map(Number);
const newMinor = minor + 1;

// Today's date as YYYYMMDD
const now = new Date();
const y = now.getFullYear();
const m = String(now.getMonth() + 1).padStart(2, '0');
const d = String(now.getDate()).padStart(2, '0');
const dateStr = `${y}${m}${d}`;

const newVersion = `${major}.${newMinor}.${dateStr}`;

// Update version and artifact name
pkg.version = newVersion;
const ext = '${ext}';
pkg.build.artifactName = `会计必备PDF工具_v${major}.${newMinor}.${dateStr}_Win7安装包.${ext}`;

fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n', 'utf8');

console.log(`Version: ${newVersion}  (v${major}.${newMinor})`);

// Run electron-builder
const args = process.argv.slice(2).join(' ');
const cmd = `npx electron-builder ${args}`;
console.log(`Running: ${cmd}`);
execSync(cmd, { stdio: 'inherit' });
